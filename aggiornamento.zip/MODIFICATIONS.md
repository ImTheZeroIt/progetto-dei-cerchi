# Registre des modifications

Ceci est la première version publique : Constitution V.29 et Codes alignés, publiés le 5 octobre 2026.

À partir de maintenant, chaque modification acceptée sera notée sur cette page avec la date, le texte et l’article concernés, et la raison.

# Modifications

## 3 novembre 2026 — Quatre points faibles : décisions lentes, Assemblée générale, dépendances, rigidité

Choix de l’auteur, après la liste des points faibles du système.

**Délai de la procédure** (Code 3, nouvel art. 13, al. 1-bis). Une décision contestée pouvait durer des mois. La procédure du consensus se conclut désormais dans les 45 jours, prorogeables une fois de 30 avec motivation ; les séances de discussion et la médiation peuvent aussi être convoquées en dehors de l’Assemblée mensuelle, avec 48 heures de préavis. À l’expiration du délai, la première Assemblée utile décide.

**Décisions urgentes** (Code 3, nouvel art. 13, al. 1-ter). Le Cercle 1 n’avait pas de voie urgente générale. Désormais, si le retard nuit aux personnes, au Panier, aux services essentiels ou à des biens qui seraient perdus : Assemblée avec 48 heures de préavis, 24 heures pour les objections, une seule séance de discussion, puis la décision. Elle est provisoire pendant 30 jours, tandis que la proposition suit la procédure ordinaire. Les objections pour norme impérative ou risque grave et les avis contraignants négatifs bloquent aussi la voie urgente ; le quorum et les voix favorables minimales restent.

**Seconde convocation de l’Assemblée générale** (Code 3, art. 14, al. 6). Si les trois quarts des Communautés ne participent pas, l’Assemblée générale est reconvoquée dans les 30 jours et la moitié des Communautés suffit. Les majorités des al. 7 et 8 restent.

**Dépendances structurelles** (Code 15, nouvel art. 12, al. 5-ter ; Code 16, art. 4, al. 4, lettres a et b ; Annexe B au Code 16). Pour les médicaments, composants électroniques, métaux ou batteries qu’on ne peut produire à cette échelle, un terme certain de sortie était irréaliste. Ces dépendances, si elles sont reconnues structurelles avec l’avis d’une autre Communauté, ont désormais un Plan de garantie : stocks, au moins deux fournisseurs indépendants, réduction de l’usage, réparation, alternatives à l’essai, chaque mesure avec un terme certain. Le Plan est réexaminé tous les 24 mois. Les autres dépendances critiques gardent le terme certain de sortie.

**Noyau inviolable : les principes oui, les chiffres non** (Const. 37.4, lettre i). Le tirage au sort, la rotation, le caractère temporaire des charges et l’interdiction de la politique comme métier restent intouchables. Les durées et intervalles (90 jours, 180 par an, 12 mois de pause, un an dans les Conseils) peuvent être modifiés à la Double majorité longue, mais dans des limites : toute charge reste temporaire, tournante et non immédiatement renouvelable, aucune durée ne dépasse le double d’aujourd’hui, aucun intervalle ne descend sous la moitié.

Versions : Constitution de V.38 à V.39 ; Code 3 de V1.12 à V1.13 ; Code 15 de V1.12 à V1.13 ; Code 16 de V1.10 à V1.11 ; Annexe B au Code 16 de V1.7 à V1.8. Lignes d’alignement mises à jour.

## 2 novembre 2026 — Conseils des petites Communautés ; voix favorables minimales

Deux incohérences relevées en mettant à jour les fiches pour experts.

**Intervalle entre deux mandats** (Code 3, art. 12-bis, al. 12). Le Code réduisait à six mois, dans les petites Communautés, l’intervalle avant de pouvoir être tiré au sort à nouveau dans le même Conseil. La Constitution (art. 6.5) exige douze mois dans toute Communauté. La réduction est supprimée : douze mois partout. Là où manquent des personnes aptes, restent les outils des al. 5 et 6 (prorogation motivée, Conseils regroupés ou partagés dans le Cercle 2).

**Seuil de 150** (Annexe C au Code 16, art. 1, al. 1). La Charte de la première année comptait 150 « personnes », tandis que la Constitution (art. 6.5) et le Code 3 (art. 12-bis, al. 12) comptent 150 « personnes ayant le droit de vote ». La Charte compte désormais elle aussi les personnes ayant le droit de vote.

**Voix favorables minimales** (Code 3, nouvel art. 13, al. 4-bis). Choix de l’auteur. Après la définition des votants (Const. 35.4), avec beaucoup d’abstentions une décision importante pouvait passer avec très peu de voix : avec 150 ayants droit, 50 participants et 44 abstentions, 4 oui suffisaient. Désormais, lorsqu’une décision exigeant un quorum est mise aux voix, les oui doivent atteindre au moins la moitié du quorum : un sixième des ayants droit pour les décisions à la majorité qualifiée, un quart pour celles soumises aux garanties spéciales. Avec 150 ayants droit, il faut au moins 25 oui. Les décisions ordinaires, qui n’ont pas de quorum, ne changent pas.

Versions : Code 3 de V1.11 à V1.12 ; Annexe C au Code 16 de V1.4 à V1.5. Lignes d’alignement mises à jour.

## 2 novembre 2026 — Les personnes qui s’abstiennent ne sont pas des votants

Choix de l’auteur. La Constitution et le Code 3 parlaient de « votants » sans dire si les abstentionnistes en font partie, et la Constitution (art. 35.1) exigeait la « majorité des participants » tandis que le Code 3 exigeait celle des « participants actifs ».

**Définition des votants** (Const., nouvel art. 35.4 et art. 35.1 ; Code 3, art. 12.3 nouvelle lettre d). Sont votants les personnes qui votent oui ou non. Les personnes qui s’abstiennent prennent part à la délibération et comptent pour le quorum, mais ne sont comptées ni parmi les votants ni dans le calcul des majorités. Cela vaut pour tous les seuils qui se réfèrent aux votants : la majorité simple du Cercle 1, les signatures pour l’Objection de conscience ou de durabilité écologique (10 % des votants), les majorités de l’Assemblée générale, du Cercle 4 et des modifications de la Constitution.

**Participation des Communautés à l’Assemblée générale** (Code 3, art. 14.6). Une Communauté participe lorsqu’au moins un tiers de ses ayants droit prend part à la délibération, abstentionnistes compris.

Versions : Constitution de V.37 à V.38 ; Code 3 de V1.10 à V1.11. Lignes d’alignement mises à jour dans tous les textes.

## 1er novembre 2026 — Seconde vérification de cohérence : territoire, systèmes, transition

Seconde partie de la seconde vérification de cohérence complète. Toutes les rubriques qui tiennent des rapports sur le territoire et les ressources, les systèmes et la transition sont appliquées : 42 rubriques (1 haute, 17 moyennes, 24 basses), avec 60 modifications dans 15 textes. Les choix de valeur sont ceux de l’auteur.

**Animaux dans les Phases 0 et 1** (Code 16, art. 3.1 f, 3.2 f et 3.3 f ; Annexe C, art. 9.3). Si des animaux vivent dans le Cercle pilote ou y sont accueillis, le Conseil Biodiversité est institué dès la Phase 0 pour les autorisations de la Const. 13.3. Dès la Phase 1, il exerce les fonctions que lui donnent les Codes 8, 9 et 10 ; dès la Phase 2, il a toutes les fonctions du Code 13.

**Protection des mineurs dans les Phases 0 et 1** (Code 16, art. 3.1 f ; Code 15, art. 21-bis.5 e). Jusqu’à l’activation du Code 12, le Conseil Santé exerce les fonctions du Conseil Soin prévues par la Const. 26.2 et 26.3, y compris pour la Communauté associée. Pendant la transition, la séparation d’un mineur dans une Communauté associée revient à l’État, comme dans les autres Cercles (Code 12, art. 7-bis.3-ter).

**L’animal après l’entrée du Corps** (Code 13, art. 7.3 et nouvel 7.3-bis, art. 11.4 c ; Code 14, art. 8-ter.3). Le Conseil Biodiversité peut ordonner un accueil provisoire de trente jours au plus, que le Tribunal de garantie valide en même temps que l’entrée ; l’accueil durable est décidé par le Tribunal. Le nouvel alinéa ne permet aucune entrée dans un Cercle 0 au-delà de la Const. 5.1 a).

**Zoonoses** (Code 13, nouvel art. 8.7, art. 7.10). Sur les animaux ne sont admis que la séparation ou l’isolement temporaire, les soins et les vaccinations, l’hygiène des lieux et la limitation des contacts. La mise à mort est interdite, sauf l’euthanasie déjà réglementée.

**Nourriture et soins des animaux** (Code 1, nouvel art. 32.1-sexies ; Code 13, art. 4-bis.6 et 7.11). Choix de l’auteur : la nourriture minimale pour la survie et les soins vétérinaires urgents des animaux qui vivent avec la Communauté, y compris les sanctuaires, relèvent des urgences vitales de la lettre a), sans rien retirer aux niveaux 1 et 2 du Panier des personnes, comme l’eau (Code 9, art. 10.8).

**Énergie et eau dans les Cercles 2 et 3** (Code 8, nouvel art. 3-bis, art. 6-bis.7). Le stockage, l’équilibrage, la compensation et le dispatching sont confiés à un Conseil Énergie et Eau commun. Les prélèvements dans un même bassin hydrographique sont délibérés par l’Assemblée générale ou, si le bassin comprend des Cercles 2 différents, par leurs Assemblées générales de manière concordante.

**Animaux, eau et sanctuaires** (Code 9, art. 6-bis.6, 10.8 et 10.9 ; Code 13, art. 3.3, 4.1 c, 4-bis.5 et 11.3 e ; Code 10, art. 4.1 g). La vérification des animaux présents lors de l’adhésion a un seul délai, douze mois, et entre-temps les animaux restent avec la Communauté sans collaborer. Les animaux déjà accueillis ne sont transférés que pour leur bien-être, avec l’attestation vétérinaire. La zone du sanctuaire est affectée par le Cercle 1 sur le territoire duquel elle se trouve. L’avis négatif du Conseil Biodiversité sur les nouveaux captages est contraignant. La STV Gestion de la faune a un délai.

**Accaparement d’énergie** (Code 8, art. 9.2). L’accumulation au-delà des limites et le chantage énergétique sont une infraction de Degré 4, comme le dit la Const. 15.2, et non un « vice de procédure grave ».

**Défense et transition** (Code 14, art. 8-quinquies.6 et 8-sexies.8 ; Code 15, art. 20.4). Pendant la transition, l’entrée du Corps dans un Cercle 0 sans consentement est elle aussi limitée par la loi en vigueur. Un animal agressé par un autre animal peut être protégé selon les mêmes degrés, sans mise à mort. La défense civile du Code 15 s’applique dans les limites de la loi et le sabotage est exclu.

**Systèmes sur des serveurs extérieurs** (Code 16, art. 9-bis.1 c). Choix de l’auteur : ils ne sont admis que si le logiciel et ses mises à jour sont choisis, vérifiés et installés par la Communauté. La Const. 19.4 ne change pas.

**Vérifications avant le Conseil Réseau** (Code 16, nouvel art. 9-bis.3). En Phase 0, l’avis sur les dépendances et la vérification des mises à jour sont rendus à titre provisoire par deux personnes compétentes tirées au sort ; leur avis négatif reste une interdiction. Dès la Phase 0, le vote par le Réseau suit le Code 7, art. 7-bis.

**Souveraineté technologique** (Code 2, art. 5.2 b ; Code 11, art. 5.7 a et 5.8 ; Code 7, art. 2.1, 5-ter.1 et 7-bis ; Code 1, art. 37.1 ; Code 16, art. 4.4 f). Le micrologiciel qui exécute des commandes ou des automatisations dotées d’une STV ne « propose ni ne décide » au sens de la Const. 19.4. Les véhicules à micrologiciel fermé suivent le Plan de substitution du Code 2, avec une seule prorogation. Le cloud propriétaire n’est admis que pendant la transition, et pour la clore les systèmes admis au titre de l’application progressive doivent être retirés. Le logiciel avec lequel on vote est open source et l’urne se trouve sur les nœuds des Communautés. Pour l’Entrepôt, l’eau et l’énergie, l’IA de Communauté est seulement consultative.

**Registres et renvois** (Code 3, art. 13.6 ; Code 7, art. 3.2 e ; Code 11, art. 6-quater.3 ; Code 16, art. 4.4 e et 10.5). Le Registre des décisions de l’Assemblée est institué ; le registre du Code 4 porte son nom ; le protocole ferroviaire suit l’art. 14 du Code 3 ; la révision suit aussi la Const. 37 ; la liste des liens du Code 16 est mise à jour.

**Panier d’urgence et boycott** (Code 16, art. 11.2 e et 15.3). Le Panier d’urgence va aussi aux enfants et aux personnes à charge des participants. L’interdiction de délibérer sur le boycott ou de le financer vaut aussi pour les Cercles pilotes et les Communautés associées : le boycott reste seulement un choix politique des personnes et le Code ne règle que des activités licites.

**Bassins et entrées** (Code 16, art. 1.2 d, 3.2 a, 3.7 b, c et f ; Code 15, art. 21-bis.6). Un Bassin compte en règle générale pas plus de quatre Cercles et, s’il les dépasse, peut se diviser sans reculer de phase. Qui entre dans un Bassin déjà en Phase 2, ou dans une Fédération qui a clos la transition, est vérifié par le Conseil Transition de la Fédération ou par un Conseil constitué pour cette seule vérification. Les délais des Codes activés par phases courent à partir de leur activation. Avant qu’un Bassin n’existe, les fonctions du Cercle 2 envers la Communauté associée sont exercées par les Cercles pilotes et les Communautés associées concernés et par les collèges du Code 4, art. 37.5. Dans un Bassin formé uniquement de Communautés associées, les seuils « sur les autres unités » ne s’appliquent pas.

**Annexes au Code 16** (Annexe A, art. 2.2 et 4.5 ; Annexe B, art. 1.2 d, 7 et 8 ; Annexe C, art. 10.1 ; Code 16, art. 13.3). Le questionnaire sur la sécurité ressentie et la garantie du Panier se comptent par Cercle pilote. Pour le Cercle né d’un réseau, les rencontres du Niveau 1 ont lieu dans les quatre-vingt-dix jours suivant la conversion. Au redémarrage, on vérifie les conditions de la phase en cours. La diffusion extérieure de l’Annexe B vaut pendant la transition. La vérification des seuils est effectuée par le Conseil Transition. Les données des pactes avec celles et ceux qui travaillent dans les filières essentielles passent, avec le consentement de la personne, au Cercle de son territoire.

**Noyau et légalité.** Aucune modification ne touche la Constitution, l’art. 37.4 ni les articles qu’il nomme. Le nouvel art. 7.3-bis du Code 13 et l’art. 8-quinquies.6 du Code 14 n’élargissent pas l’exception de la Const. 5.1 a). La Const. 38.6 est inchangée.

Raison : rapports de la seconde vérification de cohérence (`territorio`, `sistemi`, `transizione`), avec les choix de l’auteur sur la nourriture et les soins des animaux et sur les systèmes hébergés sur des serveurs extérieurs. Avec la partie 1, la seconde vérification complète est appliquée en entier (VERIFICA-COERENZA.md).

Versions : Code 1 de V1.11 à V1.12 ; Code 2 de V1.8 à V1.9 ; Code 3 de V1.9 à V1.10 ; Code 7 de V1.9 à V1.10 ; Code 8 de V1.6 à V1.7 ; Code 9 de V3.3 à V3.4 ; Code 10 de V1.7 à V1.8 ; Code 11 de V1.5 à V1.6 ; Code 13 de V1.8 à V1.9 ; Code 14 de V1.9 à V1.10 ; Code 15 de V1.11 à V1.12 ; Code 16 de V1.9 à V1.10 ; Annexes A et C au Code 16 de V1.3 à V1.4 ; Annexe B de V1.6 à V1.7. La Constitution reste en V.37.

## 1er novembre 2026 — Seconde vérification de cohérence : pouvoir, économie, personnes

Première partie de la seconde vérification de cohérence complète, qui cherche les effets croisés des corrections faites entre le 19 et le 29 octobre. Les rubriques qui tiennent des rapports sur le pouvoir et la justice, l’économie et le travail, et les personnes sont appliquées. Les choix de valeur sont ceux de l’auteur.

**Le jeune qui sort à seize ans** (Const. 26.5 et 4.9-ter ; Code 12, art. 7-ter.8 ; Code 1, art. 13.3 et 47.3-bis ; Code 4, art. 32-bis.2 a). Il peut rester dans la maison familiale, avec le consentement de ceux qui y vivent, jusqu’à dix-huit ans : il reçoit le Panier pour lui-même et l’art. 4.9-ter ne lui est pas applicable. À dix-huit ans, il choisit d’adhérer, de vivre avec le Pacte ou de partir ; le silence ne vaut pas adhésion. Son séjour n’est pas l’hospitalité de l’art. 4.9 b), qui reste inchangé.

**Comment un enfant devient membre** (Code 12, nouvel art. 7-ter.4-bis). Il est membre dès la naissance, ou dès son arrivée, si au moins l’une des personnes qui en prennent soin l’est ; sinon, il adhère selon les règles d’âge de l’art. 26.5. A « grandi dans la Confédération » qui a été membre pendant au moins un an lorsqu’il était mineur.

**Enfants des cohabitants des Communautés associées** (Code 15, art. 21-bis.9, nouvelle lettre g). Ils ont les mêmes droits que les enfants de qui vit avec le Pacte et, pour les besoins vitaux immédiats, la couverture des déficits par le Pool.

**Mineur dont personne ne prend soin** (Code 12, art. 7-bis.3-bis). Le Tribunal de garantie statue aussi lorsque personne n’exerce la responsabilité de soin ou que plusieurs personnes se la disputent, et indique qui l’assume.

**Mesures coercitives sur les mineurs** (Code 6, art. 2-ter.2 ; Code 12, art. 9.1 g). La personne qui donne le consentement pour un mineur ne peut pas consentir à une mesure coercitive : les limites de l’art. 8 du Code 6 s’appliquent, comme pour les adultes.

**Âge minimum pour les charges tirées au sort** (Code 3, art. 12-bis.4 ; Code 4, art. 27.4 ; Code 14, art. 8-bis.3 ; Code 5, art. 6.4). Dix-huit ans pour les Conseils, les organes de la justice, le Corps de protection civique et les porte-parole ; à partir de seize ans, on participe en accompagnement, sans droit de vote (dans le Corps, sans contention ni usage de la force).

**Soutien au démarrage de la vie autonome** (Code 1, nouvel art. 49.6 ; Code 15, art. 17.3). Il comprend au moins la CBO relais et la dotation de Maison-relais ; pour qui quitte la Confédération, les Biens d’usage personnel, les moyens du déménagement et une somme de la Caisse commune fixée chaque année par l’Assemblée. Il est proposé par le Conseil Soin ; recours au Cercle de garantie.

**Qui est sorti mineur** (Code 5, art. 6.6-bis). Il peut choisir à tout moment sous forme de réadmission ; le silence ne le rend pas membre.

**Réadmission de qui devient exempté** (Code 4, art. 29.6-bis f). La personne qui a perdu le statut pour refus de la CBO et qui entre-temps est exemptée ou empêchée est réadmise sans autre condition.

**Autonomie du mineur dans la Communauté associée** (Code 15, art. 21-bis.5 e). Le Conseil des Compétences participe aussi à l’évaluation, comme dans le Code 12.

**Expérimentation sanitaire** (Code 6, art. 10.5 et 10.7 e). L’interdiction sans consentement vaut pour toute personne. Dans le cas exceptionnel d’un seul mineur ou d’une personne incapable, l’autorisation est donnée par le Tribunal de garantie, de manière confidentielle, dans un délai de sept jours ou de vingt-quatre heures, au lieu de l’Assemblée générale.

**Énergie essentielle** (Code 1, art. 13.3 ; Code 4, art. 29.6-bis d). Même la personne qui a perdu le statut pour refus de la CBO conserve l’énergie essentielle à la santé et à la survie (Const. 15.2 ; Code 8, art. 4.2).

**Cohabitants des Communautés associées et biens communs** (Const. 4.5 ; Code 15, art. 21-bis.9 a). Le Pool couvre aussi pour eux l’eau, les soins d’urgence et l’énergie essentielle ; pour le reste, leurs besoins n’entrent pas dans le calcul du déficit. Ils ne prélèvent pas dans les Entrepôts des autres Communautés et des Cercles 2 et 3 ; ce qu’ils reçoivent de la Communauté qui les accueille, y compris de son Entrepôt, est à la charge de celle-ci.

**Services externes** (Code 2, art. 23.1 e). Comme pour les biens (rubrique C61), le Conseil Qualité propose et l’organe indiqué par la matrice du Code 3 décide.

**Recours sur le Pool** (Code 15, art. 9-bis.6). Contre les décisions d’allocation, la vérification du Collège de réexamen remplace le recours du Code 3, art. 17.1-bis, qui reste pour les seuls vices de procédure et de compétence.

**Méthode UCR** (Code 3, art. 9.3 ; brouillon UCR, paragraphe 2). Elle est proposée par le Conseil Comptabilité commun du Cercle 2 ; pour le Cercle 3 et entre Cercles 2 différents s’applique la méthode approuvée par le Cercle 3 ou, à défaut, celle du Cercle 2 qui conserve la ressource. Dans le brouillon, le coefficient heures par euro fait partie de la méthode ; seules les conversions des UCR en euros sont indicatives.

**Termes** (Const. 10.5 et 32.2 ; C.1-Annex A, art. 5.5 ; Code 1, art. 44.6 et 47-ter.4 a). « Union » devient « Cercle supérieur » et « Cercle intermédiaire ». La dérogation de l’Annex A est accordée par l’Assemblée du Cercle 1, sauf « risque collectif immédiat et documenté » (et non plus « urgence extrême »). Les CdR sont aussi suspendues pendant la suspension ordonnée par le Plan du Degré 3. La Maison-relais pour qui est sans logement n’a pas de limite de durée, même au-delà des trente jours de la dotation.

**Cohabitants et justice** (Code 4, art. 32-bis, nouvel alinéa 1-bis, art. 32-bis.2 a, art. 37.1). Pour le cohabitant d’une Communauté associée, les mesures liées au statut de membre ne s’appliquent pas ; à leur place, le Tribunal peut ordonner l’éloignement protecteur hors de la Communauté, avec l’offre du Pacte ailleurs. La procédure d’éloignement du 4.9-ter ne lui est pas applicable. Pendant la transition, le Chapitre V vaut pour lui s’il l’accepte avec l’accueil.

**Le Corps de protection civique là où il n’existe pas** (Code 14, art. 8-bis.1 ; Code 15, art. 21-bis.5 f). Pour la Communauté associée qui n’a pas de Corps, le Cercle 2 active les membres de service des Communautés les plus proches. L’organe interne qui tient lieu de Corps suit les règles du Corps, et son entrée dans un Cercle 0 est validée par le Tribunal.

**Assemblée générale et porte-parole** (Code 3, nouvel art. 14.1-bis, art. 14-bis.5). Chaque Communauté tire au sort un porte-parole pour un cycle de quatre-vingt-dix jours, révocable par son Assemblée. Les porte-parole convoquent l’Assemblée générale à la demande d’un Cercle 1, d’un Conseil commun, du Conseil des Entrepôts ou d’un dixième des personnes ayant le droit de vote ; lorsqu’un Code fixe un délai, la convocation est obligatoire. Le rapport proposait un an : la Const. 4.4 a), qui fait partie du Noyau, ne permet pas plus de quatre-vingt-dix jours.

**Validation de l’entrée du Corps** (Code 4, nouvel art. 34.2-bis ; Code 14, art. 8-ter.3 et 10.1 a). Il est écrit ce que vérifie le Tribunal lorsque le Corps entre dans un Cercle 0, y compris pour un animal, et ce qu’il peut ordonner.

**Second Tribunal et Collège de réexamen** (Const. 31.6 et 31.3 e ; Code 4, art. 37.5). Tant qu’il n’existe qu’un seul Cercle 2, le second Tribunal est tiré au sort selon le Code 4 ; une fois le Bassin constitué, l’art. 35.2 prévaut. Le Collège de réexamen effectue aussi les vérifications que lui attribuent les Codes.

**Organes communs et Communautés associées** (Code 15, art. 21-bis.5 c et 9-bis.2 ; Code 3, art. 12-bis.6-bis a). Le refus de la contribution de travail est traité par les organes communs dès le premier signalement ; la suspension des CdR seulement là où les CdR sont adoptées. Les membres du Conseil des Entrepôts des Cercles 2 et 3 peuvent aussi être révoqués par leur Communauté. Dans les Conseils communs, les Communautés associées entrent aux mêmes conditions, avec leurs organes internes équivalents.

**Registre.** Dans l’entrée du 29 octobre 2026, il est précisé que l’exception de l’art. 5.1 a) est protégée par le Noyau, tandis que celle des cohabitants renvoie à l’art. 4.5 et au Code 15, qui peuvent être modifiés selon leurs propres procédures, et qu’à partir du 1er novembre 2026 s’applique aussi l’exception de l’art. 26.5 pour les mineurs.

**Noyau inviolable.** Aucune modification ne touche l’art. 37.4 ni les articles qu’il nomme. L’art. 4.9-ter reçoit seulement un renvoi à l’art. 26.5 ; par prudence, il est traité, comme les modifications du 29 octobre, comme une réécriture du texte avant toute adhésion (Const. 38.1).

Raison : rapports de la seconde vérification de cohérence (`potere`, `economia`, `persone`), avec les choix de l’auteur sur la sortie à seize ans et sur l’âge pour le tirage au sort. Les rubriques sur le territoire, les systèmes et la transition suivent à part.

Versions : Constitution de V.36 à V.37 ; Code 1 de V1.10 à V1.11 ; C.1-Annex A de V1.6 à V1.7 ; Code 2 de V1.7 à V1.8 ; Code 3 de V1.8 à V1.9 ; Code 4 de V1.9 à V1.10 ; Code 5 de V1.6 à V1.7 ; Code 6 de V1.8 à V1.9 ; Code 12 de V1.6 à V1.7 ; Code 14 de V1.8 à V1.9 ; Code 15 de V1.10 à V1.11.

## 29 octobre 2026 — Noyau inviolable : animaux dans le Cercle 0 ; cohabitants dans les Communautés associées

**Animaux dans le Cercle 0** (Const. 5.1 a ; Code 14, art. 8-ter.2 et 8-ter.3, art. 8-sexies.8). Le Corps de protection civique peut entrer dans un Cercle 0, même sans le consentement de ceux qui y vivent, pour faire cesser une maltraitance en cours qui met en danger la vie d’un animal ou lui cause de graves souffrances. Il intervient, lorsque c’est possible, avec la fonction de Secours sanitaire et vétérinaire de communauté, se limite à faire cesser la maltraitance et à secourir l’animal, et l’entrée est validée par le Tribunal de garantie dans un délai de vingt-quatre heures, comme celle qui protège les personnes ; pour cela, il peut recourir à la contention non lésionnelle. Quiconque est témoin d’une maltraitance aussi grave dans un Cercle 0 appelle le Corps, en plus de la signaler au Conseil Biodiversité et au Cercle de garantie. Qui ne fait pas partie du Corps ne peut toujours pas entrer sans consentement pour défendre un animal.

**Cohabitants dans les Communautés associées** (Const. 4.5, 4.9 b et 4.9-ter ; Code 15, art. 21-bis.8 et nouvel art. 21-bis.9). Qui vit de manière stable dans une Communauté associée sans adhérer peut y rester selon l’ordre interne. Il est à la charge de la Communauté qui l’accueille : il ne prélève ni dans les Entrepôts communs ni dans le Pool et ne reçoit pas de CdR. La part de travail de la Communauté à la frontière est calculée sur toutes les personnes qui y vivent, membres et non-membres. Il ne vote pas dans les Assemblées générales et ne figure pas sur les listes de tirage au sort des organes communs. Il conserve les garanties de l’art. 1.3 et le recours aux organes communs ; le travail qu’il accomplit pour la Communauté est volontaire et ne peut pas être exigé. Il peut adhérer à tout moment et est informé par écrit chaque année de ce droit. Si les non-adhérents sont plus nombreux que les membres, le Cercle 2 vérifie chaque année qu’il n’y a pas d’exploitation. Dans tous les autres cas, y compris lorsque l’ordre interne n’accueille plus la personne, la limite de quatorze jours de l’hospitalité (art. 4.9 b) et l’art. 4.9-ter restent inchangés. À partir du 1er novembre 2026 s’applique aussi l’exception de l’art. 26.5 pour le mineur qui reste dans son Cercle 0 après sa sortie.

**Modification du Noyau inviolable.** L’art. 5.1 a) fait partie du Noyau inviolable (Const. 37.4 f), de même que l’art. 4.9 (37.4 j). Le Noyau ne peut pas être révisé (Const. 37.4 et 38.4) : il ne s’agit pas d’une révision, mais d’une réécriture du texte par l’auteur avant toute adhésion, possible seulement parce que le système n’a encore été adopté par aucune Communauté et que la Constitution n’est en vigueur pour aucune Communauté (Const. 38.1). C’est la même voie que celle suivie le 19 octobre 2026 pour la rubrique C1-bis. Après la première adhésion, ce ne serait plus possible. Les deux exceptions sont écrites de la manière la plus réduite : une phrase dans l’art. 5.1 a) et, dans les art. 4.9 b) et 4.9-ter, un renvoi à l’art. 4.5. Une fois en vigueur, l’exception de l’art. 5.1 a) est protégée par le Noyau : une révision ne pourra pas l’étendre ; celle des cohabitants renvoie à l’art. 4.5 et au Code 15, qui peuvent être modifiés selon leurs propres procédures, mais elle ne peut pas valoir hors des Communautés associées (précision du 1er novembre 2026).

**Registres et questions fréquentes.** Dans l’entrée du 26 octobre 2026, il est noté que les deux propositions non appliquées alors le sont maintenant. Dans la question « Comment est-elle faite ? », la Communauté entre dans le Noyau de soin pour protéger quelqu’un « ou, dans les cas graves, un animal ».

Raison : décisions de l’auteur sur la rubrique D4 du rapport sur la défense personnelle et sur la rubrique M1, seconde partie, du rapport sur les Communautés associées (vérification de cohérence du 26 octobre 2026). Jusqu’ici, un animal gravement maltraité à l’intérieur d’une maison ne pouvait être protégé par personne : le Code renvoyait au Corps, qui ne pouvait pas entrer. Et qui vit depuis des années dans une communauté qui s’associe, sans adhérer, par exemple un conjoint, aurait dû partir au bout de quatorze jours ou demander le Pacte de cohabitation autonome. Le Noyau inviolable n’est réécrit que parce que le système n’a encore été adopté par aucune Communauté (Const. 38.1).

Versions : Constitution de V.35 à V.36, Code 14 de V1.7 à V1.8, Code 15 de V1.9 à V1.10.

## 29 octobre 2026 — Traduction espagnole des règles

La Constitution, les seize Codes et les quatre Annexes sont traduits en espagnol (`testi/es/registro/`) et publiés sur le site avec leur registre des modifications (`CAMBIOS.md`) et les fichiers PDF et ODT à télécharger ; les réponses aux questions en espagnol renvoient désormais aux articles espagnols. Aucune règle ne change sur le fond. C’est une traduction de travail, à faire relire par des locuteurs natifs de l’espagnol ; les termes sont fixés dans `testi/es/GLOSARIO.md`. Le texte qui fait foi est l’italien.

Les pages de service sont traduites elles aussi : le registre des paramètres à vérifier, les trois brouillons techniques (Panier, UCR, CdR), les archives des propositions et leur vérification contradictoire (`testi/es/borradores/`) ; la version espagnole du site renvoie désormais à ces pages. La vérification de cohérence reste en italien, comme pour l’anglais et le français.

## 27 octobre 2026 — Code 3 : approbation de l’Annexe UCR ; brouillons techniques alignés

**Code 3** (art. 9.3 et 19.3). Les deux alinéas disaient des choses différentes sur qui approuve l’Annexe technique UCR : « l’Assemblée compétente » et « l’Assemblée du Cercle 1 ». Par décision de l’auteur, la méthode de calcul est commune à toutes les Communautés du Cercle 2 : elle est élaborée par les Conseils Comptabilité et Qualité en coordination fédérée, proposée par le Cercle 2 et approuvée par son Assemblée générale. Chaque Communauté approuve par sa propre Assemblée ses propres valeurs selon cette méthode. Avant le Cercle 2, l’art. 14.10 s’applique. Aucun autre texte n’était en contradiction (Constitution et Codes 1, 2, 4, 7, 15 et 16 vérifiés).

**Brouillons techniques** (Annexe du Panier, Annexe UCR, barème de la CdR ; version 0.2, toujours non adoptés). Alignés sur les règles en vigueur : logement, énergie, habillement et hygiène comme dans les Codes ; biens de niveau 1–2 et biens différables ; Paniers santé et soin complets ; Panier d’urgence des réseaux. Le bilan des heures compte désormais les jeunes de dix-huit ans en CBO volontaire, le logement de 22 m², les Maisons-relais, la protection civique hors du dixième et une part pour le Bassin (estimations minimales déclarées) : entre 9 et 14 heures par semaine au lieu de 9–13. Le barème de la CdR utilise la CBO estimée par le brouillon UCR et ajoute les activités culturelles, les déplacements et les robots dans les tâches à risque. Chaque brouillon a une section « Ce qu’il faut pour l’adopter ». Les programmes `strumenti/bilancio_ore.py` et `strumenti/simula_cdr.py` et le registre des paramètres sont mis à jour.

Raison : vérification des brouillons du 27 octobre 2026 ; décision de l’auteur sur l’approbation de l’Annexe UCR. Le Noyau inviolable n’est pas touché.

Versions : Code 3 de V1.7 à V1.8.

## 26 octobre 2026 — vérification de cohérence des nouveautés (défense personnelle, Communautés associées, parcours des réseaux)

Une vérification de cohérence ciblée a relu les nouveautés du 19 au 26 octobre (défense personnelle, Communautés associées, parcours des réseaux) ; pour chaque point, un second lecteur a essayé de le démonter. Les points qui ont tenu sont corrigés : pour les choix de l’auteur comme indiqué ci-dessous, pour les autres selon la recommandation des rapports.

**Défense personnelle**

- **Bien commun vital** (Code 14, art. 1.2 i et 8-sexies.7). Par décision de l’auteur, il est défini par sa fonction : le Bien commun dont la destruction, la contamination ou l’interruption met en danger concret et immédiat la vie ou la santé de personnes, avec des exemples indicatifs. Pour le défendre, restent seulement l’interposition, l’éloignement et la rétention, sans frapper et sans utiliser d’objets.
- **Protéger un enfant d’un danger** (Code 14, art. 8-sexies.5 d). Le geste minimal et momentané qui soustrait un mineur ou une personne fragile à un danger immédiat n’est pas interdit.
- **Animaux** (Code 14, art. 8-sexies.8 ; Code 4, art. 26-bis.1 et 2 ; Code 13, art. 5-bis.4). Par décision de l’auteur, contre un animal qui agresse une personne on procède par degrés, et sa mise à mort n’est admise que s’il n’y a pas d’autre moyen de sauver une vie ou d’éviter des blessures graves. Qui défend un animal peut invoquer l’erreur excusable, et pour les objets compte le danger pour l’animal. Une maltraitance dans un Cercle 0 est signalée au Conseil Biodiversité et au Cercle de garantie.
- **Entrer dans un Cercle 0** (Code 14, art. 8-sexies.9 ; Code 4, art. 26-bis.5 e). Le consentement d’une personne qui y vit suffit, même exprimé par une demande d’aide, et le refus de celui qui commet la violence ne compte pas. On peut aussi entrer pour un secours urgent lorsque le Corps ne peut pas arriver à temps. L’avis est donné au Corps ou, s’il ne répond pas, au Cercle de garantie ou aux services d’urgence.
- **Appeler les autorités** (Code 14, art. 8-sexies.13). Qui est agressé peut toujours les appeler, mais n’y est pas obligé ; qui a employé la force appelle les secours s’il y a des blessés ; les obligations légales de signalement et de dénonciation demeurent.
- **Excès léger** (Code 4, art. 26-bis.3 et 5 d). Il est de Degré 2 si le dommage est léger et réparable, de Degré 1 s’il n’y a pas de dommage appréciable. Le Tribunal constate les faits et renvoie le cas au Cercle de garantie, pour la procédure réparatrice et l’Assemblée de clarification.

**Communautés associées**

- **Règles fondamentales et vie interne** (Const. 4.5 ; Code 15, art. 21.2, 21-bis.6 et 21-bis.7). Par décision de l’auteur, la vérification ne peut demander des changements de la vie interne que là où la communauté ne respecte pas les règles fondamentales, avec un Plan de raccordement et des délais convenus ; le reste de la vie interne n’est pas touché. Si après l’adhésion le Plan n’est pas convenu ou pas mis en œuvre, l’association peut prendre fin, avec les garanties des personnes.
- **Droits des personnes et vote** (Const. 4.5 ; Code 15, art. 21-bis.1). Les articles 19.1, 21, 30.1, 30.2 et 36.1 de la Constitution sont aussi des règles fondamentales. La Communauté associée est une Communauté de base ; le vote dès quatorze ans vaut aussi dans ses décisions internes.
- **Organes internes** (Const. 4.5 ; Code 15, art. 21-bis.4 b et c). Les organes nommés par les règles fondamentales peuvent être remplacés par des organes internes équivalents ; s’ils manquent, le Cercle 2 ou un organe partagé y pourvoit.
- **Contribution de travail et perte du statut** (Code 15, art. 21-bis.4 c et 5 c). La contribution que la communauté demande vaut CBO ; pour la perte du statut (Const. 7.3-bis), elle ne compte que dans la limite de la CBO et avec les justifications et les organes du Code 4.
- **Règle du doute** (Code 15, art. 21-bis.4 e). En cas de doute, la disposition qui protège une personne ou une limite écologique vaut mise en œuvre des règles fondamentales.
- **Faits graves, défense, mineurs, mesures urgentes, exclusion** (Code 15, art. 21-bis.5). Les signalements de Degré 4–6 et les communications après une défense vont aussi au Cercle de garantie tiré au sort d’une autre Communauté, et l’organe interne ne peut pas les retenir ; la protection des mineurs est assurée par le Conseil Soin d’une autre Communauté ou partagé ; les mesures urgentes sont validées par le Tribunal dans les vingt-quatre heures ; l’ordre interne ne peut exclure personne ni le priver de logement, de Panier ou de soins.
- **Recours sur les droits** (Code 15, art. 21-bis.5 d). Il est possible tant que la violation dure ; le collège peut annuler l’acte et ordonner le remède ; si la Communauté ne l’exécute pas, le Cercle 2 y pourvoit.
- **Vérification avant les Bassins** (Code 15, art. 21-bis.6 ; Code 16, art. 12.5). Tant qu’il n’y a pas de Bassin, la vérification est faite par trois personnes tirées au sort parmi des Cercles pilotes ou des entités apparentées.
- **Qui vit dans la communauté sans adhérer** (Code 15, art. 21-bis.8). Ce n’est pas un membre ; les garanties des articles 1.3 et 4.9–4.9-ter de la Constitution s’appliquent.
- **Pool** (Code 15, art. 21-bis.2 b ; Code 1, art. 15.1-bis). Par décision de l’auteur, son utilisation est facultative ; le surplus d’aliments, d’eau et de biens pour les soins est de toute façon partagé lorsqu’une autre Communauté est en déficit vital, et la Communauté reçoit de la même manière.
- **Part de travail** (Code 15, art. 21-bis.2 c). Elle peut aussi être fournie en biens ; un versement à la Caisse du Cercle 2 est du mutualisme et ne remplace pas le travail.
- **Transit et hospitalité** (Const. 4.5 ; Code 15, art. 21-bis.2 g). La Communauté associée accueille les membres des autres Communautés, au moins avec l’aire d’accueil.
- **Abandonner un outil ou devenir associée** (Code 15, art. 21-bis.3). Un outil adopté s’abandonne avec un préavis de quatre-vingt-dix jours ; une Communauté qui applique les Codes ne devient associée qu’aux trois quarts, et qui n’est pas d’accord peut se transférer.
- **Code 16 et Communauté associée** (Code 16, art. 1.3, 3.7 f et 12.5). Les articles 2 et 15.2–15.3 s’appliquent toujours ; la Communauté compte comme Cercle pilote si elle a au moins trente adhérents, sinon avec d’autres ; elle n’a pas à franchir les seuils de la Phase 0 ; à la conversion d’un réseau, elle choisit d’entrer dans le Cercle qui naît ou de rester associée.
- **Revenus extérieurs mis en commun** (Code 16, art. 2.9). Ils valent tant qu’existent des moyens de paiement extérieurs ; le fonds n’appartient pas à l’entité ; qui sort reprend la part non dépensée.

**Parcours des réseaux**

- **Le Panier d’urgence ne soutient pas le boycott** (Code 16, art. 11.2 e). Il va à qui en a besoin, pour quelque cause que ce soit, selon des règles publiques.
- **Défense dans les réseaux** (art. 11.2 c). Civile et désarmée, dans les limites de la loi ; le renvoi à la Const. 16.4 est supprimé et le sabotage est exclu, comme dans le parcours des Cercles pilotes ; avant la conversion, on appelle les services d’urgence.
- **Ce qui s’applique aux réseaux** (art. 11.4). La continuité du Panier est assurée par le seuil ; les autres Codes s’appliquent à partir de la conversion, phase par phase ; les réseaux peuvent utiliser la procédure réparatrice ; les infractions pénales restent aux autorités.
- **Entrepôts et normes sanitaires** (art. 12.2 e). Aliments, eau et médicaments sont conservés et distribués selon les normes sanitaires ; les médicaments seulement dans les formes permises par la loi.
- **Entités et créanciers** (art. 12.3, 12.4 et 18.1 b). La phrase sur les biens « protégés même si le boycott ne réussit pas » est supprimée : le patrimoine de l’entité est séparé dans les limites de la loi, et l’entité n’accepte pas d’apports ou de versements qui soustraient des biens aux créanciers. Les statuts admettent les participants comme membres et règlent le passage des biens au Cercle.
- **Données des pactes** (art. 13.3). Consentement explicite, protection des données, effacement à la révocation ou à la conversion.
- **Seuil** (art. 1.2 o, p et r, 14.1-bis, 14.3 et 14.4). Le Panier d’urgence comprend l’énergie de base ; chaque personne et chaque pacte ne sont comptés que dans un seul réseau ; « pays » est défini ; les seuils de six et de douze mois sont vérifiés ensemble et la date vaut selon celui qui est atteint ; la vérification est répétée avant la date et, si le seuil n’est plus atteint, le vote perd son effet ; la liste et le tirage au sort des vérificateurs sont publics.
- **Vote** (art. 14.6 et 20.2 b–c). Proposition d’un dixième des participants, publiée pendant quatorze jours, vote ouvert au moins sept jours, nouvelle proposition après quatre-vingt-dix jours ; les garanties du Code 7, art. 7-bis, applicables aux réseaux, avec le registre tenu par le réseau ; participation sans nom public, non anonyme ; avis juridique étendu aux risques pour les entités, les charges et le portail, demandé par des personnes tirées au sort.
- **Le boycott** (art. 2.7 et 15.1–15.3). Le Code ne le prescrit ni ne l’autorise et n’en régit que le vote ; « ensemble et une seule fois » est dit comme une indication des personnes ; les Cercles nés des réseaux non plus ne le délibèrent pas et ne le financent pas.
- **Caisses de solidarité et Caisse commune** (art. 15.4–15.5 ; Code 15, art. 17.3). Les caisses aident quiconque est en difficulté, pour quelque cause que ce soit. Après la conversion, la Caisse commune peut payer des frais juridiques et, selon des règles égales pour tous, éteindre des dettes des membres en payant le créancier.
- **CBO dans les filières essentielles** (art. 16.2 d ; Code 15, art. 19.3 ; Annexe C, art. 5.4). Elle vaut aussi dans les Cercles pilotes pour qui a signé le pacte et dure autant que la coexistence.
- **Conversion** (art. 17.1 et 17.2-bis). Elle ne présuppose ni le seuil ni le boycott ; votent aussi les participants qui n’adhèrent pas ensuite ; pour les mineurs de moins de seize ans, adhère la personne qui en prend soin. Inventaire, biens temporaires restitués et part des stocks pour qui n’adhère pas ; règles si les adhésions sont peu nombreuses ou si plusieurs Cercles naissent.
- **Logement** (art. 17.5). Qui apporte son logement sait par écrit ce qui se passe s’il sort ; un logement grevé d’une hypothèque ou loué n’est pas apporté tant que la charge dure, et qui y vit le conserve.
- **Rencontre avec les Phases 0–4** (art. 3.8 et 20.3 ; Annexe C, art. 1.1). Le Cercle né d’un réseau entre dans un Bassin, non dans une Fédération minimale ; le portail rejoint le Réseau fédéré lorsque le Code 7 est activé ; la Charte de la première année vaut jusqu’à cinq cents personnes.
- **Liens normatifs** (art. 10.5). Les articles cités aux articles 11–20 sont ajoutés.

**Registres et questions fréquentes.** La description de la règle sur les objets dans l’entrée du 20 octobre sur la défense personnelle est corrigée. La question fréquente « Une communauté qui existe déjà doit-elle changer sa façon de vivre pour entrer ? » est corrigée.

Raison : vérification de cohérence ciblée du 26 octobre 2026 ; décisions de l’auteur sur les Communautés associées, sur le Pool, sur le Bien commun vital et sur l’animal qui agresse. Le Noyau inviolable et la Const. 38.6 ne sont pas touchés. Deux propositions qui auraient touché le Noyau ne sont pas appliquées : l’entrée du Corps dans un Cercle 0 pour un animal (Const. 5.1 a) et la dérogation à la limite d’hospitalité de l’art. 4.9 pour qui vit dans une Communauté associée sans adhérer. Les deux propositions ont été appliquées, avec une réécriture du Noyau avant toute adhésion, dans l’entrée du 29 octobre 2026.

Versions : Constitution de V.34 à V.35, Code 1 de V1.9 à V1.10, Code 4 de V1.8 à V1.9, Code 13 de V1.7 à V1.8, Code 14 de V1.6 à V1.7, Code 15 de V1.8 à V1.9, Code 16 de V1.8 à V1.9, Annexe C du Code 16 de V1.2 à V1.3.

## 26 octobre 2026 — Code 16 : le parcours des réseaux

Par décision de l’auteur, le Code 16 comporte désormais deux parcours vers la Confédération. Les Phases 0–4, les seuils et les Annexes A, B et C restent tels qu’ils étaient et deviennent le parcours des Cercles pilotes, laboratoires où les règles sont mises à l’épreuve. À côté s’ajoute le parcours des réseaux, dans lequel les personnes commencent là où elles vivent.

- **Deux parcours** (Code 16, art. 1.1, 1.2 k–q, 1.3, 3.8 et 11). Le parcours des réseaux a cinq phases : A Semences, B Tache d’huile, C Boycott, D Conversion, E Confédération. Les deux parcours se rejoignent à la conversion : le Cercle 1 né d’un réseau entre en Phase 0 et parcourt les Phases 0–4 comme tout Cercle pilote, sans seuils abrégés ; la Phase E comprend les Phases 1–4.
- **Réseaux et formes juridiques** (art. 11.3–4 et 12). Réseaux d’entraide et entrepôts de quartier ; biens communs inscrits dès le début au nom d’associations ou de coopératives. Jusqu’au choix des personnes, personne ne cesse de payer quoi que ce soit. Les communautés solidaires qui existent déjà sont les premiers nœuds et n’ont pas à changer (Const. 4.5 ; Code 15, art. 21 et 21-bis).
- **Liaison, pactes et essais licites** (art. 13). Carte des filières essentielles, pactes personnels et révocables avec celles et ceux qui travaillent dans l’eau, l’énergie, l’alimentation et la santé, formation de celles et ceux qui assurent la relève, essais où personne ne cesse de payer, avec des résultats publics.
- **Seuil, vérification et vote** (art. 14). Six mois de Panier d’urgence pour tous les participants et des pactes signés dans les quatre filières (douze mois et un plan pour les importations pour un pays qui part seul) ; vérification par trois personnes tirées au sort dans d’autres réseaux, avec des données publiques ; vote individuel et secret, approuvé par la majorité des participants ayant le droit de vote de chaque réseau, avec une date commune entre plusieurs pays et un avis juridique avant le premier vote.
- **Le boycott n’est pas une règle** (art. 2.7 et 15). C’est un choix politique, non violent et collectif des personnes des réseaux, dont chacun répond personnellement ; les entités ne le délibèrent pas. Le Code ne régit que ce qui est licite : caisses de solidarité, assistance juridique, services ouverts à tous.
- **Travailleurs essentiels et services ouverts à tous** (art. 16 ; Code 15, art. 19.3). Celles et ceux qui travaillent dans les services essentiels continuent de servir chacun ; ils reçoivent en premier le Panier d’urgence, font des tours de service courts avec relève et, après la conversion, leur travail compte comme CBO.
- **Conversion** (art. 17). Adhésion individuelle ; réseaux → Cercles 1, entrepôts → Entrepôts communs ; rationnement équitable du Panier d’urgence ; personne ne perd le logement où il vit ; reconnaissance par la loi là où la majorité l’emporte dans les institutions ; qui n’adhère pas reste libre avec ses biens et ses droits.
- **Importations, groupes promoteurs, portail** (art. 18–20). Trois voies pour les importations ; groupes promoteurs sans chefs, ouverts, autonomes, reliés par un protocole, qui se dissolvent d’eux-mêmes ; portail fédéré, chiffré, à code ouvert, qui recueille peu de données et fonctionne aussi hors ligne, avec le vote du Code 7, art. 7-bis.

Raison : Décisions de l’auteur du 26 octobre 2026 sur le brouillon « Transition par l’entraide et le boycott ». La Constitution, y compris l’art. 38.6 et le Noyau inviolable, n’est pas touchée. Les nouveaux seuils sont des hypothèses du projet (PARAMÈTRES).

Versions : Code 15 de V1.7 à V1.8, Code 16 de V1.7 à V1.8; Constitution inchangée (V.34).

## 26 octobre 2026 — Communautés associées et équivalence à la frontière

Par décision de l’auteur, le système des Cercles ne vise pas à transformer les communautés qui existent déjà, comme les communautés solidaires à caisse commune ou les écovillages, mais à les rassembler en leur donnant des outils de gestion.

- **Deux manières d’adhérer et règles fondamentales** (Const. 4.5 ; Code 15, art. 21.1 et 21-bis.1). Une communauté peut adhérer comme Communauté associée, qui conserve son propre ordre interne, ou en adoptant aussi les Codes. Pour toutes, les Titres I, IV, V et VII de la Constitution et le Noyau inviolable sont obligatoires ; les règles de gestion (CBO, CdR, Entrepôts, organes, Conseils et assemblées internes, justice du Code 4 pour les conflits internes, phases du Code 16) sont des outils, que la Communauté associée peut adopter un à un quand elle le veut. Les principes du Noyau qui touchent la gestion demeurent aussi à l’intérieur : contribution de chaque adulte apte (Const. 2.3), tirage au sort et rotation des charges (Const. 4.3, 4.4, 6.5, 31.2), aucun vote par délégation (Const. 36.1).
- **Équivalence à la frontière** (Code 15, art. 21-bis.2–3). La Communauté associée garantit : les droits de chaque personne, y compris le Panier minimal, les soins, la sortie libre et le recours aux organes communs ; l’inventaire et le Solde dans le format commun ; une part de travail pour les fonctions communes des Cercles 2 et 3, comptée pour l’ensemble de la Communauté et non par personne, pendant la transition aussi en biens ou par la Caisse commune ; des personnes sur les listes de tirage au sort des organes communs ; le vote individuel et secret de chaque membre dans les Assemblées générales ; des standards communs (STV) pour les biens échangés. Lorsqu’elle utilise un outil commun (Pool, échange entre Entrepôts, Réseau), elle en suit les règles.
- **Règle générale de renvoi** (Const. 38.1 ; Code 15, art. 21-bis.4). Les règles de gestion des Codes ne s’appliquent à la Communauté associée que si elle les adopte ; celles qui mettent en œuvre les règles fondamentales valent pour les droits, les interdictions et les limites, avec des organes internes équivalents ; les renvois au CBO et aux organes du Cercle 1 se lisent comme faits aux institutions internes, et la contribution de travail interne vaut CBO pour les Const. 2.3, 4.4 et 7.3-bis. Le CBO et le Code 4 restent obligatoires pour les membres des Communautés qui adoptent les Codes.
- **Conflits et recours** (Code 15, art. 21-bis.5). Les autres conflits internes se règlent selon l’ordre interne (pour les Degrés 4 à 6, voir ci-dessous) ; ceux avec d’autres Communautés suivent le Code 4 ; quiconque affirme qu’un de ses droits a été violé saisit trois personnes tirées au sort dans les Cercles de garantie d’autres Communautés. Les mesures des Const. 1.3-bis et 7.3-bis et celles qui restreignent la liberté personnelle restent aux organes communs.
- **Vérification et Plan de raccordement** (Const. 4.5 ; Code 15, art. 21.2 et 21-bis.6–7). Le Cercle 2 (pendant la transition, le Conseil Transition de l’unité qui accueille) vérifie uniquement l’équivalence à la frontière, dans un délai de quatre-vingt-dix jours et sans appréciations politiques ou idéologiques. S’il manque quelque chose, on convient d’un Plan de raccordement assorti de délais, qui ne change que ce qui est nécessaire à la frontière et jamais la vie interne ; il n’est pas imposé : sans équivalence, la communauté reste extérieure, reliée par des accords.
- **Phases de la transition** (Code 16, art. 1.3 et 3.7 f). La Communauté associée ne parcourt pas les phases en son sein : elle entre dans un Bassin lorsque l’équivalence est vérifiée, y est comptée comme Cercle pilote et, pour les seuils, on compte ce qu’elle fournit à la frontière. Les renvois à l’art. 21 du Code 15 introduits le 20 octobre (Code 16, art. 1.3 ; Code 3, art. 14-bis.4) sont coordonnés.
- **Revenus extérieurs mis en commun** (Code 16, nouvel art. 2.9 ; Code 15, art. 19-bis.8). Pendant la transition, les membres d’une Communauté associée peuvent mettre en commun, volontairement, les revenus et les patrimoines personnels qu’ils détiennent hors de la Confédération (Const. 3.5-ter) et les redistribuer entre eux pour les dépenses extérieures personnelles. Le fonds ne fait pas partie de la Caisse commune du Cercle (Const. 3.5-bis), ne donne pas accès aux Entrepôts, au CdR, aux Biens communs ou aux décisions, ne rémunère pas le travail et n’achète pas le consentement ; la contribution proportionnelle aux dépenses extérieures communes demeure ; la faculté cesse avec la fin des moyens de paiement extérieurs.
- **Infractions graves** (Code 15, art. 21-bis.4 d et 21-bis.5). Les infractions de Degré 4 à 6 commises dans une Communauté associée relèvent toujours du Tribunal de garantie, sans préjudice du Code 4, art. 37 (les délits restent à l’État pendant la transition) ; les autres conflits internes restent à l’ordre interne.

Raison : Décision de l’auteur du 26 octobre 2026 (« équivalence à la frontière »), avec ses choix sur les charges internes (principes du Noyau valables aussi à l’intérieur, formes libres), sur les revenus extérieurs mis en commun et sur les infractions de Degré 4 à 6. Les modifications de la Constitution (art. 4.5 et 38.1) ne touchent pas le Noyau inviolable et valent comme texte de la première adoption (Const. 38.1).

Versions : Constitution de V.33 à V.34, Code 15 de V1.6 à V1.7, Code 16 de V1.6 à V1.7.

## 21 octobre 2026 — points de gravité faible de la vérification de cohérence (C29–C70)

Les quarante-deux points de gravité faible de la vérification de cohérence sont corrigés directement, par décision de l’auteur. Pour chaque point : ce qui change et pourquoi.

- **C29. Tirage au sort sur les listes** (Code 4, art. 36.3). Ne peut être tiré au sort sur les listes fédérées quiconque appartient à la Communauté de la personne concernée, de la personne lésée ou de l’activité contrôlée, ou y a exercé une activité au cours des vingt-quatre derniers mois ; les membres locaux que les Codes font tirer au sort dans la Communauté, comme ceux de l’art. 27.1–27.2, restent. Raison : « Cercle concerné » pouvait désigner aussi le Cercle 2 où l’on tire au sort le Tribunal.
- **C30. Activation et révision du Corps de protection civique** (Code 14, art. 8-bis.1 et 8-quater.2). Les interventions programmées sont délibérées par l’Assemblée ; en urgence, le référent de service agit et informe aussitôt le Cercle. La révision dans les vingt-quatre heures est faite par les six personnes tirées au sort dans les deux Communautés voisines, à la majorité dans chacune ; si elle n’est pas achevée à temps, l’activation n’est pas validée. Raison : il n’était pas dit qui active le Corps ni qui fait la révision.
- **C31. Avis contraignant et changement des membres** (Code 3, art. 8.2 et 12-bis.10). Révoquer ou remplacer les membres du Conseil ne surmonte pas l’avis contraignant négatif, qui reste en vigueur ; le nouveau Conseil ne le réexamine que sur la proposition présentée de nouveau. Raison : la révocation pouvait servir à contourner l’avis.
- **C32. Vérification de conformité et désactivation** (Code 4, nouvel art. 13-bis). Une seule procédure pour les renvois des Codes 12, 13 et 14 au Code 4 : vérification technique du Conseil compétent, plan de mise en conformité, désactivation délibérée par l’Assemblée avec un plan de remplacement, sans interrompre la nourriture et les soins essentiels. Raison : les Codes renvoyaient à une procédure que le Code 4 ne contenait pas.
- **C33. « Garanties vitales »** (Const. 7.3 et 30.2). Pendant la suspension du CdR, les droits de l’art. 1.2 restent intacts ; aucune mesure ne touche les garanties vitales de l’art. 30.4. Raison : le terme était employé dans deux sens différents.
- **C34. Collège de réexamen** (Const. 31.3 d et e ; Code 4, art. 35.1 et 35-bis.4). La Constitution nomme le Collège de réexamen parmi les organes de justice ; dans les recours sur les infractions des Degrés 1 à 3 y siège une personne de formation juridique prise sur la liste du Tribunal, à la place d’un membre du Conseil Qualité ; la synthèse annuelle est assurée à tour de rôle par un Cercle de garantie du Bassin. Raison : le Collège n’était pas dans la Constitution et le Conseil Qualité juge des biens et des services, non des infractions. Correction matérielle (Const. 37.5) hors du Noyau.
- **C35. Majorité au Conseil Sécurité** (Code 14, art. 3.3). À la majorité seulement les actes techniques, les avis et la validation des fiches ; propositions et décisions discrétionnaires par consensus et soixante-douze heures de publication. Raison : c’est la règle de tous les Conseils (Code 3, art. 12-bis.9).
- **C36. Recours sur une décision avec avis du Cercle de garantie** (Code 3, art. 17.1). Si le Cercle de garantie a donné un avis ou une autorisation sur la décision, le recours est tranché par des personnes tirées au sort dans d’autres Communautés. Raison : qui a donné l’avis ne peut pas le juger.
- **C37. Protocole de solidarité** (Code 1, art. 2.8 d, 3.3, 30.1 d ; Code 16, art. 1.5 ; Annexe C, art. 5.3). Un seul nom ; la Communauté demande le Protocole et ne l’active pas ; avant la Fédération minimale, la déclaration revient à l’Assemblée générale du Bassin touché, dans les limites de la Const. 36.4. Une Communauté qui ne fait pas encore partie d’un Bassin ne l’active pas seule. Raison : la Const. 36.2 le fait activer par le Cercle 3 ou par dix Cercles 1 ensemble.
- **C38. Panier santé** (Code 6, art. 6.1 et 9.5 ; Code 1, art. 18.2). Il est proposé par les Conseils Santé des Communautés en tant qu’articulations du Cercle de compétence Médecine et Santé et approuvé par l’Assemblée ; le « Conseil Santé fédéré » disparaît. Raison : cet organe n’existe pas.
- **C39. Réduction du CBO** (Code 1, art. 11.1 d et e). Grossesse, deuil, crise et les autres situations des Codes de la Santé et du Soin donnent, sur indication du Conseil Santé ou du Conseil Soin, une réduction temporaire sans dette, non cumulable avec d’autres pour la même heure ; le diagnostic reste confidentiel. Raison : le Code 6 renvoyait à une réduction que le Code 1 ne contenait pas.
- **C40. Entrepôt Santé** (Code 1, art. 14.1 d). Un seul nom. Raison : « Entrepôt de Soin » n’apparaissait qu’ici.
- **C41. Plafond du temps administratif** (Code 1, art. 2.7 e). Le dixième du CBO compte Conseils, garantie, facilitation, comptabilité et documentation obligatoire ; les services du Corps et les autres fonctions civiques se comptent à part. Raison : aligne le Code 1 sur la Const. 6.5 et le Code 3, art. 12-bis.13.
- **C42. Paramètres du CdR** (Code 1, art. 44.4). Plafond et décroissance sont fixés chaque année par l’Assemblée générale du Cercle 2 ; celle du Cercle 3 peut poser des limites communes. Raison : « Assemblée générale » désigne deux organes (Code 3, art. 14.1).
- **C43. Certification en UCR** (Code 4, art. 4.6 d). Renvoi corrigé au Code 1, art. 20.6 et 40.4. Raison : l’art. 40 traite des standards ouverts.
- **C44. Annex A et Code 9** (C.1-Annex A, art. 2.3, 4.5 a, 6.2, 6.3, 6.5, 10.3 ; Code 9, art. 6.7). L’ordre de production est une échelle à cinq niveaux avec la même formule pour le Panier matériel ; chaque Cercle 2 a au moins un Atelier avancé pour trois ou quatre Communautés, activé par le Conseil Production partagé ; « cluster » et « bassin » disparaissent. Raison : termes non définis et un « niveau 5 » qui n’existait pas.
- **C45. Niveau 2 des compétences** (Code 5, art. 4.2 b). Il est confirmé par deux personnes déjà validées au moins au Niveau 2 dans la même compétence, y compris d’autres Communautés ; le Conseil des Compétences l’enregistre. Raison : le « Cercle de pratique » n’existait pas.
- **C46. Sigles L1–L3 et classes R0–R4** (Code 5, nouvel art. 4.2-bis). Les sigles désignent les Niveaux du Code 5 ; un tableau relie les classes de risque du Code 14 aux Niveaux requis ; la formation à la sécurité s’ajoute à la validation. Raison : les deux systèmes n’étaient pas reliés.
- **C47. Trois figures de référence** (Const. 29.3). Elles reviennent aux mineurs ; les adultes apprennent avec l’accompagnement ordinaire. Raison : aligne la Constitution sur le Code 5, art. 6.7 et les alinéas 29.4–29.5.
- **C48. Cercle de garantie : autres fonctions et recours au-dessus du Cercle 1** (Code 4, art. 4.2 d et 27.6 ; Code 6, art. 2-bis.4 d ; Code 3, nouvel art. 17.1-bis). Le Cercle de garantie exerce aussi les fonctions confiées par les autres Codes ; le recours contre les décisions des Cercles 2 et 3 est tranché par trois membres tirés au sort dans les Cercles de garantie de Communautés différentes, et la décision vaut pour toutes. Raison : la Const. 31.3 d) ne connaît que le Cercle de garantie de la Communauté.
- **C49. Mineurs : sortie de la Confédération et choix de résidence** (Const., nouvel art. 26.5 ; Code 12, nouvel art. 7-ter ; Code 4, art. 37.6). Dès seize ans, le mineur déclare lui-même sa sortie, après un entretien avec le Conseil Soin dans les quatorze jours ; avant, la déclaration est faite par qui en a la responsabilité de soin, uniquement dans son intérêt et après l’avoir entendu, et elle ne s’étend pas aux enfants de qui sort ; le Tribunal de garantie peut être saisi dans les quatorze jours. Dès quatorze ans, le mineur autonome peut choisir où vivre, avec l’évaluation du Conseil Soin et du Conseil des Compétences dans les trente jours et le recours au Tribunal. Les garanties des Const. 1.3 et 4.9-bis restent toujours. Raison : les Const. 4.8 et 26.2 ne disaient pas comment elles s’appliquent aux mineurs ; les âges sont le choix de l’auteur (seize comme le consentement aux soins, quatorze comme le vote).
- **C50. Énergie minimale** (Code 8, art. 2.4). Elle n’est réduite qu’en cas d’impossibilité matérielle, pour une durée limitée, avec l’entraide et l’avis au Cercle de garantie ; l’« urgence extrême » seule ne suffit pas. Raison : Const. 15.2 et 36.4.
- **C51. Eau rare : qui décide** (Code 10, art. 8.2). Le Conseil Énergie et Eau applique l’ordre du Code 9, art. 10.8 ; retirer de l’eau ou d’autres biens du Panier est un rationnement et l’Assemblée le décide, ou la procédure d’urgence. Raison : un Conseil ne décide pas à la place de l’Assemblée (Const. 6.6).
- **C52. Zone tampon des abeilles** (Code 10, art. 2.6 ; Code 9, art. 9.1 g ; Code 13, art. 6.3 c). Les produits systémiques ne sont jamais admis ; en urgence extrême, l’Assemblée n’admet pour peu de temps que des produits non persistants et non systémiques ; le secours aux colonies suit le seul Code 9. Raison : deux procédures pour la même chose.
- **C53. Énergie essentielle pour tous** (Code 8, art. 4.2). Garantie à quiconque se trouve sur le territoire, membre ou non, comme l’eau potable. Raison : la Const. 15.2 n’est pas limitée aux membres.
- **C54. Prévention des naissances des animaux domestiques** (Code 13, art. 7.10). La stérilisation pour le bien-être de l’animal ou pour la capacité de soin, indiquée par un vétérinaire et décidée par qui vit avec l’animal, n’est pas une manipulation reproductive ; personne ne l’impose à tous. Raison : règle interprétative décidée par l’auteur sur la Const. 13.2–13.3.
- **C55. Faune sauvage** (Code 13, nouvel art. 5-bis et art. 3.2 c). Contre les dégâts et les risques, seulement des méthodes non sanglantes : prévention, dissuasion, clôtures et, si nécessaire, capture sans douleur et déplacement ; le Conseil Biodiversité décide, après avoir entendu le Conseil agroécologique pour les dégâts aux champs ; la méthode figure dans une nouvelle STV. Raison : le « prélèvement non sanglant » de la Const. 13.4 n’était pas réglé.
- **C56. Euthanasie des animaux des sanctuaires** (Code 13, art. 4-bis.7). Mêmes conditions que pour les animaux domestiques, avec la fiche du sanctuaire et l’information de qui les soigne. Raison : le renvoi menait à des outils qui n’existent que pour les animaux domestiques.
- **C57. Cession d’un animal** (Code 13, art. 7.6 d). Aucun remboursement entre membres ; avec l’extérieur, seulement les frais de soin documentés, par la Caisse commune. Raison : Const. 3.5 et 3.5-bis.
- **C58. Structures « toutes les trois ou quatre Communautés » et « bassin territorial »** (Code 13, art. 4.1, 4-bis.5, 11.3 c ; Code 12, art. 6.3 ; Code 9, art. 6.4 ; Code 10, art. 1.2 g et nouvelle h). Sanctuaires, structures de soin et infrastructures agricoles se comptent dans chaque Cercle 2 ; le « bassin territorial » est défini comme le territoire du Cercle 2. Raison : le « bassin » n’était pas défini.
- **C59. « Assemblée technique » du dispatching** (Code 8, art. 3.3 d). C’est le Conseil Énergie et Eau ; la commande manuelle locale reste selon les règles existantes. Raison : le terme de la Const. 15.3 n’était pas mis en œuvre.
- **C60. Eau sous 50 litres par personne** (Code 8, nouvel art. 4-bis.6). Admise seulement pour une impossibilité technique temporaire, décidée par l’Assemblée ou par la procédure d’urgence, avec demande d’aide, demande éventuelle du Protocole de solidarité et avis au Cercle de garantie ; l’eau de boisson et pour la santé est réduite en dernier. Raison : les mêmes garanties que pour l’énergie (Code 8, art. 2.5).
- **C61. Admission des biens de faible valeur** (Code 2, art. 15.1 a). Le Conseil Qualité instruit et propose ; l’organe de la matrice du Code 3 décide ; il est dit quel Conseil est le « Cercle de compétence » d’un bien. Raison : trois règles désignaient trois organes différents (la première partie du point, au Code 3, art. 3.2 a, date du 20 octobre).
- **C62. Vérification d’usage des biens** (Code 2, art. 3.2 et nouvel art. 14.1-bis). La STV provisoire est publiée pendant au moins soixante-douze heures ; pour les biens qui ne sont pas simples ou pas sûrs, on entend aussi quelques utilisateurs ; lors d’un essai dans un Garde-manger pilote, on recueille les avis ; le Conseil des Entrepôts donne un avis non contraignant. Raison : la Const. 9.2 veut dans la validation ceux qui utilisent le bien et ceux qui gèrent l’Entrepôt.
- **C63. Carte du Pool mondial** (Code 15, art. 8.1). Elle est établie par l’IA de chaque Cercle intermédiaire pour son territoire ; les cartes s’échangent par des protocoles ouverts ; aucun système ne les réunit dans un seul modèle. Raison : Const. 22.2.
- **C64. Révision obligatoire de l’IA** (Code 7, art. 5-ter.5). Trois refus du même Cercle sur la même matière, de n’importe quel organe, sans la limite des douze mois. Raison : la Const. 19.6 relève du Noyau et ne prévoit pas ces limites.
- **C65. Vote électronique et signatures de l’Objection** (Code 7, nouvel art. 7-bis ; Code 3, art. 12.2, 13-bis.1, 13-bis.4, 13-bis.6). Registre des ayants droit séparé de l’urne, logiciel ouvert, aucun journal qui lie la personne et le vote, dépouillement par Communauté, jamais de systèmes fermés ; l’Objection peut être signée par quiconque a le droit de vote, même sans avoir voté, avec 10 % des votants et des signatures anonymes ; après confirmation aux deux tiers, elle ne peut pas être présentée de nouveau sur la même partie. Raison : Const. 34.2 et 34.4, avec les choix de l’auteur.
- **C66. Nœud-IA personnel et commun** (Const. 3.1, 3.4, 5.1 a, 8.2, 14.5 ; Code 7, art. 5-bis.1). Sont Biens communs les Nœuds-IA de Communauté et de Cercle ; le Cercle 0 a un Nœud personnel pour chacun de ses membres ; « IA-Logistique » devient « IA de Communauté et de Cercle » ; le CdR et la traçabilité des déchets utilisent le Nœud de Communauté ; le Nœud personnel est une propriété personnelle (Const. 10.3). Raison : les art. 3.1 et 5.1 a) contredisaient les art. 1.2 d) et 19.1. Les modifications des art. 3.1 et 5.1 a), dans le Noyau, sont de purs alignements de mots et donc des corrections matérielles (Const. 37.5).
- **C67. Annexe B : phases et Caisse juridique** (Annexe B, art. 5.7, 6.1, 8.6). Chaque élément s’active dans la phase où le Code 16 le prévoit ; quand la Caisse juridique est épuisée, seules les initiatives de l’Annexe s’arrêtent, sans que cela compte comme un seuil manqué. Raison : l’Annexe mêlait des éléments de phases différentes.
- **C68. Sécurité perçue sous 80 %** (Annexe B, art. 8.3 a et 8.5). On suit seulement la procédure de l’Annexe A, art. 4.6 ; si seule la proposition de passage s’était arrêtée, elle repart sans autre délibération. Raison : deux procédures sur la même condition.
- **C69. Point de non-retour** (Code 16, art. 5.5). Il renvoie à la réversibilité (art. 2.2), aux règles sur les biens communs (art. 6) et à l’avis L3 externe (Annexe A, art. 4.7). Raison : le renvoi menait à un article qui traite d’autre chose.
- **C70. Renvois du Code 16 et Annexes** (Code 16, art. 1.2 i, 3.1 b, 10.3 b et nouveaux 1.8 et 1.9). L’échelle R0–R4 est celle du Code 14 ; le Code 6 s’applique en entier dès la Phase 0 ; les normes impératives sont celles auxquelles aucun organe ne peut déroger ; chaque Annexe, ou sa partie pour une phase, est approuvée par l’Assemblée de l’échelle à laquelle elle s’applique ; les renvois à des Codes pas encore actifs s’appliquent dans la mesure où ils sont applicables, sous réserve des garanties constitutionnelles. Raison : des renvois erronés ou vagues et une approbation des Annexes pensée pour le seul Cercle 1.

Raison : Ce sont les corrections proposées par la vérification de cohérence pour les points de gravité faible, avec les choix de l’auteur sur C49 (choix de résidence dès quatorze ans), C37 (une Communauté pas encore dans un Bassin n’active pas seule le Protocole), C66 (aussi les Const. 3.1 et 5.1 a, comme correction matérielle) et C70 (Annexes approuvées par l’Assemblée de l’échelle à laquelle elles s’appliquent). Les autres modifications de la Constitution (art. 3.4, 7.3, 8.2, 14.5, 26.5, 29.3, 30.2, 31.3) ne touchent pas le Noyau inviolable et valent comme texte de la première adoption (Const. 38.1). Avec ce point, les 76 points de la vérification de cohérence sont tous résolus.

Vérification : [vérification de cohérence, points de gravité faible](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#gravità-bassa).

Versions : Constitution de V.32 à V.33, Code 1 de V1.8 à V1.9, C.1-Annex A de V1.5 à V1.6, Code 2 de V1.6 à V1.7, Code 3 de V1.6 à V1.7, Code 4 de V1.7 à V1.8, Code 5 de V1.5 à V1.6, Code 6 de V1.7 à V1.8, Code 7 de V1.8 à V1.9, Code 8 de V1.5 à V1.6, Code 9 de V3.2 à V3.3, Code 10 de V1.6 à V1.7, Code 12 de V1.5 à V1.6, Code 13 de V1.6 à V1.7, Code 14 de V1.5 à V1.6, Code 15 de V1.5 à V1.6, Code 16 de V1.5 à V1.6, Annexe B du Code 16 de V1.5 à V1.6, Annexe C du Code 16 de V1.1 à V1.2.

## 20 octobre 2026 — points de gravité moyenne de la vérification de cohérence (C8–C28)

Les vingt et un points de gravité moyenne de la vérification de cohérence sont corrigés directement, par décision de l’auteur. Pour chaque point : ce qui change et pourquoi.

- **C8. Communauté d’accompagnement** (Code 4, art. 30.3). C’est une Communauté ouverte, sans périmètre protégé et sans surveillance du Corps de protection civique, distincte de la Communauté de confinement ; la personne a l’obligation d’y séjourner et un accompagnement quotidien, elle n’est pas retenue par la force et, si elle part, le Tribunal de garantie décide. La durée maximale (cinq ans pour le Degré 5, dix pour le Degré 6) est une limite ferme. Raison : sans définition, la mesure pouvait devenir un Confinement de haute sécurité sans récidive, que la Const. 1.3-bis interdit.
- **C9. Justice en Phase 0** (Code 4, art. 37.5 ; Code 16, art. 8.6). Le collège tiré au sort hors du Cercle pilote vaut aussi lorsqu’aucun Bassin n’existe encore, aussi pour le second Tribunal et pour le Cercle de garantie de remplacement, avec des dérogations expresses aux règles sur la même Communauté ; qui procède au réexamen ne peut pas être qui a décidé. Raison : l’alinéa ne couvrait que le Bassin incomplet.
- **C10. Enregistrements du Corps** (Code 14, art. 8-quater.3). La personne visée par l’intervention est elle aussi masquée ; la version intégrale n’est vue que par ceux qui valident, par les organes de justice compétents et par la personne pour la partie qui la concerne. Raison : la personne est présumée non responsable (Const. 17.6 ; Code 4, art. 14.3).
- **C11. Avis contraignants** (Const. 6.6 ; Code 3, art. 7-ter.2, 7-quater.2 a, 8.1, 12-bis.9 ; Code 4, art. 4.6 b ; Code 9, art. 6-bis.3 c, 4 c, 5 d, 7.3 ; Code 10, art. 4.4 d ; Code 13, art. 3.2 c, 3.3, 3.5, 6.6 ; Code 14, art. 3.6 ; Code 16, art. 8.3). L’article 8 du Code 3 devient la liste fermée des avis contraignants négatifs : Santé, Réseau, Sécurité et, pour les limites écologiques que la Const. 6.6 nomme désormais, agroécologique et Biodiversité. Le bien-être des animaux qui cohabitent ou collaborent avec les personnes ne passe plus par un « avis contraignant », mais par l’autorisation que la Const. 13.3 donne déjà au Conseil Biodiversité. Raison : le Code 3 oubliait la Sécurité et d’autres Codes donnaient des avis contraignants que la Constitution ne prévoyait pas.
- **C12. Hiérarchie des priorités** (Code 1, art. 2.8 a, 32.1-ter, 32.1-quater, 32.4 ; Code 6, art. 7.2–7.3 ; Code 8, art. 2.3 ; Code 11, art. 2.4–2.5 ; Code 12, art. 2.4, 4.7). L’article 32 du Code 1 vaut pour tous ; les échelles des Codes sectoriels n’ordonnent que leur propre secteur et le niveau 1 est toujours le plus élevé. Le soin des personnes fragiles passe avant les biens périssables, mais pas avant les aliments du Panier ; les pièces de rechange passent après le Panier de tous, sauf la dérogation d’urgence de l’art. 32.3. Raison : les Codes sectoriels réécrivaient la hiérarchie de manières différentes.
- **C13. « Niveaux 1 et 2 du Panier »** (Code 1, art. 32.1-quinquies ; Code 16, art. 1.2 f ; Code 16, Annexe C, art. 6.1 ; Code 11, art. 1.4 d–e ; C.1-Annex A, art. 2.3 a). Une seule définition, dans le Code 1, pour l’énergie, les aliments, le soin et les autres biens du Panier ; les autres textes y renvoient. Raison : la définition ne figurait que dans le Code 16, elle était incomplète et « niveau » désignait aussi les Cercles.
- **C14. Jeunes de dix-huit ans qui n’ont pas encore choisi** (Code 5, art. 6.2, 6.6 et nouvel 6.6-bis ; Code 4, art. 29.3 e). Jusqu’au choix de la Const. 26.4, la CBO reste volontaire et la procédure pour refus ne peut pas être engagée ; le Conseil des Compétences informe la personne au moins trois mois avant ses dix-huit ans et le délai ne court pas sans information. Raison : aucun Code ne mettait en œuvre la Const. 26.4.
- **C15. Déplacements dans la CBO** (Code 1, art. 25.5 et 43.2). Le trajet imposé par la CBO compte comme heures de CBO et ne donne pas de CdR ; la majoration ne vaut que pour les déplacements au-delà de la CBO. Raison : dans la CBO, la Const. 8.1 n’admet de CdR que pour les tâches désagréables, pénibles ou de nuit.
- **C16. Excédents** (Code 1, nouvel art. 15.1-bis ; Code 15, art. 6.2 et 15.3). Lorsque le Solde est actif, l’excédent fédérable va d’abord au Pool ; le don direct, le réemploi et la cession à l’extérieur valent pour le reste. Raison : les Codes 1 et 15 donnaient deux règles différentes pour les mêmes biens.
- **C17. Pool et Solde** (Code 15, art. 3.1–3.3, 9.2 c et nouvel art. 9-bis ; Code 3, art. 12-bis.2 ; Code 16, art. 3.2 g et 3.3 c). Chaque Cercle 2 et 3 a un Conseil des Entrepôts tiré au sort qui décide des affectations du Pool dans le cadre des critères annuels de l’Assemblée générale, en 24 heures pour les besoins vitaux ; le Solde ne se déclare plus au « niveau 4 ». Raison : aucun organe ne décidait au-dessus du Cercle 1.
- **C18. Le logement de qui s’en va** (Const. 3.3 ; Code 1, art. 47.3 et nouvel 47.3-bis). L’habitation est un Bien d’usage personnel tant que dure la propriété d’usage ; avec le transfert, la sortie de la Confédération ou la cessation du statut, le logement est libéré, dans les délais déjà prévus, et qui vit dans le même Cercle 0 peut y rester. Raison : il n’était pas dit si qui s’en va garde le logement.
- **C19. Attribution des logements** (Code 1, nouvel art. 47-ter). Plan annuel proposé par le Conseil des Entrepôts et approuvé par l’Assemblée ; attribution selon le besoin, jamais selon les heures de CBO, les CdR ou les charges ; liste d’attente publique et anonyme ; personne ne reste sans abri ; recours devant le Cercle de garantie. Raison : la « planification du logement » de la Const. 3.7 n’avait pas de procédure.
- **C20. Eau rare** (Code 9, art. 2.5, 6-bis.2, 10.8 ; Code 8, art. 4-bis.5 ; Code 13, art. 4-bis.6, 7.11). Une seule règle, au Code 9, art. 10.8 : d’abord l’eau potable pour les personnes (quota minimal) et pour les services de santé et de soin ; puis, à égalité et répartie en proportion du besoin, l’eau minimale pour la survie des animaux et des pollinisateurs et l’eau minimale pour les champs du Panier essentiel ; les autres usages sont réduits en premier. Le nombre des animaux est planifié sur l’eau des années sèches et, avant de laisser un animal sans eau, on demande par le Pool l’eau ou le transfert dans une autre Communauté ; tant que le Pool n’existe pas (Phase 0), le transfert est tenté directement avec une autre Communauté ou une entité extérieure apparentée, par accord écrit. Raison : les Codes 9 et 13 et la clause « le Code 1 prévaut » donnaient des réponses opposées ; le choix est celui de l’auteur.
- **C21. STV autres que pour les biens** (Code 2, art. 1.3 et nouvel art. 3-bis ; Code 7, art. 6.5 ; Code 12, art. 1.2 g ; Code 14, art. 1.2 b). Les STV des procédures, services, automatisations, systèmes et sécurité suivent la matrice du Code 3, avec le coût sur deux ans comme valeur ; qui rédige une STV ne peut pas l’approuver seul ; la criticité d’une automatisation est validée par deux personnes L3, dont une indépendante. STV signifie toujours « Fiche technique de validation ». Raison : la procédure n’était écrite que pour les biens.
- **C22. Cloud et logiciels fermés** (Const. 19.4 ; Code 2, art. 5.2 b et nouvel 12.5 ; Code 7, art. 3.9 et 5.5 ; Code 11, art. 5.7 ; Code 16, nouvel art. 9-bis). La Constitution permet aux Codes d’admettre, pour une durée limitée et avec un Plan de substitution public, des systèmes dont le code source n’est pas disponible, à l’exclusion de ceux qui proposent ou décident en matière de droits, de vote et de Biens communs ; le Code de la transition régit, jusqu’à la clôture, les systèmes hébergés à l’extérieur et les modèles d’IA non open source. Le véhicule qui dépend d’un cloud obligatoire n’a plus la dérogation de douze mois et les IA de gestion emploient des modèles open source. Raison : la Const. 19.4 n’admettait pas les dépendances résiduelles que le Code 2 admet ; l’auteur a choisi de l’écrire dans la Constitution (option B).
- **C23. IA de gestion** (Code 7, art. 5.1). Elle peut exercer toutes les fonctions d’appui prévues par la Constitution et par les Codes, toujours sous forme de proposition ; la liste des interdictions reste fermée. Raison : la liste « exclusive » excluait des fonctions que d’autres textes lui confient.
- **C24. IA des Cercles 2 et 3** (Code 3, art. 12-bis.6 b et nouvel 12-bis.6-bis ; Code 7, nouvel art. 4.7). Un schéma unique de Conseil commun des Cercles 2 et 3 (personnes tirées au sort parmi les Conseils des Communautés, seulement des actes techniques et des décisions urgentes à ratifier dans les trente jours, décisions discrétionnaires à l’Assemblée générale, révocation par la Communauté d’origine) ; le Conseil Réseau commun gère les nœuds et les IA des Cercles 2 et 3 et chaque Communauté garde la reprise en main manuelle. Raison : aucun organe ne gérait ces IA.
- **C25. Logistique des Cercles 2 et 3** (Code 11, nouvel art. 6-quater). Un Conseil Logistique commun gère les fourgons, les caravanes et le cabotage du Cercle 2 avec une règle écrite pour partager le temps des moyens ; pour le chemin de fer du Cercle 3, un protocole approuvé par son Assemblée générale. Raison : les moyens partagés n’avaient pas d’organe.
- **C26. Après la clôture de la transition** (Code 4, nouvel art. 37.6 ; Code 16, art. 10.2 a). Là où s’applique la loi d’un État, les garanties de la transition demeurent ; le Code 16 cesse de s’appliquer seulement pour la Fédération qui a clos. Raison : avec la clôture tombaient des garanties liées à la loi de l’État, qui demeure.
- **C27. Naissance du Cercle étendu** (Code 3, nouvel art. 14-bis ; Code 16, art. 1.5 et 1.7). La Fédération minimale devient Cercle étendu lorsqu’elle clôt sa propre transition ; plus tard, trois Cercles 2 ou plus peuvent en constituer un ; la date est enregistrée et compte pour le régime de fondation (Const. 38.2–38.3). Raison : aucun texte ne disait comment naît un Cercle étendu (option A du projet).
- **C28. Échelle des phases** (Code 16, art. 1.2 a, 1.3, nouvel 3.7, 4.5, 5.1, 10.1 ; Code 15, art. 21.1). La Phase 0 est propre à chaque Cercle pilote, la Phase 1 à chaque Bassin, les Phases 2 à 4 à chaque Fédération minimale ; qui arrive plus tard part de la Phase 0 et entre dans la phase du groupe quand il en atteint les seuils ; chaque échelle a son Conseil Transition. Raison : il n’était pas dit à quelle échelle valent les phases.
- **Code 3, art. 3.2, lettre a)**. Pour les décisions d’allocation à risque faible décide l’organe de la matrice de l’art. 7 : le Cercle de compétence si la valeur est faible, le Conseil Qualité avec le Cercle de compétence si elle est moyenne. Raison : simple incohérence de texte avec la matrice, relevée pendant le travail (première partie du point C61, gravité faible).

Raison : Ce sont les corrections proposées par la vérification de cohérence pour les points de gravité moyenne, avec les choix de l’auteur sur C20, C22 (option B), C27 (option A), sur la priorité du soin (il reste après la livraison ordinaire du Panier, sauf l’échange avec les biens périssables), sans ajout sur C8 ni échéance propre sur C11. Les modifications de la Constitution (art. 3.3, 6.6 et 19.4) ne touchent pas le Noyau inviolable et valent comme texte de la première adoption (Const. 38.1).

Vérification : [vérification de cohérence, points de gravité moyenne](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#gravità-media).

Versions : Constitution de V.31 à V.32, Code 1 de V1.7 à V1.8, C.1-Annex A de V1.4 à V1.5, Code 2 de V1.5 à V1.6, Code 3 de V1.5 à V1.6, Code 4 de V1.6 à V1.7, Code 5 de V1.4 à V1.5, Code 6 de V1.6 à V1.7, Code 7 de V1.7 à V1.8, Code 8 de V1.4 à V1.5, Code 9 de V3.1 à V3.2, Code 10 de V1.5 à V1.6, Code 11 de V1.4 à V1.5, Code 12 de V1.4 à V1.5, Code 13 de V1.5 à V1.6, Code 14 de V1.4 à V1.5, Code 15 de V1.4 à V1.5, Code 16 de V1.4 à V1.5, Annexe C du Code 16 de V1.0 à V1.1.

## 20 octobre 2026 — Constitution, nouvel art. 17.9 ; Code 14, art. 1, al. 1, et nouvel art. 8-sexies ; Code 4, art. 25, al. 1 ; art. 26, al. 3 ; nouvel art. 26-bis (défense personnelle)

Défense personnelle. Toute personne peut se défendre, défendre d’autres personnes et les animaux sans armes, en se soustrayant, en mettant en sécurité, en s’interposant et, si cela ne suffit pas, avec la seule force strictement nécessaire et proportionnée pour faire cesser le danger. Cela vaut contre une agression physique ou sexuelle en cours ou imminente, lorsque le danger est concret et immédiat et non seulement redouté, et contre une maltraitance en cours qui blesse un animal ou le fait souffrir ; les désaccords sur la manière de soigner ou d’éduquer un animal ne justifient pas la force et relèvent du Conseil Biodiversité. Les objets trouvés sur place peuvent toujours être utilisés pour se protéger ; pour frapper, seulement en cas de danger pour la vie, de blessures graves ou de violence sexuelle, et seulement pour arrêter l’agression (description corrigée le 26 octobre 2026 : la règle avait été ainsi précisée après la première rédaction de cette entrée ; pour les Biens communs vitaux, voir l’entrée du 26 octobre 2026). Ne sont pas une défense l’attaque, la vengeance, la punition, la force après que le danger a cessé, la force sur les personnes pour protéger de simples biens et la force pour corriger, éduquer ou retenir une personne avec qui l’on vit. On n’entre sans consentement dans le Cercle 0 d’autrui que pour faire cesser une violence physique ou sexuelle en cours, en avertissant aussitôt le Corps de protection civique, en sortant dès que le danger a cessé et sous le contrôle du Tribunal de garantie dans un délai de vingt-quatre heures. Après le fait, on porte secours et on avertit le Corps ou le Cercle de garantie ; c’est le Tribunal de garantie qui examine. L’erreur due à une peur excusable n’est pas une infraction ; l’excès est de Degré 4, ou de Degré 2 si le dommage est léger ; pour les mineurs, seules des mesures réparatrices et éducatives s’appliquent. Pendant la transition, la loi de l’État s’applique, et qui a adhéré s’engage à rester dans les limites plus strictes de ces règles.

Raison : Les textes confiaient la protection au seul Corps de protection civique et voulaient une défense « désarmée et non violente », mais ne disaient pas si et comment une personne peut se défendre ou défendre autrui quand le Corps n’est pas là. Le nouvel article 17.9 se trouve dans l’article 17 et non dans l’article 16, qui fait partie du Noyau inviolable ; la Const. 5.1, lettre a), qui en fait aussi partie, ne change pas : l’entrée dans un Cercle 0 utilise l’exception qu’elle prévoit déjà « selon le Titre VIII », mise en œuvre par le Code 4, art. 26-bis.

Versions : Constitution de V.30 à V.31, Code 4 de V1.5 à V1.6, Code 14 de V1.3 à V1.4. Les modifications de la Constitution valent comme texte de la première adoption (Const. 38.1).

## 19 octobre 2026 — Constitution, art. 1.3, 2.2, 2.3, 4.9-bis et 7.1, nouvel art. 7.3-bis, art. 37.4, lettre a) ; Code 4, art. 13, al. 6 ; art. 25, al. 1 et 6 ; art. 29, al. 1 et 6, et nouveaux al. 4-bis et 6-bis ; Code 1, art. 13, al. 3 ; art. 18, al. 1, lettre a) ; art. 44, al. 6 (points C1 et C1-bis)

Refus de la CBO. Avant le Degré 3, l’Assemblée de clarification entend la personne, examine d’autres tâches, propose une médiation et l’informe du Pacte de cohabitation autonome ; ce n’est que si, après au moins quatorze jours, tout cela n’a pas abouti qu’elle peut suspendre la CdR et l’accès aux ressources non essentielles, pour une durée limitée et avec un recours devant le Collège de réexamen, sans toucher au Panier, au logement, aux soins ni au vote. Si le refus continue sans justification même après le Plan de transformation du Degré 3, le Tribunal de garantie peut déclarer, à six voix sur sept, la cessation du statut de membre : la personne ne reçoit qu’une parcelle de terre avec l’eau, sans habitation et sans biens de la Communauté, conserve l’eau potable et les soins d’urgence vitale et peut revenir à tout moment en reprenant la CBO. Les enfants restent membres avec tous leurs droits et le Tribunal décide avec qui ils vivent. La maladie, le handicap, l’âge, la grossesse et l’objection de conscience ne sont jamais un refus.

Modification du Noyau inviolable (C1-bis). Les articles 1.3, 2.2, 2.3, 4.9-bis et 37.4, lettre a), de la Constitution font partie du Noyau inviolable ou y sont liés : le 1.3 nomme le nouvel article 7.3-bis parmi les exceptions à la garantie des droits ; le 2.2 et le 2.3 disent que la CBO n’est pas le prix des biens pris un à un, mais la contribution due comme condition de l’appartenance ; le 4.9-bis dit que, dans ce cas, la terre est donnée sans habitation ; le 37.4 a) interdit d’étendre l’exception. Restent pour quiconque l’eau potable, les soins d’urgence vitale et la protection des mineurs. Le Noyau ne peut pas être révisé (Const. 37.4 et 38.4) : il ne s’agit pas d’une révision, mais d’une réécriture du texte faite par l’auteur avant toute adhésion, possible parce que la Constitution n’est encore en vigueur pour aucune Communauté (Const. 38.1). Après la première adhésion, ce ne serait plus possible. Pourquoi : l’auteur a choisi de modifier ouvertement le Noyau au lieu de faire reposer la cessation sur un renvoi indirect à l’article 4.8, qui aurait laissé le nouvel article 7.3-bis en contradiction avec les mots du 1.3, du 2.3 (« la CBO n’est pas la contrepartie individuelle des droits ») et du 4.9-bis.

Raison : La Constitution permettait de suspendre la CdR avant le Degré 3, mais le Code 4 l’interdisait et aucun texte ne disait qui décide, combien de temps dure la suspension ni comment former un recours. L’auteur a en outre décidé que le refus persistant après le Degré 3 entraîne la cessation du statut de membre, avec la seule terre et l’eau.

Vérification : [vérification de cohérence, point C1](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c1-sospensione-del-cdr-prima-del-grado-3).

## 19 octobre 2026 — Code 10, nouvel art. 4-bis ; art. 4, al. 1, nouvelle lettre i) ; art. 10, al. 3, nouvelle lettre f) ; Code 4, nouvel art. 32-bis et art. 37, al. 1 ; Code 11, art. 6-ter, al. 4 (point C2)

Pacte de cohabitation autonome. Le nouvel article 4-bis du Code 10 dit qui conclut le Pacte, ce qu’il contient, comment la capacité de charge est documentée et comment former un recours. Chaque Cercle 1 réserve au Pacte une part de terre pour au moins une personne pour cent résidents ; s’il n’y a pas de place, le Cercle 2 puis le Cercle 3 la cherchent et, entre-temps, la personne est accueillie même au-delà de quatorze jours. Le nouvel article 32-bis du Code 4 remplace, pour qui vit au moyen du Pacte, les mesures réservées aux membres par la révision du Pacte et fixe la procédure non violente d’éloignement de l’habitat commun prévue par l’article 4.9-ter de la Constitution.

Raison : Le Pacte est un droit du Noyau inviolable, mais aucun Code n’en fixait le contenu, l’organe, la terre et les procédures, et le Code 4 appliquait la déchéance du statut à qui n’est pas membre.

Vérification : [vérification de cohérence, point C2](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c2-patto-di-convivenza-autonoma-e-persone-non-membri-manca-la-disciplina).

## 19 octobre 2026 — Code 14, art. 8-ter, al. 3 ; Code 12, art. 7-bis, al. 3, et nouveaux al. 3-bis et 3-ter ; Code 4, art. 27, al. 6 (point C3)

Cercle 0 et protection des mineurs. Le Corps de protection civique peut entrer dans un Cercle 0 aussi pour faire cesser une violence physique ou sexuelle en cours, avec la validation du Tribunal de garantie dans un délai de vingt-quatre heures, ou avec une autorisation motivée du Tribunal. Un mineur peut être séparé de son Cercle 0 même sans danger immédiat, sur décision du Cercle de garantie proposée par le Conseil Soin et validée dans un délai de vingt-quatre heures. Le Tribunal prend la décision stable sur les personnes avec qui vit le mineur dans un délai de trente jours, prolongeable une seule fois de trente jours, après l’avoir entendu, et la réexamine au moins tous les six mois.

Raison : Le Corps ne pouvait entrer qu’en cas de danger pour la vie et, après la validation de la séparation, aucun texte ne disait qui décide où vit le mineur et pour combien de temps.

Vérification : [vérification de cohérence, point C3](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c3-cerchio-0-chi-può-entrare-e-chi-protegge-i-minori).

## 19 octobre 2026 — Code 4, art. 25, al. 9 ; art. 37, al. 3 (point C4)

Mineurs. Une personne de moins de dix-huit ans ne peut jamais être placée en confinement protecteur. Si elle est dangereuse pour autrui, le Tribunal de garantie, par la décision définitive sur un fait de Degré 4, 5 ou 6 et à six voix sur sept, peut ordonner un accueil éducatif protégé, ouvert et sans surveillance, pour douze mois au plus, renouvelable une fois et réexaminé au moins tous les trois mois.

Raison : Le Code 4 excluait pour les mineurs les articles 31, 32 et 33, mais pas le confinement protecteur de l’article 30, alinéa 3.

Vérification : [vérification de cohérence, point C4](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c4-minorenni-il-contenimento-protettivo-non-è-escluso).

## 19 octobre 2026 — Code 6, art. 2, al. 2 ; art. 2-bis, nouveaux al. 3-bis, 3-ter, 3-quater et 3-quinquies, al. 4, lettre d), et al. 7 ; art. 11, al. 2, lettre d), et al. 5, lettre d) ; Code 13, art. 7, al. 10 ; Code 14, art. 8-ter, al. 4 (point C5)

Épidémies. Aucun traitement, test ou vaccination ne peut être pratiqué sur le corps d’une personne sans son consentement. Qui refuse la protection indiquée ne peut être exclu que des tâches et des lieux à risque et reçoit une autre tâche ; il conserve le Panier, le logement, les soins et le vote. L’isolement et la quarantaine durent au plus quatorze jours, prolongeables une fois ; si la personne n’est pas d’accord, le Tribunal de garantie les valide dans un délai de vingt-quatre heures. La liste des mesures collectives admises est fermée.

Raison : Le Code 6 faisait une exception au consentement pour les mesures de l’article 2-bis sans dire quelles mesures étaient admises. L’auteur a décidé qu’aucun traitement sanitaire ne peut être imposé.

Vérification : [vérification de cohérence, point C5](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c5-epidemie-non-è-detto-se-un-trattamento-si-possa-imporre).

## 19 octobre 2026 — Code 6, art. 8, al. 6, lettre c), et al. 7 et 10 ; Code 12, art. 9, al. 1, lettre g) (point C6)

Crise psychique. Toute mesure coercitive doit être validée par le Tribunal de garantie dans un délai de vingt-quatre heures, sinon elle prend fin ; l’Assemblée ne décide plus. Elle dure au plus soixante-douze heures à la fois et quatorze jours au total, elle est réévaluée par les personnes soignantes à échéances fixes et peut être révoquée à tout moment sur demande. Une nouvelle mesure n’est possible que pour un nouvel épisode, avec d’autres personnes soignantes et un Tribunal dans une autre composition, et jamais au-delà de vingt-huit jours sur quatre-vingt-dix. Le représentant ne peut pas consentir à une mesure coercitive.

Raison : Le contrôle revenait au Cercle de garantie, au-delà de vingt-quatre heures il fallait une délibération de l’Assemblée et il n’y avait pas de durée maximale.

Vérification : [vérification de cohérence, point C6](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c6-coercizione-nella-crisi-psichica-controllo-debole-e-nessuna-durata-massima).

## 19 octobre 2026 — Code 6, nouvel art. 2-ter ; art. 10, al. 7, lettre a) ; Code 12, art. 7-bis, al. 5 (point C7)

Consentement aux soins. À partir de seize ans, on décide seul de ses propres soins ; avant, décident les personnes qui ont la responsabilité de soin, après avoir entendu le mineur, dont l’avis pèse davantage avec l’âge. En cas de désaccord ou de conflit d’intérêts, le Tribunal de garantie décide, avec l’avis d’une personne soignante indépendante. Les vaccinations des mineurs ne sont jamais obligatoires. Pour l’adulte qui ne peut pas décider pendant plus de soixante jours, le Tribunal nomme un représentant stable, réexaminé chaque année.

Raison : Pour les soins ordinaires des mineurs, aucun texte ne disait qui donne le consentement, et le représentant temporaire du Code 12 était renouvelé tous les trente jours sans limite.

Vérification : [vérification de cohérence, point C7](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c7-chi-dà-il-consenso-alle-cure-di-un-minore-o-di-una-persona-incapace-in-modo-permanente).

## 19 octobre 2026 — Constitution, art. 31.3, lettre c) ; Code 4, art. 27, al. 3 ; art. 37, nouvel al. 5

Tribunal de garantie. La Constitution lui attribue, outre les infractions de Degré 4, 5 et 6 et la révision urgente, « les autres fonctions de garantie attribuées par les Codes », et le Code 4 est aligné. Pendant la Phase 0, tant que les membres ne peuvent pas être tirés au sort dans le Bassin, les fonctions du Tribunal, du Collège de réexamen et du Conseil de transformation sont exercées par un collège tiré au sort parmi des personnes formées d’autres Cercles pilotes ou d’entités apparentées ou, à défaut, parmi des membres étrangers aux faits, qui ne peut pas ordonner les mesures les plus graves ; si aucun collège n’est formé à temps, la mesure prend fin.

Raison : Les modifications des points C1 à C7 confient au Tribunal des tâches nouvelles (garde des mineurs, consentement aux soins, représentant stable, validation des mesures sanitaires, cessation du statut) que l’article 31.3 c) de la Constitution ne nommait pas, et pendant la Phase 0 le Tribunal ne pouvait pas être formé. L’article 31.3 ne fait pas partie du Noyau inviolable.

Vérification : [vérification de cohérence, points C1 à C7 et C9](https://imthezeroit.github.io/progetto-dei-cerchi/registro/verifica-coerenza.html#c9-giustizia-nella-fase-0-mancano-i-componenti-esterni).

Versions : Constitution de V.29 à V.30, Code 1 de V1.6 à V1.7, Code 4 de V1.4 à V1.5, Code 6 de V1.5 à V1.6, Code 10 de V1.4 à V1.5, Code 11 de V1.3 à V1.4, Code 12 de V1.3 à V1.4, Code 13 de V1.4 à V1.5, Code 14 de V1.2 à V1.3. Les modifications de la Constitution valent comme texte de la première adoption (Const. 38.1).

## 19 octobre 2026 — C.1-Annex A, art. 4, al. 1 et 3, et nouvel al. 1-bis ; Code 1, art. 32, nouvel al. 1-bis (proposition 1)

Vêtements et hygiène dans le Panier matériel. Le texte accepté est celui de la [proposition 1, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-1--vestiario-e-igiene-nel-paniere-materiale).

Raison : Les vêtements et les produits d’hygiène sont nécessaires à chacun, et aucun Panier ne les nommait.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 9](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/9)).

## 19 octobre 2026 — Code 1, nouvel art. 47-bis (proposition 2)

Normes du logement adéquat. Le texte accepté est celui de la [proposition 2, version 4](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-2--standard-dellalloggio-adeguato).

Raison : La Constitution garantit le logement, mais aucun texte ne disait ce qui le rend adéquat.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 10](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/10)).

## 19 octobre 2026 — Code 7, art. 3, nouvel al. 9 ; Code 5, art. 2, nouvel al. 4-bis (proposition 3)

Connectivité et matériel pour apprendre. Le texte accepté est celui de la [proposition 3, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-3--connettività-e-materiali-per-apprendere).

Raison : La connectivité est un droit, mais le Code 7 ne disait pas avec quoi on l’exerce.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 11](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/11)).

## 19 octobre 2026 — Code 8, art. 4, al. 4 (proposition 4)

Valeur de première application du Panier énergie. Le texte accepté est celui de la [proposition 4, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-4--valore-di-prima-applicazione-del-paniere-energia).

Raison : Le Panier énergie énumérait les services garantis sans aucune valeur minimale.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 12](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/12)).

## 19 octobre 2026 — Code 1, art. 43, nouvel al. 1-bis (proposition 5)

CdR pour les activités culturelles offertes à la Communauté. Le texte accepté est celui de la [proposition 5, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-5--cdr-per-le-attività-culturali-offerte-alla-comunità).

Raison : Ce qu’une personne offre à tous est une contribution ; le décompte en heures et la limite annuelle évitent qu’elle devienne un classement.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 13](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/13)).

## 19 octobre 2026 — Code 10, art. 1, al. 1, 2 et 3 ; art. 9, al. 1, lettre a) (proposition 6)

Le sous-sol, bien commun. Le texte accepté est celui de la [proposition 6, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-6--sottosuolo-bene-comune).

Raison : Aucun texte ne nommait le sous-sol et les gisements ; désormais on ne peut pas en tirer de rente.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 14](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/14)).

## 19 octobre 2026 — Code 10, nouvel art. 8-bis et art. 3 et 7 ; Code 15, art. 12, nouvel al. 5-bis (proposition 7)

Matières premières : récupération et inventaire. Le texte accepté est celui de la [proposition 7, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-7--materie-prime-recupero-e-inventario).

Raison : Avant de se demander s’il faut creuser, il faut savoir ce que l’on peut récupérer ; l’article n’autorise pas de nouvelles extractions. Code 10, art. 3 et 7 (inventaire et accès au Cadastre) alignés.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 15](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/15)).

## 19 octobre 2026 — Code 7, art. 1, al. 2, nouvelle lettre f), et nouvel art. 6-bis ; Code 1, art. 8, al. 3 (proposition 8)

Robots et machines autonomes. Le texte accepté est celui de la [proposition 8, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-8--robot-e-macchine-autonome).

Raison : Aucun texte ne réglait les machines qui agissent seules parmi les personnes. Code 1, art. 8, al. 3 aligné.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 16](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/16)).

## 19 octobre 2026 — Code 1, art. 44, al. 3 ; art. 45, al. 2 et 3 (proposition 9)

Décroissance de la CdR. Le texte accepté est celui de la [proposition 9, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-9--decrescenza-dei-cdr-quando-comincia-e-quali-si-impiegano-per-primi).

Raison : Le texte ne disait pas comment diminue la valeur des CdR ; la réduction progressive respecte à la fois les douze mois et le vingt-quatrième mois.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 17](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/17)).

## 19 octobre 2026 — Code 1, art. 44, al. 2 (proposition 10)

Plafond de la CdR et majorations. Le texte accepté est celui de la [proposition 10, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-10--la-maggiorazione-dei-compiti-sgradevoli-per-chi-è-al-tetto).

Raison : Le texte ne disait pas si le plafond vaut aussi pour les majorations, ni comment se mesure le solde.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 18](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/18)).

## 19 octobre 2026 — Code 3, art. 7, al. 3 et nouveaux al. 3-bis et 3-ter ; art. 7-bis, al. 1 ; art. 21, al. 3 (proposition 11)

Seuils économiques proportionnés à la taille de la Communauté. Le texte accepté est celui de la [proposition 11, version 2](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html#proposta-11--soglie-economiche-in-proporzione-alla-dimensione-della-comunità).

Raison : Les mêmes seuils fixes pesaient très différemment dans une Communauté de trente personnes et dans une Communauté de cinq cents. Art. 21, al. 3 aligné.

Discussion : aucune observation reçue au 19 octobre 2026 ([signalement 19](https://github.com/ImTheZeroIt/progetto-dei-cerchi/issues/19)).

Versions : Code 1 de V1.5 à V1.6, C.1-Annex A de V1.3 à V1.4, Code 3 de V1.4 à V1.5, Code 5 de V1.3 à V1.4, Code 7 de V1.6 à V1.7, Code 8 de V1.3 à V1.4, Code 10 de V1.3 à V1.4, Code 15 de V1.3 à V1.4. La Constitution reste à la V.29. Les propositions étaient ouvertes depuis le 6 octobre 2026 (la proposition 2 depuis le 19 octobre) ; quand personne ne répond, le registre le dit, au lieu d’écrire « approuvée après discussion ».

## 5 octobre 2026 — Constitution, art. 6.5 (correction matérielle)

« Dans les Communautés comptant moins de cent cinquante personnes » devient « Dans les Communautés comptant moins de cent cinquante personnes ayant le droit de vote ».

Raison : pour le même seuil, le Code 3, art. 12-bis, al. 12, compte les ayants droit au vote, tandis que la Constitution comptait les personnes. On a gardé la mesure du Code, parce que les Conseils sont composés de personnes tirées au sort parmi les ayants droit au vote : c’est leur nombre qui dit si une Communauté peut les pourvoir. La version reste V.29.

# Comment les règles changent

Depuis le 19 octobre 2026, les modifications vérifiées sont appliquées directement et enregistrées sur cette page avec la date, le texte et la raison. Les onze propositions publiées entre le 5 et le 19 octobre ont été acceptées et restent consultables dans les [archives des propositions](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/propositions.html). Chacun peut signaler un problème ou proposer une modification : voir [Comment contribuer](https://imthezeroit.github.io/progetto-dei-cerchi/fr/contribuer.html).

# Paramètres à vérifier

Ce sont des nombres proposés pour rendre les règles applicables. Tous peuvent être modifiés par procédure ordinaire. Les données et les expériences qui les confirment ou les démentent sont les bienvenues. Le registre complet, avec l’origine de chaque valeur, son incertitude et la preuve qu’il faudrait pour la confirmer ou la corriger, est sur la page [Paramètres à vérifier](https://imthezeroit.github.io/progetto-dei-cerchi/fr/regles/parametres.html). C’est un brouillon de calibrage, non adopté, qui ne modifie aucune règle.

| Paramètre | Valeur proposée | Où |
|---|---|---|
| Taille de la Communauté de base | en règle générale 30–500 personnes | Const. 5.1 |
| Quorum de l’Assemblée | 1/3 des ayants droit au vote ; 1/2 pour les décisions avec garanties spéciales (art. 7-quater) | Code 3, art. 12 |
| Conseils techniques | 3–5 personnes, un an, renouvellement échelonné, pas de nouveau tirage au sort avant 12 mois | Const. 6.5 ; Code 3, art. 12-bis |
| Cercle de garantie | 3–7 personnes, 90 jours (180 au plus dans l’année) | Code 4, art. 4 |
| Plafond de la CdR | 240 CdR | Code 1, art. 44 |
| Décroissance de la CdR | pleine valeur pendant 12 mois, puis un douzième par mois jusqu’à zéro à 24 mois | Code 1, art. 44 |
| Assemblée de clarification / Conseil de transformation / Tribunal de garantie | 7 / 5 / 7 personnes ; 6 voix sur 7 pour les mesures extrêmes | Code 4, art. 27 |
| Confinement protecteur | 5 ans au plus (Degré 5) et 10 ans (Degré 6), avec réexamen au moins tous les six mois | Code 4, art. 30, al. 3 |
| Mesures conservatoires | validation dans les 24 heures | Code 4, art. 34 |
| Panier eau | au moins 50 litres par personne et par jour | Code 8, art. 4-bis |
| Régime de fondation | 2 Communautés, 6 mois, vote dans les 30 jours, 2/3 des personnes et 2/3 des Communautés, ratification dans les 24 mois | Const. 38 |
| Réserve de la Caisse commune | pas plus de 12 mois de besoins extérieurs | Code 15, art. 17 |
| Seuil de la petite Communauté | moins de 150 personnes ayant le droit de vote | Const. 6.5 ; Code 3, art. 12-bis, al. 12 |
| Conseils de secteur | trois, de 3–7 personnes chacun ; pause entre deux mandats réduite à 6 mois | Code 3, art. 12-bis, al. 12 |
| Temps administratif | pas plus de 1/10 de la CBO totale, sur base trimestrielle | Const. 6.5 ; Code 3, art. 12-bis, al. 13 |
| Contribution sur les revenus extérieurs | 1/10 du revenu net en première application, jamais plus de 1/5 | Code 15, art. 19-bis |
| Déclaration des revenus extérieurs | par tranches, confidentielle, conservée 12 mois | Code 15, art. 19-bis |
| Choix de l’adhésion | dans les 12 mois suivant les 18 ans ; le silence vaut adhésion | Const. 26.4 |
| Fonctions critiques | au moins 3 personnes formées | Code 15, art. 12, al. 7 |
| Réexamen des accès privilégiés | trimestriel, 3 personnes tirées au sort | Code 7, art. 8, al. 8 |
| Assemblée la première année | en règle générale au moins une par mois | Annexe C, art. 4 |

Il reste aussi à mener la vérification sur des cas concrets demandée par les Codes 3 et 4.
