---
titolo: "ANNEXE TECHNIQUE B AU CODE 16 — MANUEL OPÉRATIONNEL DE DÉSENGAGEMENT ET DE FÉDÉRATION"
breve: "Annexe B au Code 16 — Manuel opérationnel de désengagement et de fédération"
versione: "V1.7"
gruppo: "allegati"
ordine: 16.2
id: "codice-16-allegato-b"
slug: "code-16-annexe-b"
licenza_dichiarata: "CC-BY-SA 4.0 e CERN OHL-S 2.0"
---

Annexe technique adoptée en application de l’article 19 du Code 3. La présente Annexe ne constitue pas une source autonome de sanctions et n’introduit pas d’obligations individuelles autonomes. Elle définit des critères et des instruments opérationnels pour la vérification des seuils institutionnels du Code 16. En cas de conflit, le Code 16 prévaut.

## Art. 1 — Nature, coordination temporelle et définitions

1.  La présente Annexe fournit des instruments opérationnels pour la transition et la fédération. Ses dispositions lient les organes institutionnels exclusivement aux fins de la vérification des seuils du Code 16 et ne peuvent pas être appliquées pour imposer des comportements individuels non prévus par les Codes ou par la réglementation applicable.

2.  La présente Annexe n’institue pas de chronologie autonome et ne modifie pas les phases du Code 16. Les durées indiquées aux articles 3–7 sont des repères opérationnels minimaux, subordonnés aux seuils et aux délibérations prévus par le Code 16 :

    a) les articles 3 et 4 mettent en œuvre des activités préparatoires de la Phase 0 et de la Phase 1 ;

    b) l’article 5 s’applique au parcours qui mène de la Phase 1 à la Phase 2 ;

    c) l’article 6 s’applique au parcours de la Phase 2 à la Phase 3 ;

    d) l’article 7 régit la diffusion extérieure pendant la transition, demeure un guide technique après la clôture et ne constitue pas une Phase 4 du Code 16.

    Aucun délai opérationnel ne peut autoriser le passage à une phase institutionnelle avant le franchissement des seuils correspondants du Code 16.

3.  Aux fins de la présente Annexe, on entend par :

    a) **système extractif** : l’ensemble des activités, des contrats et des chaînes d’approvisionnement qui crée une dépendance propriétaire critique au sens du Code 2, article 5, ou une dépendance critique au sens du Code 15, telle que documentée dans le Registre des dépendances ;

    b) **bloc territorial** : une unité de coordination opérationnelle composée d’une ou de plusieurs Fédérations minimales déjà constituées en application du Code 16. Le bloc n’a ni autonomie institutionnelle, ni pouvoirs délibératifs sur les biens communs, ni Caisse propre et agit exclusivement pour la coordination, l’échange de connaissances et l’élaboration de plans communs de réduction des dépendances. S’il ne comprend qu’une seule Fédération minimale, il n’en duplique pas les institutions ;

    c) **classification N/NN/S** : une classification technique des biens et des services effectuée conformément au Code 1, articles 18 et 32, à la STV Panier et au C.1-Annex A, article 1, alinéa 2 :

    - **N — nécessaire** : bien ou service du Panier 1-2 pour lequel aucune alternative interne adéquate n’a été vérifiée ;
    - **NN — non nécessaire** : bien ou service non inclus dans le Panier 1-2, ou pour lequel une alternative interne adéquate a été vérifiée ;
    - **S — dépendance incompatible** : bien ou service qui contribue à une dépendance propriétaire critique, entraîne une violation de l’article 9 du Code 16 ou est produit en violation d’une STV de sécurité applicable aux risques R2 ou supérieurs.

    La classification est motivée, enregistrée et publiée avec renvoi au Code sectoriel compétent. Elle porte sur les biens, les services et les dépendances ; elle ne constitue pas une évaluation morale des personnes ou de leurs comportements individuels.

## Art. 2 — Conditions préalables aux initiatives publiques et règles comptables

1.  Avant d’engager des initiatives publiques de réduction des dépendances extérieures, le Cercle vérifie cumulativement que :

    a) le Panier 1-2 est garanti ;

    b) une Caisse juridique distincte a été constituée, dans le cadre de la Caisse commune prévue à l’article 17 du Code 15, et qu’un accord a été conclu, pour chaque Bassin, avec au moins un cabinet professionnel, comprenant un protocole de protection contre les représailles ;

    c) la coordination interne fonctionne sur un Réseau fédéré auto-hébergé, avec au moins un nœud en fonctionnement conformément au Code 7 ;

    d) la documentation est conservée dans un dépôt versionné et réplicable ;

    e) il n’existe pas de dépendances d’endettement ou financières directes entre blocs territoriaux.

2.  Les conditions de l’alinéa 1 concernent l’aptitude institutionnelle à engager les initiatives prévues par la présente Annexe. Elles ne limitent pas les droits individuels, les activités licites, l’accès aux services essentiels ni le recours à la Garantie.

3.  Les économies résultant de la cessation documentée d’achats de biens NN ou S sont comptabilisées séparément dans le registre comptable de l’Entrepôt, sous un libellé distinct et avec la documentation de l’achat cessé. Le poste comptable correspondant est formellement identifié dans le système comptable applicable.

4.  L’économie est certifiée par le Conseil des Entrepôts, après avis obligatoire :

    a) du Conseil agroécologique pour les aliments ;

    b) du Conseil Énergie et Eau pour l’énergie et l’eau ;

    c) du Conseil Production pour les autres biens.

    La vérification établit que la cessation porte effectivement sur des biens NN ou S et ne réduit pas la disponibilité d’un bien N dépourvu d’alternative interne vérifiée. En cas de doute, le poste est classé N jusqu’à l’achèvement de l’instruction.

5.  L’économie monétaire certifiée peut être convertie chaque mois par le Conseil Transition en un volume d’heures équivalent, exclusivement pour mesurer la capacité organisationnelle du Cercle. Le calcul utilise un barème public approuvé par l’Assemblée générale, fondé sur le coût horaire moyen local des activités nécessaires au Panier 1-2.

6.  Le volume d’heures visé à l’alinéa 5 constitue un indicateur organisationnel du Cercle : il n’est pas de l’argent, il n’est pas transférable et il ne constitue pas une créance individuelle. Nul ne peut être obligé de fournir des heures en compensation.

7.  Dix pour cent des économies monétaires certifiées sont affectés à la Caisse commune conformément à l’article 17 du Code 15. Le versement ne peut pas être imputé à des personnes déterminées ni affecter le Panier 1-2.

## Art. 3 — Module opérationnel initial : publication et recensement

**Durée opérationnelle minimale indicative :** de zéro à quatre-vingt-dix jours, dans le cadre de la Phase 0 institutionnelle du Code 16.

1.  Le module vise à déterminer la capacité effective du Cercle et ne constitue pas une campagne de recrutement.

2.  Les activités institutionnelles prévues sont :

    a) publier les Codes 1–16 et les Annexes techniques dans un dépôt accessible, versionné et réplicable ;

    b) recueillir des manifestations volontaires de disponibilité pour des compétences juridiques, fiscales, agroécologiques, énergétiques, hydrauliques, sanitaires au sens du Code 6 et informatiques au sens du Code 7.

3.  Le module est considéré comme documenté lorsque sont :

    a) recensé sous forme agrégée le temps disponible au total pour les activités du Cercle ;

    b) enregistrées les compétences L1, L2 et L3 conformément au Code 5, article 10 ;

    c) recensés le sol, les machines, les équipements, les EPI, les semences et les ressources énergétiques disponibles ;

    d) recensés les besoins effectifs du Panier 1-2 ;

    e) actifs l’Entrepôt provisoire conformément aux articles 13–22 du Code 1 et l’Entrepôt du savoir minimal conformément au Code 5, article 3, avec une comptabilité séparée entre biens provisoires et définitifs ;

    f) actives la Caisse commune et la Caisse juridique distincte selon les règles applicables ;

    g) opérationnel le nœud de coordination sur le Réseau fédéré ;

    h) documentée l’application du Niveau 1 du Protocole de démarrage social.

4.  Pendant ce module, la poursuite des activités extérieures de travail, d’études et d’achat nécessaires à la sécurité et à la stabilité personnelle est recommandée. La participation aux activités internes d’étude, de recensement et de formation L1 est volontaire et ne peut pas être imposée en contradiction avec les droits des personnes.

## Art. 4 — Module opérationnel de substitution

**Durée opérationnelle minimale indicative :** de quatre-vingt-dix à cent quatre-vingts jours. Le début et la fin restent subordonnés aux phases institutionnelles et aux seuils du Code 16.

1.  Le module vise à développer des alternatives internes jusqu’à ce que soit atteint le seuil d’autoproduction du Panier 1-2 prévu par le Code 16. Le pourcentage est calculé selon une méthodologie publique et uniforme définie par la STV Panier.

2.  Les activités de substitution sont planifiées par domaine conformément au Code 16, article 3, alinéa 2.

3.  La poursuite d’activités professionnelles extérieures par les personnes concernées est volontaire. La présente Annexe ne limite pas le droit de mettre fin à une relation de travail ou de la modifier conformément à la réglementation applicable sur le territoire concerné et n’autorise pas la violation d’obligations contractuelles ou de normes impératives.

4.  Pendant le module s’applique le Niveau 2 du Protocole de démarrage social, qui comprend :

    a) la double facilitation des Assemblées, avec rotation et interdiction du cumul entre facilitateur et auteur de la proposition ;

    b) la vérification de la surcharge conformément à l’article 3 du Protocole et au Code 1, article 6, alinéa 5 ;

    c) l’utilisation d’indicateurs agrégés et sans profilage ;

    d) le recours volontaire à la réparation sociale, sans préjudice de l’accès au Code 4.

## Art. 5 — Module de réduction sélective des dépendances

**Durée opérationnelle minimale indicative :** de cent quatre-vingts à trois cent soixante-cinq jours. Le module ne peut commencer qu’après l’autorisation institutionnelle pertinente et dans le respect du Code 16.

1.  Le module planifie la réduction sélective des achats et des activités productives qui alimentent des dépendances incompatibles avec l’autonomie matérielle. Il n’autorise pas de violations de la loi, d’obligations contractuelles impératives ni d’interruptions du Panier 1-2.

2.  Pour chaque Cercle sont établies et mises à jour :

    a) une liste des biens ou services que l’on n’entend plus produire pour le marché extérieur ;

    b) une liste des achats extérieurs que l’on entend cesser ou réduire ;

    c) la classification N/NN/S, les motivations et la référence aux Codes sectoriels.

3.  Les objectifs de réduction des consommations sont définis sur la base d’une valeur initiale documentée. La cessation des biens classés S est poursuivie en priorité ; les achats NN sont réduits selon un plan progressif. Aucune réduction ne peut porter sur un bien N dépourvu d’alternative interne adéquate. L’objectif indicatif de réduire de cinquante pour cent, dans un délai de trente jours, la valeur des fournitures classées comme dépendance à l’égard du système extractif n’est applicable que s’il est compatible avec la continuité du Panier, avec la sécurité et avec les obligations juridiques en vigueur.

4.  Tout choix relatif aux heures supplémentaires, aux tâches non dues ou à la cessation de production est effectué par les personnes concernées dans les limites du droit du travail, du droit syndical et du droit des contrats applicables. Avant toute initiative collective susceptible d’affecter des relations de travail ou des contrats, un avis juridique professionnel local est requis.

5.  Sont en tout état de cause interdits le sabotage, la dégradation, le blocage illicite de la circulation, l’occupation illicite et tout comportement qui viole des normes impératives. La présente Annexe ne constitue pas une autorisation autonome de tels comportements.

6.  Les obligations fiscales sont intégralement remplies. Les éventuels dons ou affectations de parts déductibles à des organismes du tiers secteur ou à des biens communs sont volontaires et sont effectués par l’intermédiaire de professionnels compétents conformément au Code 15 et aux normes applicables.

7.  Pendant le module sont activés, chacun dans la phase où l’article 3 du Code 16 le prévoit et conformément aux Codes sectoriels :

    a) le Cadastre de la biodiversité minimal provisoire ;

    b) le cadastre des risques généraux ;

    c) l’inventaire des machines critiques, des EPI et des protections collectives ;

    d) au moins un sanctuaire par Bassin, conformément au Code 13, article 4 ;

    e) les Conseils Biodiversité, Sécurité, Soin, Habitat et Territoire, agroécologique, Énergie et Eau.

## Art. 6 — Module de fédération et de coordination entre blocs

**Durée opérationnelle minimale indicative :** de trois cent soixante-cinq à sept cent trente jours, subordonnée aux phases institutionnelles du Code 16.

1.  Le parcours de fédération requiert, chacun dans la phase où l’article 3 du Code 16 le prévoit :

    a) l’agrégation d’au moins trois Bassins ;

    b) la première version du Registre des dépendances conformément au Code 15, avec un plan à terme certain pour chaque dépendance critique ;

    c) des audits L3 sur l’autonomie écologique, de sécurité et alimentaire ;

    d) un nœud du Réseau fédéré opérationnel dans chaque Bassin ;

    e) le dépassement effectif d’au moins cinquante pour cent des dépendances critiques enregistrées, calculé selon des critères publics et vérifiables.

2.  Le raccordement d’un nouveau bloc territorial s’effectue selon les règles suivantes :

    a) les Codes 1–16 sont traduits et adaptés au droit applicable sur le territoire concerné par des juristes professionnels locaux ; l’importation automatique du modèle juridique d’un autre bloc est exclue ;

    b) l’échange entre blocs non encore intégrés dans le même régime fédéral est orienté vers les connaissances, les STV, les semences libres, les fiches de réparation et les protocoles. La dette inter-blocs et les échanges monétaires sont exclus lorsqu’ils sont incompatibles avec les règles transitoires applicables ;

    c) au moins une rencontre mensuelle de coordination entre blocs est organisée. La concertation comprend l’état des lieux des achats et des dépendances encore liés au système extractif et produit, si nécessaire, un plan de sortie commun ;

    d) la crise ou l’interruption des activités d’un bloc n’entraîne pas automatiquement l’interruption des autres blocs. Des mesures de continuité cohérentes avec le Panier et avec les Codes applicables sont prévues.

## Art. 7 — Diffusion extérieure

1.  Le présent article régit la diffusion extérieure pendant la transition ; après la clôture, il demeure un guide technique sans effets normatifs. Il ne constitue pas une phase du Code 16 et ne modifie pas la définition de la Phase 4, qui correspond dans le Code 16 à la clôture.

2.  La diffusion extérieure est évaluée sur la base de l’adoption volontaire de solutions pour un avantage fonctionnel mesurable et ne requiert pas l’adhésion universelle.

3.  L’évaluation peut prendre en compte conjointement :

    a) l’adoption documentée d’une STV ou d’une Fiche par au moins trois acteurs extérieurs non adhérents à la Confédération ;

    b) une réduction documentée du coût du Panier 1-2 ou du risque classé R2 ou supérieur par rapport à une alternative extractive comparable ;

    c) la réplicabilité de la solution sans dépendance propriétaire critique.

4.  Aux fins du présent article, une attestation d’efficacité consiste en une déclaration écrite de l’acteur adoptant qui décrit l’usage, la durée et les résultats observés. La période d’observation est d’au moins quatre-vingt-dix jours, sauf si la nature de la solution requiert une période différente motivée.

5.  L’attestation est vérifiée par le Conseil compétent en la matière et, lorsque l’adoption affecte la sécurité R2 ou supérieure, par un membre L3 indépendant tiré au sort conformément à l’article 36 du Code 4.

6.  La vérification compare les résultats documentés avec une alternative comparable, en tenant compte du Panier, de la sécurité et de l’autonomie. L’adoption extérieure n’entraîne pas, à elle seule, l’activation du Solde mondial unique prévu par le Code 15 et ne modifie pas les conditions fixées par ce Code.

## Art. 8 — Suspension opérationnelle et redémarrage

1.  Les initiatives opérationnelles prévues par la présente Annexe sont suspendues, en ce qui concerne la proposition de passage ou l’activité de réduction des dépendances, lorsque l’une des conditions suivantes est remplie :

    a) le Panier 1-2 n’est pas garanti pendant trois mois consécutifs dans un Cercle pilote de l’unité qui propose le passage ;

    b) plus de vingt pour cent des réponses valables au questionnaire anonyme sur la sécurité ressentie sont négatives dans un Cercle pilote de l’unité qui propose le passage ;

    c) un incident R4 survient qui n’a pas été géré selon les procédures applicables ou pour lequel l’analyse des causes requise fait défaut ;

    d) la Caisse juridique est épuisée.

2.  La suspension n’interrompt pas la fourniture du Panier, l’accès à la Garantie, les mesures de sécurité ni les autres droits individuels. Elle entraîne la suspension de la proposition de passage à la phase suivante ou des seules initiatives concernées. Les inventaires, les procès-verbaux, les recensements et les STV déjà vérifiées sont conservés avec mention de la cause.

3.  Le redémarrage requiert la certification de la levée de la cause par les organes compétents :

    a) pour la condition visée à l’alinéa 1, lettre b), le Conseil de référence pour le soin, avec la nouvelle vérification prévue à l’article 4, alinéa 6, lettre c), de l’Annexe A, selon la procédure de cet alinéa, qui est la seule applicable à cette condition ;

    b) pour la condition visée à l’alinéa 1, lettre c), le Conseil Sécurité ;

    c) pour la condition visée à l’alinéa 1, lettre a), conjointement le Conseil des Entrepôts et le Conseil Transition ;

    d) pour la condition visée à l’alinéa 1, lettre d), le Conseil Transition, après avis juridique professionnel.

4.  Lors du redémarrage, les conditions de la phase en cours pertinentes au regard de la cause de la suspension sont vérifiées de nouveau. Les résultats antérieurs qui ne sont pas affectés par la cause restent valables.

5.  Le redémarrage est délibéré par l’Assemblée générale, après avis obligatoire des Conseils compétents, et publié conformément à l’article 15 du Code 3. Lorsque la suspension pour la condition de l’alinéa 1, lettre b), ne concerne que la proposition de passage de phase, la proposition reprend avec le résultat positif de la nouvelle vérification de l’alinéa 3, lettre a), sans délibération distincte de redémarrage.

6.  La suspension ne constitue pas un échec. Dans les cas de l’alinéa 1, lettres a), b) et c), elle atteste uniquement que le seuil pertinent prévu à l’article 4 du Code 16 n’a temporairement pas été franchi. Dans le cas de l’alinéa 1, lettre d), elle ne concerne que les initiatives de la présente Annexe, pour lesquelles fait défaut la condition de l’article 2, alinéa 1, lettre b), et n’a pas d’incidence sur les seuils de l’article 4 du Code 16.
