---
titolo: "CODE 16 — TRANSITION ET LANCEMENT DE LA CONFÉDÉRATION"
breve: "Code 16 — Transition et lancement"
versione: "V1.7"
gruppo: "codici"
ordine: 16
id: "codice-16"
slug: "code-16"
allineamento: "Constitution V.34 ; Code 1 V1.9 ; Code 2 V1.7 ; Code 3 V1.7 ; Code 4 V1.8 ; Code 5 V1.6 ; Code 6 V1.8 ; Code 7 V1.9 ; Code 8 V1.6 ; C.1-Annex A V1.6 ; Code 9 V3.3 ; Code 10 V1.7 ; Code 11 V1.5 ; Code 12 V1.6 ; Code 13 V1.7 ; Code 14 V1.6 ; Code 15 V1.7."
---

## Art. 1 — Objet, définitions et nature temporaire

1.  Le présent Code régit les phases, les seuils, les compétences transitoires et les procédures de lancement de la Confédération, ainsi que le passage de l’état préconfédéral à l’état confédéral opérationnel.

2.  Aux fins du présent Code, on entend par :

    a) **transition** : pour chaque Cercle pilote, la période comprise entre son institution et la déclaration de clôture prévue à l’article 10 pour la Fédération minimale dont il fait partie ;

    b) **phase** : la période transitoire au cours de laquelle sont activés des objectifs, des Codes et des procédures spécifiques, avec les seuils de sortie correspondants ;

    c) **Cercle pilote** : une Communauté de base, correspondant au Cercle 1, instituée en application des articles 4–6 de la Constitution pour l’expérimentation initiale ;

    d) **Bassin** : un regroupement de trois ou quatre Cercles pilotes territorialement contigus et écologiquement reliés, correspondant au Cercle intermédiaire ou Cercle 2 visé à l’article 5 de la Constitution ;

    e) **Fédération minimale** : un regroupement d’au moins trois Bassins ;

    f) **Panier 1-2** : les biens et les services du Panier de suffisance indiqués par l’article 32, alinéa 1-quinquies, du Code 1 ;

    g) **point de non-retour** : la délibération qui rend irréversible l’affectation de biens communs écologiques ou territoriaux ;

    h) **Protocole de démarrage social** : l’Annexe technique A au présent Code, adoptée conformément à l’article 19 du Code 3, qui définit une méthodologie de vérification des seuils sociaux institutionnels sans introduire d’obligations ni de sanctions individuelles autonomes ;

    i) **niveaux de risque R0-R4** : les niveaux définis par l’article 1, alinéa 3, du Code 14. Jusqu’à l’activation de ce Code, les mêmes niveaux sont attribués à titre provisoire par le Conseil Santé dans les Fiches de sécurité prévues à l’article 4 du Code 6 ;

    j) **Charte opérationnelle de la première année** : l’Annexe technique C au présent Code, adoptée conformément à l’article 19 du Code 3, qui réunit les règles minimales nécessaires au lancement d’un Cercle pilote sans introduire d’obligations autonomes.

3.  Le présent Code a une nature temporaire et cesse de produire des effets normatifs, pour chaque Fédération minimale, avec la déclaration de clôture visée à l’article 10, sans préjudice des dispositions de mémoire qui y sont prévues. Il continue de s’appliquer aux Cercles pilotes, aux Bassins et aux Fédérations minimales qui n’ont pas clos la transition, y compris ceux qui se constituent ou adhèrent ultérieurement, en application de l’article 21 du Code 15 ; à la Communauté associée de l’article 21-bis du Code 15, il s’applique dans les limites de l’article 3, alinéa 7, lettre f). Il ne peut pas instituer de droits, d’obligations ou de compétences permanents au-delà de la période de transition, ni modifier le contenu substantiel des Codes 1–15. Ses dispositions ne constituent pas une modification des Codes au sens des articles 37 et 38 de la Constitution. En cas de contradiction, la Constitution prévaut.

4.  La qualification transitoire d’un bien, d’une fonction ou d’une compétence n’en détermine pas le régime permanent.

5.  Pendant la transition, les renvois des Codes au Cercle 1 s’entendent comme faits au Cercle pilote et ceux au Cercle 2 comme faits au Bassin. La Fédération minimale exerce les fonctions du Cercle 3 jusqu’à ce qu’elle soit constituée en Cercle étendu en application de l’article 14-bis du Code 3. Jusqu’à la constitution de la Fédération minimale, la déclaration du Cercle 3 concerné prévue par l’article 36.2 de la Constitution est adoptée par l’Assemblée générale du Bassin touché, dans les limites de l’article 36.4 de la Constitution.

6.  Pendant la transition, le Solde prévu par le Code 15 opère à l’échelle du Bassin et de la Fédération minimale. L’activation de la phase confédérale opérationnelle n’implique pas que la Confédération englobe l’humanité entière.

7.  La révision de la Constitution et des Codes suit le régime de fondation aux conditions de l’article 38.2 de la Constitution, c’est-à-dire tant qu’il n’existe pas au moins trois Cercles étendus, même lorsqu’une partie de la Confédération est encore en transition.

8.  Les Annexes techniques A, B et C au présent Code sont adoptées et modifiées selon l’article 19 du Code 3, avec les règles suivantes :

    a) chaque Annexe, ou sa partie qui s’applique à une phase, est adoptée par l’Assemblée de l’unité qui se trouve dans cette phase au sens de l’article 3, alinéa 7 : l’Assemblée du Cercle pilote pour la Phase 0, l’Assemblée générale du Bassin pour la Phase 1 et celle de la Fédération minimale pour les Phases 2 et 3, en application des articles 12 et 14 du Code 3 ;

    b) la modification délibérée par une unité vaut pour elle et pour les unités qui la rejoignent, en application de l’article 3, alinéa 7, lettre c) ; elle est publiée dans l’Entrepôt du savoir fédéré, afin que les autres unités puissent l’adopter ;

    c) aucune Annexe ni aucune de ses modifications ne peut altérer les phases, les seuils, les compétences ou les garanties du présent Code et des Codes 1–15, en application de l’article 19, alinéa 5, du Code 3.

9.  Jusqu’à l’activation d’un Code en application de l’article 3, les renvois qui y sont faits par le présent Code et par ses Annexes s’appliquent dans la mesure où ils sont applicables avec les organes et les procédures déjà actifs. Les avis des Conseils non encore institués suivent l’article 8, alinéas 2 et 3. Demeurent toujours applicables les interdictions et les garanties qui mettent directement en œuvre la Constitution.

## Art. 2 — Principes de la transition

1.  **Continuité du Panier.** Aucun passage de phase n’est délibéré s’il entraîne l’interruption des niveaux 1 et 2 du Panier ou un risque d’interruption qui n’est pas géré de manière adéquate.
2.  **Réversibilité.** Avant l’adoption d’un point de non-retour, toute intervention prévoit, lorsque cela est techniquement applicable, un plan de réversibilité.
3.  **Proportionnalité et progressivité.** L’activation de fonctions, de Codes et de contraintes est proportionnée aux compétences disponibles, aux ressources recensées et aux risques effectivement présents.
4.  **Effectivité.** Il est interdit de constituer de manière purement formelle des Cercles, des Bassins ou des Fédérations dépourvus de continuité territoriale, d’activité effective ou de recensement vérifiable.
5.  **Transparence.** Les phases, les seuils, les recensements, les délibérations et les plans sont publiés conformément à l’article 15 du Code 3 et soumis à une période d’observations d’au moins soixante-douze heures. Les données personnelles sont exclues ou agrégées conformément au Code 7, article 2.2.
6.  **Non-marchandisation.** Il est interdit de constituer des rentes sur le lancement de la Confédération, sur les biens communs apportés pendant la transition ou sur les compétences vitales.
7.  **Légalité et coexistence.** Pendant la transition, les Cercles agissent dans le respect de l’ordre juridique en vigueur sur le territoire, en application de l’article 38.6 de la Constitution. L’article 37 du Code 4 et le Chapitre IV du Code 15 s’appliquent.
8.  **Caractère volontaire.** L’adhésion est individuelle et volontaire. Nul ne peut être incité à cesser des activités extérieures, à apporter des biens ou à renoncer à des droits reconnus par l’ordre juridique en vigueur. La contribution proportionnelle sur les revenus extérieurs prévue par l’article 19-bis du Code 15, communiquée avant l’adhésion, demeure applicable.
9.  **Revenus extérieurs mis en commun.** Pendant la transition, dans le respect de l’ordre juridique en vigueur en application de l’article 38.6 de la Constitution, les membres d’une Communauté associée en application de l’article 21-bis du Code 15 peuvent mettre en commun volontairement les revenus et les patrimoines qu’ils détiennent hors de la Confédération en application de l’article 3.5-ter de la Constitution et les redistribuer entre eux pour les dépenses extérieures personnelles. Le fonds ainsi constitué est formé de revenus et de patrimoines personnels extérieurs : il est distinct de la Caisse commune du Cercle prévue par l’article 3.5-bis de la Constitution et par l’article 17 du Code 15 et n’en fait pas partie. Il ne donne pas accès aux Entrepôts, au CdR, aux Biens communs ou aux décisions ; il n’est pas réparti en proportion du travail ni comme sa rémunération et ne peut pas être employé pour acheter du travail ou du consentement, en application de l’article 19-bis, alinéa 2, du Code 15. Chaque membre peut s’en retirer à tout moment. La contribution proportionnelle aux dépenses extérieures communes de l’article 3.5-ter de la Constitution et de l’article 19-bis du Code 15 demeure. La faculté cesse lorsque cessent les moyens de paiement extérieurs, en application de l’article 19-bis, alinéa 8, du Code 15.

## Art. 3 — Phases de la transition

1.  **Phase 0 — Préconfédérale.** La durée indicative est de zéro à six mois. Au cours de cette phase :

    a) au moins un Cercle pilote est constitué avec au moins trente personnes adhérentes ;

    b) les Codes 1, 2, 3, 4, 5 et 6 et le Chapitre IV du Code 15 sont activés ;

    c) un recensement initial, agrégé et sans profilage, est réalisé du sol disponible, des compétences L1 et L2, des machines et équipements et des besoins du Panier 1-2 ;

    d) un Entrepôt minimal provisoire conformément aux articles 13–22 du Code 1 et un Entrepôt du savoir minimal conformément à l’article 3 du Code 5 sont activés ;

    e) la formation L1 de base aux gestes qui sauvent est lancée conformément au Code 6 ;

    f) le Cercle de garantie et les Conseils prévus par les Codes actifs sont institués, y compris le Conseil des Entrepôts, le Conseil Santé et le Conseil des Compétences, même sous une forme regroupée ou partagée ou bien au sein des trois Conseils de secteur prévus par l’article 12-bis, alinéa 12, du Code 3 ;

    g) le Cercle pilote fonctionne conformément à la Charte opérationnelle de la première année.

2.  **Phase 1 — Bassin.** La durée indicative est de six à dix-huit mois. Au cours de cette phase :

    a) trois ou quatre Cercles pilotes contigus se regroupent en un Bassin ;

    b) les Codes 7, 8, 9 et 10 et le C.1-Annex A sont activés, en plus des Codes de la Phase 0 ;

    c) le cadastre territorial fédéré minimal provisoire prévu par l’article 7 du Code 10 est lancé ;

    d) le bilan alimentaire de Bassin et une STV Panier minimale conjointe des Codes 9 et 10 sont établis ;

    e) les sols susceptibles de devenir des sanctuaires font l’objet d’un recensement préliminaire, en préparation de l’activation du Code 13 ;

    f) les Conseils Réseau, Énergie et Eau, agroécologique, Habitat et Territoire et Production sont activés ;

    g) le Solde prévu par le Code 15 est activé à l’échelle du Bassin et le Conseil des Entrepôts du Bassin prévu par l’article 9-bis du Code 15 est institué.

3.  **Phase 2 — Fédération minimale.** La durée indicative est de dix-huit à trente-six mois. Au cours de cette phase :

    a) au moins trois Bassins sont regroupés ;

    b) les Codes 11, 12, 13 et 14 sont activés, en plus des Codes déjà activés ;

    c) le Chapitre III du Code 15 et le Solde à l’échelle de la Fédération minimale sont activés, avec le Conseil des Entrepôts prévu par l’article 9-bis du Code 15 pour le Cercle 3 ;

    d) au moins un sanctuaire par Bassin est institué, en application de l’article 4 du Code 13 ;

    e) les machines critiques, les EPI et les protections collectives sont recensés conformément au Code 14 ;

    f) les Conseils Logistique, Soin, Biodiversité et Sécurité sont activés ;

    g) la première version du Registre des dépendances est instituée, en intégrant les registres des Codes sectoriels.

4.  **Phase 3 — Confédération opérationnelle.** La durée indicative est de trente-six à soixante mois. Au cours de cette phase :

    a) les Codes 1–15 et le C.1-Annex A sont pleinement activés, dans les limites des conditions d’efficacité prévues par chaque Code ;

    b) des audits d’autonomie écologique, de sécurité et alimentaire sont réalisés par des membres L3 indépendants tirés au sort conformément à l’article 36 du Code 4 et aux Codes sectoriels ;

    c) le dépassement d’au moins cinquante pour cent des dépendances critiques enregistrées est achevé, sur la base d’objectifs et de délais vérifiables ;

    d) le nœud du Réseau fédéré prévu par le Code 7 est achevé pour chaque Bassin.

5.  **Phase 4 — Clôture.** La transition s’achève par la déclaration de clôture adoptée conformément à l’article 10.

6.  Les durées indiquées sont indicatives et ne remplacent pas les seuils de sortie de l’article 4. Aucune phase ne peut être franchie avant que les seuils correspondants aient été vérifiés.

7.  **Échelle des phases.** La Phase 0 est propre à chaque Cercle pilote, la Phase 1 à chaque Bassin et les Phases 2, 3 et 4 à chaque Fédération minimale. Les règles suivantes s’appliquent :

    a) le passage de la Phase 0 à la Phase 1 est délibéré conjointement par les Cercles pilotes qui constituent le Bassin, en application de l’article 14, alinéa 10, du Code 3 ; le passage de la Phase 1 à la Phase 2 par l’Assemblée générale des Bassins qui constituent la Fédération minimale ; les passages suivants et la clôture par l’Assemblée générale de la Fédération minimale ;

    b) le Cercle pilote qui se constitue ou adhère alors que d’autres sont déjà dans une phase ultérieure parcourt la Phase 0. Une fois dépassés les seuils de l’article 4, alinéa 1, il entre dans un Bassin contigu ou en constitue un nouveau. Le Bassin qui a dépassé les seuils de l’article 4, alinéa 2, entre dans une Fédération minimale ou en constitue une nouvelle avec au moins deux autres Bassins ;

    c) le Cercle pilote ou le Bassin qui entre dans un Bassin ou dans une Fédération minimale en prend la phase lorsqu’il satisfait, pour sa propre part, aux seuils des passages déjà délibérés par celui-ci ou celle-ci. La vérification est effectuée par le Conseil Transition de l’unité qui l’accueille et ne peut pas introduire d’appréciations supplémentaires, en application de l’article 4.5 de la Constitution. Les Codes déjà activés s’appliquent à l’entrant à partir du jour de l’entrée, et les délais transitoires de chaque Code courent à partir de cette date ;

    d) si la Fédération minimale a déjà clos la transition, la vérification de la lettre c) comprend les seuils de l’article 4, alinéas 3 et 4, et la clôture de la transition pour l’entrant est délibérée par son Assemblée générale en application de l’article 10, alinéa 1 ; l’entrée dans le Cercle étendu suit l’article 14-bis, alinéa 4, du Code 3 ;

    e) l’entrée d’un nouveau Cercle pilote ou d’un nouveau Bassin ne fait pas reculer de phase l’unité qui l’accueille ;

    f) la Communauté associée en application de l’article 21-bis du Code 15 ne parcourt pas les phases pour sa propre vie interne et n’est pas tenue d’activer les Codes et les Conseils des phases, sauf les outils qu’elle adopte. Elle entre dans un Bassin, ou concourt à en constituer un, lorsque l’équivalence à la frontière a été vérifiée, et elle est comptée comme Cercle pilote aux fins de l’article 1, alinéa 2, lettre d). Les seuils de l’article 4 sont vérifiés, pour sa part, sur les données et les engagements qu’elle fournit à la frontière en application de l’alinéa 2 de cet article ; dans le Bassin et dans la Fédération minimale, elle suit les règles des outils communs activés dans la phase.

## Art. 4 — Seuils d’activation et de sortie

1.  **Passage de la Phase 0 à la Phase 1.** Sont requis :

    a) la garantie continue des niveaux 1 et 2 du Panier pendant au moins trois mois dans le Cercle pilote ;

    b) un recensement vérifié et le fonctionnement de l’Entrepôt minimal et de l’Entrepôt du savoir minimal ;

    c) l’absence de violations critiques non gérées au sens de l’article 9, alinéa 2 ;

    d) l’application documentée du Niveau 1 du Protocole de démarrage social ;

    e) un Bilan du travail, établi en application de l’article 2 du Code 1, qui documente pendant au moins un trimestre la couverture des niveaux 1 et 2 du Panier dans la limite de l’article 3 de ce même Code.

2.  **Passage de la Phase 1 à la Phase 2.** Sont requis :

    a) l’autoproduction dans le Bassin d’au moins soixante-dix pour cent des niveaux 1 et 2 du Panier, calculée selon les critères de la STV Panier applicable ;

    b) le fonctionnement du cadastre territorial minimal ;

    c) au moins une zone candidate au statut de sanctuaire, attestée par le Conseil Habitat et Territoire. En l’absence du Conseil Biodiversité, l’évaluation biologique provisoire est rendue par le Conseil Transition en application de l’article 8, alinéa 2, avec l’indication expresse de son caractère provisoire ;

    d) l’absence de violations critiques non gérées au sens de l’article 9, alinéa 2, vérifiée conformément aux Codes 4, 9 et 10 ;

    e) l’application documentée du Niveau 2 du Protocole de démarrage social ;

    f) des Bilans du travail de Bassin qui respectent la limite de l’article 3 du Code 1 pendant au moins deux trimestres consécutifs.

3.  **Passage de la Phase 2 à la Phase 3.** Sont requis :

    a) le fonctionnement du Cadastre de la biodiversité minimal provisoire ;

    b) le fonctionnement du cadastre des risques généraux ;

    c) l’institution d’au moins un sanctuaire par Bassin ;

    d) des Fiches de sécurité en vigueur pour toutes les activités classées R2 ou au-dessus ;

    e) l’absence d’incidents R4 non gérés ou dépourvus de l’analyse des causes requise ;

    f) l’application documentée du Niveau 3 du Protocole de démarrage social.

4.  **Passage de la Phase 3 à la Phase 4.** Sont requis :

    a) un audit fédéré positif sur l’autonomie, réalisé après au moins six mois continus de fonctionnement sans dépendances critiques non substituables compromettant la continuité du Panier ;

    b) l’inscription au Registre des dépendances d’un plan de sortie à échéance certaine pour chaque dépendance critique encore présente ;

    c) le fonctionnement des nœuds du Réseau fédéré dans tous les Bassins ;

    d) le maintien documenté du Niveau 3 du Protocole de démarrage social ;

    e) des Bilans du travail qui respectent la limite de l’article 3 du Code 1 pendant quatre trimestres consécutifs ou, à défaut, la présentation d’une proposition motivée de révision de cette limite en application de l’article 38 de la Constitution.

5.  La vérification des seuils est effectuée par le Conseil Transition, avec l’avis obligatoire des Conseils compétents en la matière. Le passage de phase constitue une décision constitutive au sens de l’article 3, alinéa 3, du Code 3 et est délibéré par l’Assemblée générale indiquée par l’article 3, alinéa 7, lettre a), selon la convocation, le quorum et la procédure prévus par les Codes 3 et 4. La délibération est publiée sous une forme agrégée et sans profilage.

6.  L’avis social prévu par le Protocole de démarrage social peut porter exclusivement sur la vérification institutionnelle du seuil et sur la possibilité de proposer ou de délibérer le passage de phase. Il ne peut pas produire de sanctions, d’exclusions ou de limitations individuelles, ni conditionner l’accès au Code 4, à la Garantie, aux biens vitaux ou au Panier 1-2.

## Art. 5 — Gouvernement transitoire

1.  Dans chaque phase est institué un Conseil Transition distinct, dont la durée est limitée à la phase de référence, à l’échelle prévue par l’article 3, alinéa 7 : un pour chaque Cercle pilote en Phase 0, un pour chaque Bassin en Phase 1 et un pour chaque Fédération minimale dans les Phases 2 et 3. Le Conseil Transition du Bassin et de la Fédération minimale est un Conseil commun au sens de l’article 12-bis, alinéa 6-bis, du Code 3, dont les membres sont tirés au sort parmi les personnes éligibles au sens de l’alinéa 2 des Cercles pilotes qui en font partie ; les règles de l’alinéa 3 demeurent applicables.

2.  Le Conseil est composé de trois à cinq membres disposant de compétences L2 ou L3 pertinentes pour la phase, notamment en organisation, droit confédéral, agroécologie, territoire, sécurité et biodiversité.

3.  La nomination et la durée sont régies comme suit :

    a) les membres sont tirés au sort parmi des volontaires aptes ayant accompli la CBO requise et la formation spécifique, avec le droit de refuser la charge, conformément aux articles 4.3 et 4.4, lettre d), de la Constitution ;

    b) aucun membre n’exerce la fonction pendant plus de quatre-vingt-dix jours consécutifs ni pendant plus de cent quatre-vingts jours au total sur trois cent soixante-cinq jours ;

    c) le renouvellement s’effectue par tirage au sort échelonné, avec une passation des fonctions consignée au procès-verbal, de manière à garantir la continuité du Conseil pendant toute la phase ;

    d) entre deux mandats au Conseil Transition s’écoulent au moins douze mois d’activité exclusivement en CBO ordinaire ;

    e) il est interdit d’appartenir simultanément au Conseil Transition et au Conseil des Entrepôts au cours de la même phase ;

    f) chaque membre déclare ses conflits d’intérêts et s’abstient lorsqu’il existe un conflit ou une coïncidence directe entre contrôleur et contrôlé, conformément au Code 3, article 16.

4.  Le Conseil fonctionne avec un quorum d’au moins deux tiers de ses membres. Les décisions sont prises par consensus en l’absence d’objections motivées, conformément au Code 3, article 4. Les réunions font l’objet de procès-verbaux, qui sont conservés pendant trente-six mois.

5.  Le Conseil Transition ne délibère ni le passage de phase ni l’adoption d’un point de non-retour. Il peut formuler des propositions à l’Assemblée générale, à laquelle il revient de décider : le passage de phase selon l’article 4 ; le point de non-retour selon l’article 2, alinéa 2, l’article 6 et l’article 4, alinéa 7, de l’Annexe A.

6.  Le Conseil Transition :

    a) coordonne les recensements ;

    b) établit les plans transitoires ;

    c) vérifie les seuils ;

    d) propose l’activation des Codes ;

    e) alimente le Registre des dépendances ;

    f) coordonne les Conseils activés au cours de la phase ;

    g) vérifie l’application du Protocole de démarrage social dans la seule limite des seuils institutionnels.

7.  Le Conseil Transition ne peut pas exercer de compétences réservées à d’autres Conseils, céder à des acteurs extérieurs le contrôle de biens communs ni contracter d’engagements financiers extérieurs qui créent des dépendances critiques.

## Art. 6 — Biens communs pendant la transition

1.  Les biens apportés pendant la transition sont inscrits dans un inventaire provisoire fédéré selon la compétence applicable :

    a) le Code 10, article 7, pour le sol et les biens territoriaux ;

    b) le Code 5, article 3, pour les connaissances essentielles ;

    c) les articles 13–22 du Code 1 pour les biens gardés dans les Entrepôts ;

    d) le C.1-Annex A et les Codes 9 et 14 pour les machines, les semences, les EPI et les protections collectives, à compter de leur activation respective.

2.  La nature de bien commun inaliénable des biens prévus par l’article 3.1 de la Constitution n’est pas suspendue pendant la transition. Le présent article régit exclusivement la garde et l’inscription provisoire.

3.  Le transfert au régime définitif de garde a lieu :

    a) pour les biens territoriaux et écologiques, à la clôture de la Phase 2 ;

    b) pour les biens technologiques critiques, à la clôture de la Phase 3.

    Le transfert requiert une délibération de l’Assemblée générale et l’avis obligatoire du Conseil compétent.

4.  Jusqu’à l’activation du régime définitif, les actes de disposition qui excèdent l’entretien ordinaire et l’usage conforme à une Fiche en vigueur sont sans effet. Les actes de vente, de location ou d’hypothèque des biens communs demeurent interdits, conformément aux articles 3.1 et 3.2 de la Constitution.

5.  Les Entrepôts provisoires tiennent une comptabilité distincte entre les biens en transition et les biens communs déjà inscrits dans le régime définitif. La traçabilité et l’accès suivent le Code 1 ; pour l’Entrepôt du savoir, le Code 5 s’applique.

6.  La titularité juridique des biens pendant la transition est régie par l’article 16 du Code 15.

## Art. 7 — Personnes, compétences et formation transitoire

1.  La formation L1 aux gestes qui sauvent est dispensée gratuitement dès la Phase 0 conformément au Code 6 et, à compter de l’activation des Codes correspondants, conformément aux Codes 13 et 14.
2.  Les compétences antérieures sont enregistrées conformément au Code 5, article 10, alinéa 1. La validation provisoire de la continuité, les délais correspondants et les raccourcissements des parcours de formation sont régis exclusivement par l’article 10, alinéas 2–7, du Code 5. Le Conseil Transition ne peut pas proroger ces délais ni y déroger.
3.  Toute fonction classée R3 ou au-dessus requiert le tutorat d’une personne disposant d’une compétence L2 ou L3 vérifiée, jusqu’à ce qu’une couverture interne suffisante soit disponible.
4.  Le registre transitoire des compétences est tenu sous une forme agrégée et sans profilage, conformément au Code 7, article 2.2.
5.  Le Conseil Transition prend en considération le Protocole de démarrage social exclusivement aux fins de la vérification des seuils sociaux de durabilité institutionnelle et dans les limites fixées par l’Annexe technique A.

## Art. 8 — Conflits et Garantie pendant la transition

1.  Le Code 4 s’applique dès la Phase 0.
2.  Jusqu’à l’activation d’un Conseil compétent, le Conseil Transition peut rendre, à titre provisoire, les avis obligatoires non contraignants qui concernent la matière non encore couverte. L’avis est annoté comme provisoire et soumis à réexamen dans un délai de six mois à compter de l’activation du Conseil compétent.
3.  La suppléance de l’alinéa 2 ne s’applique pas aux avis contraignants négatifs prévus par l’article 8 du Code 3 ni à l’autorisation de l’article 13.3 de la Constitution. Jusqu’à l’activation du Conseil compétent, les décisions qui requièrent l’un de ces avis ou cette autorisation sont suspendues. Les autres décisions qui ne dépendent pas de cet avis peuvent se poursuivre.
4.  Les suspensions nécessaires pour faire face à un risque grave et immédiat R4 sont immédiatement exécutoires dans toute phase, dans le respect des procédures des Codes compétents.
5.  Le recours à la Garantie est admis dans un délai de quatorze jours conformément à l’article 17 du Code 3 et à l’article 17 du Code 4. Aucune disposition du présent Code ou du Protocole de démarrage social ne peut conditionner, retarder ou limiter l’accès à la Garantie.
6.  Pendant la transition, le Chapitre V du Code 4 s’applique dans les limites de son article 37. Tant qu’aucun Bassin n’est constitué, les organes du Code 4 qui requièrent des membres extérieurs au Cercle pilote, y compris le Collège de réexamen de l’article 17 et le Cercle de garantie de remplacement de l’article 15, alinéa 3, sont formés conformément à l’article 37, alinéa 5, du Code 4.

## Art. 9 — Interdictions pendant la transition

1.  Pendant la transition, il est interdit de :

    a) constituer des rentes sur le lancement, sur les biens communs inscrits à l’inventaire provisoire ou sur la formation L1 aux gestes qui sauvent ;

    b) vendre, hypothéquer ou grever le sol destiné à un sanctuaire candidat ou à un corridor écologique candidat ;

    c) breveter, enregistrer, déposer, revendiquer ou conserver des titres exclusifs sur le matériel génétique sauvage ou local ou sur les connaissances essentielles recensées ;

    d) contracter des dettes financières extérieures ou conclure des accords de fourniture qui créent une dépendance propriétaire critique au sens de l’article 5 du Code 2, en l’absence d’un plan de sortie à échéance certaine inscrit au Registre des dépendances ;

    e) céder à des acteurs extérieurs le contrôle de l’Entrepôt provisoire, du Cadastre provisoire, du Cadastre de la biodiversité provisoire ou du Registre des dépendances ;

    f) constituer des Cercles ou des Bassins fictifs ou dépourvus des conditions minimales prévues par l’article 2, alinéa 4, et par l’article 3 ;

    g) imposer un accès payant aux STV et aux Fiches essentielles pour le Panier 1-2, la biodiversité ou la sécurité générale.

2.  Aux seules fins du présent Code, les violations de l’alinéa 1, lettres a), b), c), d) et e), sont classées comme critiques ; celles des lettres f) et g) sont classées comme substantielles.

3.  La constatation, les mesures conservatoires et réparatrices et les éventuels remèdes sont régis par le Code 4. Les effets sur les décisions sont déterminés conformément à l’article 18 du Code 3. L’exclusion technique d’un bien ou d’un service reste de la compétence du Conseil Qualité en application du Code 2.

## Art. 9-bis — Application progressive de la souveraineté technologique

1.  En application de l’article 38.6 de la Constitution, jusqu’à la clôture de la transition, l’obligation de posséder physiquement le matériel de chaque système utilisé, prévue par l’article 19.4 de la Constitution, et celle de n’employer que des IA open source, prévue par l’article 19.5, s’appliquent progressivement de la manière suivante :

    a) l’utilisation d’un système hébergé sur des infrastructures extérieures ou qui intègre un modèle d’IA non open source n’est admise que si la dépendance est admise comme résiduelle et surmontable en application de l’article 5, alinéa 2, lettre b), du Code 2, ou comme temporaire en application des articles 2, alinéa 1, 8, alinéa 2, et 10, alinéa 3, du Code 7, et si elle est inscrite au Registre des dépendances avec le Plan de substitution ou le Plan de sortie ;

    b) l’application progressive ne permet pas d’utiliser du code fermé ou des modèles non open source pour les IA de gestion, pour les algorithmes de l’article 2, alinéa 5, du Code 7, pour l’IA personnelle et pour les systèmes de consultation et de vote de l’article 34.4 de la Constitution ;

    c) les systèmes de la lettre a) installés auprès de la Communauté ne reçoivent pas de mises à jour automatiques ou à distance ; toute mise à jour est vérifiée par le Conseil Réseau avant l’installation et elle est réversible, en application de l’article 5-ter, alinéa 7, du Code 7 ;

    d) l’application progressive cesse pour chaque système à l’échéance de son Plan et, en tout cas, avec la clôture de la transition.

2.  L’utilisation de systèmes dont le code source n’est pas disponible suit, pendant la transition et après celle-ci, l’article 19.4 de la Constitution, l’article 5, alinéa 2, lettre b), et l’article 12, alinéa 5, du Code 2.

## Art. 10 — Clôture de la transition, mémoire et primauté

1.  La clôture de la transition est délibérée, pour chaque Fédération minimale, par son Assemblée générale à la majorité qualifiée des deux tiers, conformément aux articles 13 et 14 du Code 3. La délibération est précédée :

    a) de l’avis obligatoire des Conseils fédérés ;

    b) de l’audit fédéré positif prévu par l’article 4, alinéa 4 ;

    c) de la vérification du respect des conditions de clôture.

2.  La déclaration de clôture produit les effets suivants :

    a) le présent Code cesse de produire des effets normatifs pour la Fédération minimale qui a délibéré la clôture, en application de l’article 1, alinéa 3, et la Fédération minimale est constituée en Cercle étendu en application de l’article 14-bis du Code 3 ;

    b) les inventaires provisoires, les procès-verbaux des Conseils Transition et les délibérations de passage de phase sont conservés comme mémoire historique conformément au Code 7 ;

    c) les biens déjà transférés au régime définitif restent soumis aux Codes sectoriels ;

    d) les biens non encore transférés faute d’avoir atteint les seuils sont restitués ou transférés par délibération de l’Assemblée générale et avis du Conseil compétent.

3.  Pendant la transition, en cas de conflit entre le présent Code et les Codes 1–15, le présent Code prévaut exclusivement dans la mesure strictement nécessaire pour régir la séquence d’activation et les seuils visés à l’article 4, en garantissant la continuité du Panier 1-2. Cette primauté ne crée pas de compétences permanentes et ne s’applique pas :

    a) à la Constitution ;

    b) aux normes impératives de la Constitution et des Codes, c’est-à-dire à celles qui n’admettent pas de dérogation de la part des organes qui décident, rappelées par l’article 2, alinéa 2, du Code 3 ;

    c) aux avis contraignants négatifs prévus par l’article 8 du Code 3.

4.  Après la clôture de la transition, les clauses de primauté des Codes sectoriels s’appliquent, y compris celles du Code 10, article 10, du Code 13, article 11, et du Code 14, article 10.

5.  Les principaux liens normatifs du présent Code sont : Constitution, articles 3.1, 3.2, 4–6 et 32 ; Code 1, articles 13–22 et 32 ; Code 2, article 5 ; Code 3, articles 3, 4, 8, 13–19 ; Code 4 ; Code 5, articles 3 et 10 ; Code 6, articles 4 et 11 ; Code 7, article 2.2 ; Codes 8 et 9 ; Code C.1-Annex A ; Codes 10–14 ; Code 15, Chapitres III et IV.
