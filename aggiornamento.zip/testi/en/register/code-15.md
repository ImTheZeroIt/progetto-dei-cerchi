---
titolo: "CODE 15 — EXTERNAL RELATIONS AND WORLD BALANCE"
breve: "Code 15 — External relations and Balance"
versione: "V1.13"
gruppo: "codici"
ordine: 15
id: "codice-15"
slug: "code-15"
allineamento: "Constitution V.40; Code 1 V1.12; Code 2 V1.9; Code 3 V1.13; Code 4 V1.11; Code 5 V1.7; Code 6 V1.9; Code 7 V1.10; Code 8 V1.7; C.1-Annex A V1.7; Code 9 V3.4; Code 10 V1.8; Code 11 V1.6; Code 12 V1.7; Code 13 V1.9; Code 14 V1.10; Code 16 V1.11."
---

## PRELIMINARY TITLE — GENERAL PROVISIONS

### Art. 1 — Subject matter, premise and principles

1.  This Code governs the calculation and offsetting of geographical differences between production and requirement in respect of the goods, resources and services included in the Sufficiency Basket referred to in Code 1. It also governs the Dependency Register and the relations of the Confederation with external parties.
2.  The Balance operates among the confederated Circles at the scale actually reached by the Confederation: that of the Basin, that of the Bioregion and, when the Confederation comprises the whole of humanity, that of the world. The expressions “Single World Balance” and “World Pool” denote the Balance and the Pool at the scale reached. Until then, relations with external parties, strategic autonomy clauses and countermeasures in the event of resource blackmail are governed by Chapter IV; transitional measures are governed by Code 16.
3.  Within the Confederation, the goods of the Sufficiency Basket shall not be the object of sale and purchase or of market exchange. Their distribution takes place through the Single World Balance. Market exchange is permitted exclusively in external relations, in accordance with Chapter IV and Code 16.
4.  The Single World Balance is founded on verifiable data, uniform criteria, traceability of resources and human decisions. Automated systems may process data and formulate proposals, but may not autonomously take allocation or transfer decisions.

## CHAPTER I — SINGLE WORLD BALANCE, MINIMUM NECESSARY LABOUR AND RESERVES

### Art. 2 — Accounting definitions and calculation sequence

1.  For the purposes of this Code, the following definitions apply:

    a) **P — Accountable Product**: the quantity of a resource that conforms to the applicable quality standards and has been verified in accordance with the procedures of the competent Code. For goods subject to a Technical Validation Sheet, the STV provided for by Code 2 applies;

    b) **B — Validated Real Need**: the human requirement validated by the competent Council, including ordinary storage and transport losses and the quantities necessary for sowing, ordinary maintenance and operational continuity. B does not include the Non-Federable Technical Reserve referred to in Article 5;

    c) **Gross Balance**: the result of subtracting B from P, calculated according to the formula **P − B**;

    d) **Available Balance**: the positive quantity of the Gross Balance that remains after the Non-Federable Technical Reserve has been set aside. The reserve reduces only a positive balance and does not increase a deficit;

    e) **Federable Balance**: the part of the Available Balance that is conforming, physically available and logistically retrievable, as ascertained pursuant to Article 3;

    f) **TRU — Residual Useful Time**: the period during which a resource retains its usefulness for use according to the applicable standards;

    g) **World Pool**: the whole of the availabilities constituted by the ascertained Federable Balances;

    h) **Federated Reserve**: the share of the World Pool not yet assigned to a specific destination and kept for a subsequent allocation.

2.  For every resource and accounting period, the following sequence shall mandatorily be applied:

    **P → B → Gross Balance → Non-Federable Technical Reserve → Available Balance → Federable Balance → World Pool → allocation.**

3.  The calculation shall be carried out as follows:

    a) if P − B is equal to or less than zero, the result constitutes the deficit and is not further reduced by effect of the Technical Reserve;

    b) if P − B is positive, the Technical Reserve is subtracted from the surplus up to the amount of that surplus;

    c) the remaining quantity, if positive and ascertained as physically and logistically available, constitutes the Federable Balance.

4.  The quantities necessary for sowing, ordinary maintenance and operational continuity shall be counted once only: either in the calculation of B as the ordinary requirement of the period, or as Technical Reserve pursuant to Article 5, if they meet the requirements of the latter. The same quantity may not be attributed to both items at the same time.

5.  The accounting period is quarterly. The Sufficiency Basket and the technical annexes define the units of measurement, the opening stocks, the criteria for calculating ordinary losses and the arrangements for reconciling data between consecutive periods. Logistics management may operate with more frequent updates, without prejudice to the quarterly statement of account.

### Art. 3 — Declaration and ascertainment of the Federable Balance

1.  Each Circle 1, 2 and 3 shall declare quarterly, for each resource within its competence:

    a) the Accountable Product;

    b) the Validated Real Need;

    c) the Gross Balance;

    d) the Technical Reserve set aside;

    e) the Available Balance;

    f) the proposed Federable Balance.

2.  The declarations of the different Circles shall be coordinated so as to avoid duplication of the same quantities. Each physical resource is recorded once only as an original availability; the records of Circles 2 and 3 report consolidated data and are not added again to the data of the Circles they include.

3.  The ascertainment of the Federable Balance is a technical procedure carried out by the Storehouse Council of the Circle where the resource is held in custody. The Council:

    a) verifies the conformity of the declared data;

    b) verifies the physical and logistical availability of the resource;

    c) consults the STVs, the sectoral registers and the relevant Dependency Register;

    d) records the reasons for any adjustments;

    e) remains responsible for the ascertainment even when it makes use of automated verifications.

4.  The control and verification procedures follow Codes 1 and 2. The Dependency Register helps to represent the constraints and dependencies that affect availability, but does not replace the accounting and storehouse registers necessary to document P, B, stocks and transfers.

5.  The ascertained Federable Balance shall be entered in the World Pool according to pre-established objective criteria. The body competent for allocation may not modify at its discretion the technical classification of the resource as federable; it may resolve exclusively on its destination and on the arrangements for the transfer in accordance with the priorities of this Code.

6.  Entry in the Pool derives from the ascertainment of the conditions laid down by this Code and not from a political resolution on the nature of the resource.

### Art. 4 — Single World Balance

1.  The positive surplus ascertained as federable is held physically in custody in the storehouse of the Circle where it is located, but is accounted for as part of the World Pool. By way of example, if P is equal to 100, B is equal to 80 and no Technical Reserve needs to be set aside, the proposed Federable Balance is equal to 20, subject to verification of physical and logistical availability.
2.  An ascertained deficit activates the procedure for coverage by the World Pool in accordance with the priorities of Article 8. The initiation of the procedure is automatic; the assignment and the transfer are resolved by the competent human body pursuant to Article 9.
3.  The management of availabilities does not give rise to bilateral supply relationships between Circles. A single Logistics World Pool operates. No Circle may claim to choose the final recipient of its own surplus or to know the specific origin of the resource assigned to cover a deficit, without prejudice to the traceability and transparency obligations laid down by this Code.

### Art. 5 — Non-Federable Technical Reserve and Federated Reserve

1.  The **Non-Federable Technical Reserve** consists of the quantities strictly necessary for the technical and infrastructural continuity of the Circle. It may include, according to documented necessity, spare parts, energy for continuity, materials for emergency repairs and conservation seeds.

2.  The Technical Reserve is validated by the competent Council, remains excluded from the World Pool and is not ordinarily transferable. Extraordinary transfer is permitted only in the presence of a documented emergency and in accordance with the safety and coordination procedures laid down by Code 1.

3.  The maximum limit of the Technical Reserve shall be determined, for each resource, on the cumulative basis of:

    a) documented technical requirement;

    b) risk of interruption of the service or of the infrastructure;

    c) time necessary to obtain a substitute resource;

    d) local restoration capacity.

    The limit shall be reviewed at least once a year. Quantities in excess shall be reclassified as Available Balance and submitted to the ascertainment referred to in Article 3.

4.  The **Federated Reserve** is a part of the World Pool not yet assigned to a specific destination. It is kept exclusively for future redistribution and may not be used to create artificial scarcity or for speculative purposes.

5.  The Federated Reserve shall be recorded with an indication of the quantity, the category of the resource, the reason for setting it aside, the TRU and the date by which it is advisable to proceed with allocation. Information on location shall be published only when its disclosure does not create risks for the safety or conservation of the resource; the technical detail remains accessible to the competent bodies.

6.  **Extractive Accumulation** is prohibited, meaning the withholding of resources for the purpose of creating artificial scarcity, awaiting an increase in value or securing exclusive use. Only the reserves governed by this Article and any other form of setting aside expressly provided for by the competent Codes are permitted.

### Art. 6 — Prevention of waste

1.  The Management Artificial Intelligence governed by Code 7 shall signal when the waste-risk thresholds defined by the STVs are exceeded and shall indicate the remaining TRU. The signal constitutes technical support and does not replace the assessment and decision of the Storehouse Council.
2.  The Storehouse Council of the Circle where the resource is held in custody shall decide and implement, within an ordinary maximum of seventy-two hours from the signal, the necessary measures of processing or recycling; reassignment through the Pool is decided within the same time limit by the Council provided for by Article 9-bis. If reassignment is not decided in good time, the Council of the Circle of custody allocates the resource in accordance with Article 15, paragraph 2, of Code 1. The time limit shall be reduced when necessary in order to intervene before the TRU expires and may never result in the intervention taking place after the resource has lost its usefulness.
3.  When the TRU is less than seven days, the intervention shall be ordered without delay, taking into account the actual times required for transport, processing and use of the resource.
4.  The loss of a Federated Reserve through omission or unjustified delay in reassignment constitutes damage to the Confederation and shall be dealt with in accordance with Code 4.

## CHAPTER II — OPERATING MECHANISM, FEDERAL LOGISTICS AND GUARANTEES

### Art. 7 — Global Minimum Necessary Labour

1.  For each Circle, the requirement of labour necessary for the production and management of resources shall be determined according to the following formula:

    **Necessary Labour = Validated Local Need + Share of Global Need assigned by the World Pool.**

2.  This Code determines the overall requirement of labour necessary for the management of the federated share. The assignment of persons, teams and organisational arrangements is governed by Code 1, according to criteria of proximity, competence and safety.

3.  The working time actually necessary for the production, storage, preparation and transfer of the federated share shall be recognised for the purposes of the CBO in accordance with the rules of Code 1. Such activity does not constitute unpaid labour.

4.  The share of CBO attributable to the Pool shall be calculated on the basis of the labour actually necessary and documented; it shall not be determined by means of an automatic conversion between physical units of product and hours of labour.

### Art. 8 — Calculation, proposal and allocation priorities

1.  The AI of the Intermediate Circle provided for by Article 22.2 of the Constitution shall draw up, for its own Circle 2, at least every twenty-four hours, an updated map of the federable availabilities and of the declared deficits. The maps of the Circles 2 are exchanged through the open protocols of Article 5-ter, paragraph 3, of Code 7 and, between Extended Circles, through the distributed protocol of Article 19.7 of the Constitution; no system brings them together in a central model, pursuant to Article 5-ter, paragraph 2, of Code 7. The map shall consider at least:

    a) quantity and location of the resources;

    b) energy necessary for each transfer;

    c) perishability and TRU;

    d) urgency and level of the need;

    e) capacity and safety of the logistics infrastructure.

    The system formulates proposals for an optimised flow, but does not take allocation or transfer decisions.

2.  Within the World Pool, proposals shall be ordered according to the following priorities:

    a) immediate vital needs, in accordance with Article 32 of Code 1;

    b) resources whose imminent TRU entails a concrete risk of waste, in accordance with Article 6;

    c) productive needs indispensable for maintaining the necessary productive capacity;

    d) constitution or replenishment of the federated reserves for foreseeable events.

3.  The hierarchy in paragraph 2 governs exclusively the allocation internal to the Pool and does not replace the general hierarchy of activities established by Article 32 of Code 1. In the event of conflict, the latter prevails. Where priority is equal, preference shall be given to the logistics route that requires less energy, provided that it respects the time limits, the safety and the integrity of the resource.

4.  Each proposal shall indicate the data used, the priorities applied, the alternatives considered and any margins of uncertainty. Proposals and resolutions shall be kept so as to allow their subsequent verification.

### Art. 9 — Competent bodies and formation of decisions

1.  Pursuant to Article 38 of Code 1, the Management Artificial Intelligence is an instrument of calculation, optimisation and proposal. No flow proposal shall become enforceable without a resolution of the competent human body.

2.  The functions are distributed as follows:

    a) **ascertainment of the Federable Balance**: competent local Storehouse Council, pursuant to Article 3;

    b) **drawing up of flow proposals**: Management Artificial Intelligence, under human supervision;

    c) **allocation and transfer decision**: Storehouse Council of Circle 2 or of Circle 3, in accordance with Article 9-bis, within the criteria approved by the General Assembly; decisions exceeding the criteria fall to the General Assembly;

    d) **reasoned opposition to the transfer**: Storehouse Council of the transferring Circle, also at the request of the Assembly, within the time limits and on the grounds provided for by Article 11;

    e) **verification of the opposition**: Review Panel constituted pursuant to Article 17 of Code 4 from among persons unconnected with the Circles concerned.

3.  The transfer resolution shall identify the resource, the quantity, the time limit, the planned route and the measures necessary to guarantee its delivery and integrity.

4.  The deliberative body may not alter the technical criteria for ascertaining the balance outside the verification and challenge procedures provided for. If errors emerge in the data or in the ascertainment, the decision shall be postponed or recalculated in accordance with the applicable procedures.

### Art. 9-bis — Storehouse Councils of Circles 2 and 3

1.  In implementation of Articles 5.1, letters c) and d), and 10.5 of the Constitution, each Circle 2 and each Circle 3 establishes a Storehouse Council, which decides on the allocation and transfer of the resources of the Pool:

    a) the Council of Circle 2 decides on transfers between the Base Communities of its Basin;

    b) the Council of Circle 3 decides on transfers between different Circles 2 included in its area;

    c) transfers between different Circles 3 are decided by concurring resolutions of the Councils of the Circles 3 concerned.

2.  The Council is composed of five to seven persons with validated competence in storehouse management or logistics, drawn by lot from among the persons of the Communities included in the Circle. No more than two members belong to the same Base Community or, for Circle 3, to the same Circle 2. Paragraphs 4, 5, 8, 9 and 11 of Article 12-bis of Code 3 apply. Revocation falls to the General Assembly of the Circle or to the Assembly of the Community of origin, pursuant to Article 12-bis, paragraph 6-bis, letter d), of Code 3.

3.  The Council decides in compliance with the priorities of Article 8 and with the criteria approved each year by the General Assembly of the Circle pursuant to Article 14 of Code 3, with the Dossier of Article 33 of the Constitution. The criteria indicate at least:

    a) the application of the priorities of Article 8 to the resources of the Circle;

    b) the size and the times of use of the Federated Reserve;

    c) the criteria for choosing between destinations of equal priority;

    d) the quantities or the values in UCR beyond which the decision falls to the General Assembly.

4.  Decisions that comply with the criteria are bound technical acts within the meaning of Article 12-bis, paragraph 9, of Code 3 and do not require a new Dossier. Decisions that exceed the criteria or the limits of letter d) of paragraph 3 fall to the General Assembly, which in cases of urgency resolves pursuant to Article 14, paragraph 9, of Code 3. Until the first criteria are approved, the Council decides only on immediate vital needs and on resources at risk of waste, in accordance with Article 8, paragraph 2, letters a) and b).

5.  The Council decides on flow proposals within forty-eight hours; on immediate vital needs without delay and in any case within twenty-four hours; on resources at risk of waste within the time limit of Article 6. If the Council does not decide in time on an immediate vital need, the Storehouse Council of the Circle where the resource is held in custody may execute the flow proposal that complies with Article 8 and with the criteria; the execution is recorded and communicated without delay to the competent Council. For resources at risk of waste, Article 6, paragraph 2, applies.

6.  The decisions are communicated to the Circles concerned. The opposition of Article 11 and the verification of Article 9, paragraph 2, letter e), remain in force; each Community concerned may request the same verification against an allocation decision. The request does not suspend the transfer, without prejudice to Article 11, paragraph 3. Against allocation decisions the verification of this paragraph replaces the appeal of Article 17, paragraph 1-bis, of Code 3, which remains admissible only for defects of procedure and of competence.

7.  During the transition the Council of Circle 2 is established in the Basin and that of Circle 3 in the minimum Federation, pursuant to Article 1, paragraphs 5 and 6, of Code 16.

### Art. 10 — Federal logistics

1.  The inter-Circle and interregional transport of the resources of the Basket shall ordinarily take place by means of the federated railway network provided for by Article 11.2 of the Constitution, as a mode with high capacity and lower energy cost, when it is suitable for the resource and compatible with the delivery times.
2.  Last-mile transport, from the railway station to the local Storehouse, is governed by Code 1 and may make use, according to availability and safety, of cargo bikes, electric vehicles, tractors and trolleys.
3.  Every transfer shall be recorded, indicating at least the type and quantity of the resource, the Circle of origin and the Circle of destination, the energy used and the CBO necessary. The public data shall not include information whose disclosure could compromise the safety of persons or of infrastructure; the logistical detail is accessible to the competent bodies.
4.  The modes of transport shall comply with the applicable Safety Sheets and with the parameters of the Codes competent in matters of health, environment, territory and the resource transported.

### Art. 11 — Opposition, transparency, prohibition of blackmail and guarantee of vital needs

1.  Every proposal for withdrawal from the World Pool shall be communicated to the Assemblies and to the Storehouse Councils of the Circles concerned. The Storehouse Council of the transferring Circle, also at the request of the Assembly, may lodge a reasoned opposition within seventy-two hours of the communication, indicating:

    a) the documented local emergency;

    b) the concrete risk that the transfer would compromise a vital need or an essential technical continuity;

    c) the elements demonstrating an error in the ascertainment or in the classification of the resource;

    d) any alternatives available in the Pool.

2.  The opposition does not constitute a definitive veto, nor may it be based on a political preference or on the wish to withhold a surplus. It activates the verification provided for by Article 9, paragraph 2, letter e), in accordance with the procedures of Code 4.

3.  Pending the verification, the transfer may be suspended for the time strictly necessary when the documentation submitted indicates a concrete and immediate risk. The suspension shall be reasoned, limited in time and reviewed as a matter of urgency. It may not be used to prevent indefinitely the allocation of a federable resource.

4.  The verification shall consider whether the local emergency is well founded, the accuracy of the data, the possibility of replacing the resource with another availability of the Pool and the effects of the suspension on the recipient need. The outcome shall be reasoned and communicated to the Circles concerned.

5.  It is prohibited to make the cession or transfer of a resource belonging to the Pool conditional on obtaining another benefit, a political decision or an advantage. Such conduct constitutes resource blackmail.

6.  In the event of ascertained blackmail, the measures and sanctions shall be applied in accordance with Code 4 and shall bear on the responsibility of the body or of the persons responsible. They may not result in the logistical isolation of the Circle or in the suspension or limitation of its members’ access to vital goods.

7.  Transparency on flows shall be ensured by means of verifiable records of availabilities, decisions and transfers, with due respect for logistical security, data protection and the competences established by Codes 7 and 14.

## CHAPTER III — DEPENDENCY REGISTER

### Art. 12 — Dependency Register

1.  The Dependency Register is hereby established, as the federated register of the Confederation’s dependencies on goods, services, competences, infrastructure and ecological functions that are external or not substitutable. It is kept in every Circle 1 by the Storehouse Council and is consolidated in Circles 2 and 3 without duplication.

2.  The Register is fed by the Councils in accordance with the sectoral Codes and, for proprietary dependencies, in accordance with Article 5 of Code 2. Each Council remains responsible for the data in its own field.

3.  For each dependency the Register shall indicate at least:

    a) the description and the category: material, technological, logistical, energy, water, competence-related, ecological, territorial or on external parties;

    b) the function and the level of the Basket concerned;

    c) the classification pursuant to paragraph 4;

    d) the person responsible and the continuity measures.

4.  A dependency is critical when its interruption would compromise the Basket or a function of levels 1 to 3 and no alternative is available within the time threshold defined by the applicable STV. Absolute critical proprietary dependency remains prohibited pursuant to Article 5 of Code 2.

5.  Every critical dependency shall be accompanied by an Exit Plan indicating the verifiable objective, the person responsible, the resources, the intermediate measures and a definite final time limit. The Plan is approved by the Assembly on a proposal from the competent Council. If exit is not technically possible within the time limit, the Plan shall be reviewed with a statement of reasons; the review may not be limited to extending the dependency.

5-bis. For raw materials, the Exit Plan indicates reduction of the requirement, reuse, recycling and recovery. It may not indicate new extraction. Paragraph 5 applies.

5-ter. **Structural dependencies.** A critical dependency is structural when the good, component or competence cannot, in the foreseeable future, be produced or replaced at a scale within the reach of the Confederation, as is the case for many medicines, electronic components, metals and batteries. The classification is justified in the Register by the competent Council, with the opinion of the corresponding Council of another Community. For a structural dependency the Exit Plan of paragraph 5 is replaced by a Guarantee Plan, which indicates: a) the safety stocks; b) at least two independent sources of supply, where they exist; c) the measures for reducing the requirement, reuse and repair; d) the alternatives under trial and the competences to be trained; e) for each measure, a person responsible and a definite time limit. The Guarantee Plan is approved by the Assembly and is reviewed at least every twenty-four months; at each review it is verified whether the dependency is still structural or whether it can have an Exit Plan. Paragraph 5-bis applies.

6.  The Register shall be published in aggregate form. Information that exposes vulnerabilities of infrastructure is accessible in accordance with Article 15 of Code 3.

7.  **Dependencies on persons.** A critical competence dependency exists where a function of levels 1 to 3, or the administration of a critical infrastructure, can be performed by fewer than three trained persons in Circle 1 or, for shared functions, in Circle 2. The Exit Plan consists in the training of other persons in accordance with Code 5 and in the documentation of the function in the Knowledge Storehouse. Until its completion the function shall be ensured also by means of the federated sourcing and remote mentoring of Article 13.

### Art. 13 — Federated sourcing of competences and remote mentoring

1.  When an L2 or L3 competence necessary for a function of levels 1 to 3 is not available in the Circle, the competent Council shall activate federated sourcing by means of a request on the Network to Circle 2 and, if necessary, to Circle 3. The reply shall be given within twenty-four hours for vital emergencies and within seventy-two hours in other cases.

2.  Sourcing shall take place, as the case may be, by means of:

    a) sending the person concerned to the competent service;

    b) temporarily sending the competence to the requesting Circle;

    c) remote mentoring supervised by an L3 person, when it is appropriate and safe.

3.  The time given for the benefit of another Circle shall be counted towards the CBO pursuant to Article 30 of Code 1 and Article 7 of this Code.

4.  The shortage shall be entered in the Register as a competence dependency and shall be accompanied by a training plan in accordance with Code 5.

5.  Until the competence is available in the Confederation, recourse to external services follows Chapter III of Code 2.

### Art. 14 — Autonomy audits

1.  The annual federated audits provided for by the sectoral Codes shall be coordinated in an annual Circle 2 plan. The persons appointed shall be drawn by lot in accordance with Article 36 of Code 4.
2.  The audit shall verify the completeness of the Register, the progress of the Exit Plans and the emergence of new dependencies. The report shall be published; the Circle concerned has fifteen days in which to submit observations. An appeal to the Guarantee Circle is permitted in accordance with Code 4.
3.  The outcomes of the audits are relevant for the purposes of the thresholds of Code 16.

## CHAPTER IV — EXTERNAL RELATIONS IN THE COEXISTENCE PHASE

### Art. 15 — Scope and principles

1.  This Chapter governs the relations of the Circles with persons, entities, enterprises and authorities external to the Confederation, until such time as the Confederation comprises the whole of humanity.

2.  External relations are founded on the following principles:

    a) legality: the legal order in force in the territory and fiscal and contractual obligations shall be respected;

    b) non-violence and cooperation: those who do not join shall not be treated as adversaries;

    c) transparency and traceability;

    d) progressive reduction of dependencies;

    e) prohibition of rent and of profit.

3.  Exchanges with the outside serve exclusively to meet the needs not yet covered by federated self-production and to dispose of real surpluses. Real surpluses are surplus goods that are not destined for the Pool pursuant to Article 15, paragraph 1-bis, of Code 1. Export for profit is prohibited, pursuant to Article 11.1 of the Constitution.

### Art. 16 — Legal personality and ownership of assets

1.  During coexistence each Circle shall operate through a non-profit entity recognised by the local legal order, identified with the opinion of a legal professional. The statute shall incorporate, within the limits permitted by law, the principles of the Constitution: indivisibility of the assets, prohibition of the distribution of profits, individual vote and rotation of offices.
2.  The land, buildings and installations conferred or acquired shall be registered in the name of the entity with statutory constraints of inalienability, indivisibility and designated use. In the event of dissolution the assets shall devolve to another Circle or to an entity with the same purposes.
3.  The offices that the law imposes on the entity shall be conferred by sortition and shall rotate with the maximum frequency permitted. Those who hold them are bound by the resolutions of the Assembly and do not acquire further powers.
4.  The conferral of goods by persons is voluntary and documented. The deed shall indicate whether the conferral is definitive or for temporary use. Goods in temporary use remain entered in the provisional inventory of Article 6 of Code 16 and shall be returned in the event of withdrawal prior to the transfer to the definitive regime.

### Art. 17 — Common Fund and external means of payment

1.  External means of payment shall be held exclusively by the Common Fund of the entity, pursuant to Article 3.5-bis of the Constitution. The Fund has separate accounts, published in aggregate form. It does not circulate among the members and does not give access to the Storehouses.
2.  The Fund is fed by the proportional contribution provided for by Article 19-bis, by voluntary contributions from the members, by the disposal of real surpluses and of obsolete goods pursuant to Article 15 of Code 1, by donations free of conditions and by the services rendered to the outside resolved by the Assembly.
3.  The Fund shall be used for the residual purchases of necessary goods that cannot be self-produced, for the external services permitted in accordance with Code 2, for fiscal and legal obligations, for legal protection, for the support for starting an autonomous life of those who leave the Confederation pursuant to Article 49, paragraph 6, of Code 1, for the expenses of the transition and, during the transition, for the settlement of members’ debts towards third parties, by direct payment to the creditor and according to public rules equal for all. Decisions follow the matrix of Article 7 of Code 3.
4.  No member shall receive money from the Fund as consideration for his or her own contribution; the reimbursement of documented expenses is permitted. The external income of persons remains at their disposal, under the conditions of Article 19-bis. No one may be excluded from the Basket for not having contributed to the Fund.
5.  The Fund may not be used for speculative investments or to generate rent. The reserve shall not exceed the documented requirement of twelve months of necessary external expenses; the excess shall be allocated to the Exit Plans or to mutualism between Circles.
6.  Transfers between the Funds of different Circles shall take place only as mutualism, without interest and without any obligation of repayment. It is prohibited to contract financial debts that give rise to a critical dependency.

### Art. 18 — Suppliers, purchases and commercial practices

1.  In meeting a requirement that calls for recourse to the outside, the following order of preference shall, as a rule, be followed:

    a) other Circles of the Confederation;

    b) cooperatives, non-profit entities and parties of the social economy;

    c) local enterprises;

    d) other suppliers.

2.  The compatibility of the relationship with the supplier shall be assessed separately from the technical conformity of the good or service, which is governed by Code 2. The assessment shall consider at least:

    a) respect for the rights of those who work and the absence of exploitation;

    b) the ecological impact and the treatment of animals;

    c) deceptive practices and the artificial creation of dependencies;

    d) the transparency of the conditions.

3.  Contracts shall be concluded in writing, shall provide for exit clauses and may not contain exclusivity clauses or penalties that give rise to a dependency. They are approved in accordance with the matrix of Article 7 of Code 3.

4.  The exclusion of an individual supplier falls to the competent bodies in accordance with Codes 2 and 3; the exclusion of a category on grounds of principle falls to the General Assembly.

5.  A public register of suppliers and of current contracts shall be kept, with due respect for the levels of transparency of Code 3.

### Art. 19 — Services rendered to the outside and external activities of members

1.  The Circles may dispose of real surpluses to the outside and provide services, without a profit motive. The proceeds shall be paid into the Common Fund.
2.  It is prohibited to organise production according to the external market. The share of CBO allocated to production for the outside shall be resolved by the Assembly and shall not exceed the measure necessary to cover the necessary external purchases.
3.  External working activities carried out by persons during coexistence are free and do not constitute CBO, except for work in the essential supply chains that the Circle counts as CBO during coexistence, under the conditions of Article 16, paragraph 2, letter d), of Code 16. No one may be induced to abandon them.
4.  The sharing with the outside of STVs, Sheets, knowledge and free seeds shall be promoted and shall be carried out under free licences.

### Art. 19-bis — External income and external assets of persons

1.  **Transitional nature.** External income consists of the remuneration, pensions, subsidies, rents and any other receipts that a person obtains from parties external to the Confederation. It exists only for as long as external parties and external means of payment exist, pursuant to Article 3.5-ter of the Constitution. It remains at the disposal of the person.

2.  **Internal neutrality.** External income and external assets confer no advantage in access to the Basket, to the Storehouses, to the commons, to the CdR, to offices or to decisions. Among the members it is prohibited to use them to:

    a) purchase goods or services that the Codes assign according to need;

    b) remunerate the labour of another member or have others perform one’s own CBO;

    c) grant loans at interest or establish rents;

    d) obtain consent, votes or offices.

3.  **Proportional contribution.** Those who receive external income and benefit from the Basket shall contribute to the Common Fund in proportion to that income, because the external expenses borne by the Fund benefit everyone. The rate shall be resolved each year by the Assembly by qualified majority and is equal for all. On first application it is equal to one tenth of the external income, net of taxes and of legal obligations towards third parties, and may not exceed one fifth. The contribution concerns income, not assets.

4.  **Guarantees.** Failure to pay shall not entail exclusion from the Basket or the suspension of the rights of Article 1.2 of the Constitution. It shall be dealt with as non-observance of a common rule in accordance with Code 4, with preference given to mediation and rescheduling.

5.  **Confidentiality and transparency.** Each year the person shall declare to the Accounting Council, in confidential form, the bracket into which his or her external income falls. Only aggregate data per Circle shall be published: number of persons per bracket and total of the contributions. The declaration shall be kept for twelve months and any use other than the calculation of the contribution is prohibited, in conformity with Code 7, Article 2.2.

6.  **Equal access to external expenses.** A share of the Fund, resolved by the Assembly, shall guarantee to those who have no external income the necessary external expenses, including those for documents, legal obligations, care not available in the Confederation and travel for family or health reasons.

7.  **External assets.** The goods that a person owns outside the Confederation remain his or hers in accordance with the legal order in force. They may not be let or given for use against payment to other members, nor used to employ members. Conferral on the entity provided for by Article 16 is voluntary, confers no privileges and makes the good a Common Good.

8.  **Reduction and cessation.** The Exit Plans shall progressively reduce the need for external income. This Article shall cease to apply when the Confederation comprises the whole of humanity: from that moment no external income exists and the Common Funds shall be closed. Until then the option of Article 2, paragraph 9, of Code 16 continues to apply even after the closure of the transition.

### Art. 20 — Strategic autonomy, resource blackmail and countermeasures

1.  For every necessary good or service that lacks an internal alternative, there shall be provided a safety stock pursuant to Article 16 of Code 1, a plurality of suppliers when possible and an Exit Plan.
2.  External resource blackmail occurs when an external party makes the supply of a necessary good or service conditional on a decision of the Circles or on an undue advantage, or threatens its interruption for that purpose.
3.  Countermeasures shall be exclusively lawful and non-violent: activation of the Pool and of federated mutualism, accelerated substitution, termination of the relationship, publicising of the facts, legal protection and recourse to the competent authorities. Retaliation against persons and the causing of damage are prohibited.
4.  In the event of aggression, the non-violent civil defence provided for by Article 16.4 of the Constitution and by Article 8-ter of Code 14 shall apply, within the limits of the law in force pursuant to Article 15, paragraph 2, letter a); sabotage is excluded, as in Article 11, paragraph 2, letter c), of Code 16.

### Art. 21 — Accession of external communities and withdrawal

1.  An external community that requests accession pursuant to Article 4.5 of the Constitution shall sign the Constitution and shall choose whether to join as an associated Community, pursuant to Article 21-bis, or by also adopting the Codes. In the second case it shall apply Code 16 in accordance with Article 3, paragraph 7, of that Code.
2.  The Circle 2 of reference shall verify exclusively the protocols of technological and logistical interoperability and, for the associated Community, the equivalence at the boundary of Article 21-bis and the compliance with the fundamental rules that it declares pursuant to paragraph 6 of that Article. The verification shall be concluded within ninety days and may not introduce further political or ideological assessments.
3.  The withdrawal of a Circle 1 follows Articles 4.6 and 4.7 of the Constitution. The technical arrangements shall be agreed with Circle 2 in such a way as to guarantee the continuity of the Basket for all the persons concerned.

### Art. 21-bis — Associated Communities and equivalence at the boundary

1.  **Fundamental rules and tools.** Pursuant to Article 4.5 of the Constitution, Titles I, IV, V and VII of the Constitution, Articles 19.1, 21, 30.1, 30.2 and 36.1 and the Inviolable Core of Article 37.4 are fundamental rules, binding on every Community. The associated Community is a Base Community for the purposes of the Constitution and of the Codes, except as provided by this Article. The management rules of the Codes, including the CBO and the CdR, the Storehouses, internal bodies and Councils and the forms of their sortition, internal assemblies and quorums, the justice of Code 4 for internal conflicts and the phases of Code 16, are tools. The associated Community keeps its own internal order if it respects the fundamental rules and guarantees the equivalence at the boundary of paragraph 2. The principles of the Inviolable Core remain in force in internal life as well, including the contribution of every able-bodied adult under Article 2.3, sortition, rotation and the prohibition of the professional and permanent exercise of politics and of the judicial function under Articles 4.3, 4.4, 6.5 and 31.2, and the prohibitions of Article 36.1 of the Constitution. The right of every member to vote and deliberate from completion of the fourteenth year, pursuant to Articles 26.2 and 36.1 of the Constitution, also applies in internal decisions.

2.  **Equivalence at the boundary.** The associated Community shall guarantee at the boundary with Circles 2 and 3:

    a) to every member the rights of Article 1.2 of the Constitution, including levels 1 and 2 of the Basket and care, and to anyone present there the guarantees of Article 1.3; the right to leave the Community and the Confederation pursuant to Articles 4.8 and 5.2 of the Constitution; appeal to the common guarantee bodies of paragraph 5 for anyone who claims that one of their rights has been violated;

    b) the inventory of resources and the quarterly declaration of the Balance in the common format of Articles 2 and 3; the ascertainment of Article 3, paragraph 3, is carried out by the body designated by its internal order and is verified by the Storehouse Council of Circle 2. Using the Pool is optional: by way of derogation from Article 3, paragraphs 5 and 6, and from Article 15, paragraph 1-bis, of Code 1, the ascertained Federable Balance of the Community enters the Pool only if it uses the Pool pursuant to paragraph 3. Even if it does not use it, the part of its ascertained Federable Balance consisting of food, water and goods for care is made available to the Pool when another Community has an ascertained deficit of immediate vital needs, according to the priorities of Article 8, paragraph 2, letter a), and the Community receives from the Pool, under the same conditions, the coverage of its own deficits of immediate vital needs;

    c) a share of work for the common functions of Circles 2 and 3 and for the federated share of Article 7, determined for the Community as a whole and not per person, with the same criteria used for the other Communities; the Community distributes it internally in accordance with its own order. During the transition the share may also be rendered in goods; a payment to the Common Fund of Circle 2 for common external expenses is permitted as mutualism pursuant to Article 17, paragraph 6, and does not replace the share of work;

    d) persons on the sortition lists of the common bodies of Circles 2 and 3, on the same conditions as the other Communities;

    e) the individual and secret vote of every member in the General Assemblies, without proxy, pursuant to Articles 34.4 and 36.1 of the Constitution;

    f) the common standards of the goods it exchanges with the other Communities, including the STV of Code 2;

    g) the transit and hospitality of the members of the other Communities, within the limits of the carrying capacity, in accordance with its own order and with at least the equipped stopping area of Article 12.1 of the Constitution.

3.  **Common tools and adopted tools.** When the associated Community uses a common tool, such as the Pool, exchange between Storehouses or the federated Network, it follows its rules. It may adopt individual tools of the Codes at any time, by a resolution taken in accordance with its own order and communicated to Circle 2; from that moment it applies their rules. An adopted tool may be relinquished by the same procedure, with ninety days’ notice and without prejudice to pending procedures. A Community that applies the Codes may become an associated Community only with the majority of Article 4.6 of the Constitution and after the verification of paragraph 6; those who disagree may transfer with the guarantees of Article 5.2 of the Constitution.

4.  **Reference to the Codes.** For the associated Community:

    a) the provisions of the Codes that govern tools of internal management apply only if and from when it adopts them;

    b) the provisions of the Constitution and of the Codes that implement the fundamental rules are valid for the rights, prohibitions and limits that they establish; the internal bodies and procedures through which they implement them may be replaced by bodies and procedures of its internal order that achieve the same result, without prejudice to paragraph 5;

    c) the references of the Constitution and of the Codes to the CBO, to the Storehouses and to the bodies and assemblies of Circle 1 shall be understood, as regards internal life, as references to the corresponding institutions of its internal order; if the corresponding institution is lacking, the body of Circle 2 or a shared body applies. The contribution of work that the internal order requires of every able-bodied adult counts as CBO for the purposes of Articles 2.3 and 4.4 of the Constitution; for the purposes of Article 7.3-bis it counts only within the limit of Article 3 of Code 1 and with the justifications of Article 29, paragraph 3, of Code 4;

    d) the obligations that the Codes impose on members as such, including the CBO of Code 1 and the justice of Code 4 for internal conflicts, apply to the members of the Communities that adopt the Codes, without prejudice to paragraph 5; to the members of the associated Community apply the fundamental rules, the rights of persons and the rules of the common tools they use;

    e) in case of doubt as to whether a provision governs a management tool or implements the fundamental rules, a provision that protects a person or an ecological limit is deemed to implement the fundamental rules; the question may be referred by anyone with an interest to the panel of paragraph 5, letter d).

5.  **Conflicts, guarantees and appeals.** For the associated Community:

    a) offences of Grades 4, 5 and 6 committed within the associated Community always fall within the competence of the Guarantee Tribunal, in accordance with Code 4 and without prejudice to its Article 37. The report of a fact that may constitute an offence of Grade 4, 5 or 6 is transmitted without delay by the internal body, or submitted directly by anyone, to the Guarantee Circle of another Community of Circle 2, drawn by lot for the case, which classifies its grade pursuant to Article 28 of Code 4; the internal order may not withhold it. Until a Circle 2 exists, Article 37, paragraph 5, of Code 4 applies;

    b) the report of Article 8-sexies, paragraph 10, of Code 14 is made to the equivalent internal body and, in copy, to the Guarantee Circle drawn by lot pursuant to letter a), which performs the functions of Article 26-bis, paragraph 5, letters a)–c), and paragraph 6, of Code 4; an excess of Grade 1 or 2 that has been ascertained is referred back to the internal order;

    c) other internal conflicts are resolved in accordance with the internal order; a refusal of the contribution of work that may lead to the measures of Article 7.3-bis of the Constitution is dealt with by the bodies of Articles 27, 28 and 29, paragraphs 4-bis and 6-bis, of Code 4, starting from the report of paragraph 4-bis, letter a), of Article 29; the suspension of the CdR of paragraph 4-bis, letter c), applies only if the Community has adopted the CdR. Conflicts with other Communities follow Code 4, with the mediation of Circle 2 provided for by Article 5.1, letter c), of the Constitution;

    d) anyone who claims that one of their rights has been violated in the associated Community may appeal, under the rules of Article 17 of Code 3, to three members drawn by lot from among the members of the Guarantee Circles of other Communities, belonging to different Communities; Articles 15 and 37, paragraph 5, of Code 4 apply. The appeal is admissible at any time while the violation continues; the panel may annul the internal act and order the measure necessary to restore the right; if the Community does not carry it out, Circle 2 secures the right for the person, including through relocation;

    e) the assessment of autonomy provided for by Article 26.2 and the protection pathway of Article 26.3 of the Constitution and the functions of Articles 7-bis and 7-ter of Code 12 are performed by the Care Council of another Community of Circle 2 or by a shared Care Council or, until the activation of Code 12, by the Health Council of another Community, pursuant to Article 3, paragraph 1, letter f), of Code 16 and, for the assessment of autonomy, by the Competences Council of the same Community or by the shared one, to which anyone may report a case; the separation of a minor follows Article 7-bis, paragraph 3, of Code 12 and is ordered by the Guarantee Circle drawn by lot pursuant to letter a), with validation by the Guarantee Tribunal; during the transition Article 7-bis, paragraph 3-ter, of Code 12 applies;

    f) the measures of Articles 1.3-bis and 7.3-bis of the Constitution and any measure that restricts personal liberty are adopted only by the common bodies, in accordance with Code 4; the urgent measures of Article 34, paragraph 1, of Code 4 may be ordered by the internal body or by the Civic Protection Corps and are validated by the Guarantee Tribunal within twenty-four hours, pursuant to paragraph 2 of the same Article. The internal body that performs the functions of the Civic Protection Corps is subject to Articles 8-ter, 8-quater and 8-quinquies of Code 14; its entry into a Circle 0 is validated by the Guarantee Tribunal pursuant to Article 8-ter, paragraph 3, of that Code;

    g) the internal order may not deprive a member of housing, of the Basket or of care, nor exclude them from the Community; removal is ordered only by the common bodies in the cases provided for by Code 4. If living together is no longer possible, the Community and the person agree with Circle 2 on relocation, with the bridge CBO and the Bridge House allocation of Article 49 of Code 1.

6.  **Verification and Bridging Plan.** The community that applies to join as an associated Community describes its internal order to the extent needed to show how it guarantees paragraph 2 and declares how it complies with the fundamental rules. The Circle 2 of reference, and during the transition the Transition Council of the unit that receives it pursuant to Article 3, paragraph 7, letter c), of Code 16, verifies only the equivalence at the boundary and compliance with the fundamental rules, within ninety days and without political or ideological assessments, pursuant to Article 21, paragraph 2. Until a Basin exists that receives it, the verification is carried out by three persons drawn by lot from the list of Article 37, paragraph 5, of Code 4, belonging to different pilot Circles or kindred entities, within the same limits. The outcome is reasoned and published. If an element is missing, those who carry out the verification and the community agree a Bridging Plan with defined time limits, which changes only what is needed at the boundary and, in internal life, only what does not comply with the fundamental rules; the rest of internal life is not affected. The Plan may not be imposed: until the equivalence and compliance with the fundamental rules are achieved, the community remains external and may connect with the Confederation through agreements pursuant to Chapter IV, without accession. Until a Basin exists that receives it, the functions that this Article and Article 8-bis, paragraph 1, of Code 14 assign to Circle 2 and its bodies are performed by the joint resolution of the pilot Circles and associated Communities involved in the verification, pursuant to Article 14, paragraph 10, of Code 3, and by the panels of Article 37, paragraph 5, of Code 4.

7.  **After accession.** If an element of paragraph 2 ceases to be met or a fundamental rule is no longer complied with, Circle 2 reports it and a Bridging Plan is agreed under the rules of paragraph 6. If the Plan is not agreed or is not implemented within the time limits, the General Assembly of Circle 2 may declare the association terminated, with the guarantees of Article 4.7, letter c), of the Constitution for the persons. The rights of persons and the appeals of paragraph 5 always remain applicable.

8.  **Persons who do not join.** Persons who live permanently in the associated Community without joining personally are not members: they do not vote in the General Assemblies and are not entered on the sortition lists of the common bodies. They may remain there in accordance with the internal order, under the conditions of paragraph 9, or request the Autonomous Coexistence Pact, which may also be agreed with the associated Community, pursuant to Article 4.9, letter c), of the Constitution. The guarantees and rules of Articles 1.3, 4.9, 4.9-bis and 4.9-ter of the Constitution apply to them, except as provided in paragraph 9 for those accommodated by the internal order.

9.  **Cohabitants accommodated by the internal order.** In implementation of Article 4.5 of the Constitution, the limit of Article 4.9, letter b), and Article 4.9-ter of the Constitution do not apply, for as long as the internal order accommodates them, to a person who lives permanently in the associated Community without joining. The following rules apply to them:

    a) they are the responsibility of the Community that hosts them: they do not draw from the Storehouses of the other Communities and of Circles 2 and 3 or from the Pool, not even through the coverage of deficits provided for in paragraph 2, letter b), save for the drinking water, life-saving emergency care and essential energy guaranteed to anyone by Articles 1.3 and 15.2 of the Constitution, and do not receive CdR; otherwise their needs are not included in the Validated Real Need by which the deficit is ascertained; what they receive from the Community that hosts them, including from its Storehouse, is borne by that Community;

    b) the share of work of paragraph 2, letter c), is determined by counting all the persons who live permanently in the Community, members and non-members;

    c) they do not vote in the General Assemblies and are not entered on the sortition lists of the common bodies, pursuant to paragraph 8;

    d) they retain the guarantees of Article 1.3 of the Constitution and appeal to the common bodies of paragraph 5, letter d); any work they do for the Community is voluntary and may not be demanded;

    e) they may join at any time and are informed in writing by the Community, every year, of this right;

    f) if the persons accommodated without joining outnumber the members, the Circle 2 of reference, or whoever carries out the verification pursuant to paragraph 6, verifies every year that there is no exploitation; if exploitation is found, paragraph 5, letter d), and paragraph 7 apply;

    g) Article 4.9-bis, last sentence, of the Constitution and Article 4-bis, paragraph 2, letter f), of Code 10 apply to their minor children; letter a) does not exclude, for minors, the coverage of deficits in immediate vital needs provided for in paragraph 2, letter b).
