---
titolo: "CODICE 4 — DELLA GIUSTIZIA RIPARATIVA E DELLA GARANZIA"
breve: "Codice 4 — Giustizia riparativa e garanzia"
versione: "V1.10"
gruppo: "codici"
ordine: 4
id: "codice-04"
slug: "codice-04"
allineamento: "Costituzione V.39; Codice 1 V1.12; Codice 2 V1.9; Codice 3 V1.13; Codice 5 V1.7; Codice 6 V1.9; Codice 7 V1.10; Codice 8 V1.7; C.1-Annex A V1.7; Codice 9 V3.4; Codice 10 V1.8; Codice 11 V1.6; Codice 12 V1.7; Codice 13 V1.9; Codice 14 V1.10; Codice 15 V1.13; Codice 16 V1.11."
---

## CAPO I — DISPOSIZIONI GENERALI, PRINCIPI E DEFINIZIONI

### Art. 1 — Oggetto, finalità e collocazione sistematica

1.  Il presente Codice disciplina la prevenzione e la gestione dei conflitti, l’accertamento procedurale delle violazioni dei Codici, la riparazione dei danni e, ove possibile, la reintegrazione delle persone e dei Cerchi nella comunità confederale. Disciplina inoltre i gradi di illecito, gli organi giudicanti e le misure di protezione previsti dal Titolo VIII della Costituzione.

2.  Il Codice attua i principi costituzionali di non accumulo del potere, sussidiarietà, centralità della persona, trasparenza differenziata e deliberazione secondo il metodo del consenso per assenza di obiezioni motivate valide.

3.  Nel sistema normativo confederale:

    a) il Codice 1 disciplina i bisogni, il contributo, la produzione e i Magazzini;

    b) il Codice 2 disciplina i criteri di ammissibilità tecnica e qualitativa dei beni e dei servizi, le STV e le SVS, nonché le relative sospensioni, esclusioni e procedure di sostituzione;

    c) il Codice 3 disciplina gli organi decisionali, i procedimenti deliberativi, le soglie, i quorum, le maggioranze e i ricorsi deliberativi;

    d) il presente Codice disciplina la gestione riparativa dei conflitti e dei danni, le garanzie procedurali, le misure cautelari di propria competenza, la verifica degli accordi riparativi e, nel Capo V, gli illeciti e le misure di protezione.

4.  La procedura disciplinata dal presente Codice ha finalità riparativa e preventiva e non afflittiva. Essa opera nell’ordinamento confederale e non sostituisce la giurisdizione statale né limita i diritti riconosciuti dalla Costituzione. Fino al completamento della transizione si applica l’articolo 37.

### Art. 2 — Principi della procedura riparativa

1.  La procedura riparativa si fonda sui seguenti principi:

    a) priorità della riparazione rispetto alla punizione;

    b) volontarietà della partecipazione alla conferenza riparativa, ferme le conseguenze e le misure di tutela previste dai Codici;

    c) ricostruzione dialogica dei fatti, attraverso l’ascolto delle versioni, l’individuazione degli elementi condivisi e contestati e il riconoscimento degli eventuali danni, secondo le modalità dell’Allegato Tecnico;

    d) proporzionalità delle misure rispetto alla condotta, al danno e alle circostanze del caso;

    e) prevenzione della reiterazione della condotta e rimozione, ove possibile, delle cause che l’hanno determinata;

    f) centralità della persona offesa e della comunità direttamente coinvolta;

    g) riservatezza e trasparenza differenziate secondo i livelli previsti dall’articolo 15 del Codice 3;

    h) presunzione di non responsabilità fino alla conclusione della procedura applicabile, fatto salvo il potere di adottare misure cautelari necessarie per la sicurezza, la protezione dei dati o la continuità dei servizi, nei limiti previsti dall’articolo 9;

    i) divieto di ritorsione nei confronti di chi segnala, partecipa o fornisce informazioni in buona fede.

2.  Nessuna disposizione del presente Codice può essere interpretata in modo da imporre alla persona offesa un incontro, un confronto diretto o un accordo riparativo contro la sua volontà.

### Art. 3 — Ambito di applicazione

1.  Il presente Codice si applica alle segnalazioni riguardanti:

    a) la presunta violazione di norme imperative della Costituzione o dei Codici;

    b) i conflitti tra membri o tra Cerchi;

    c) i conflitti di interesse disciplinati dall’articolo 16 del Codice 3;

    d) i danni a beni comuni, infrastrutture o Magazzini disciplinati dal Codice 1;

    e) le violazioni della sovranità dei dati e delle regole sul trattamento previste dal Codice 2, articolo 20, lettera g);

    f) l’inadempimento, la non conformità o la cessazione della fornitura di beni o servizi esterni disciplinati dagli articoli 20 e 24 del Codice 2;

    g) la violazione degli obblighi di trasparenza previsti dall’articolo 15 del Codice 3;

    h) gli illeciti dei Gradi da 1 a 6 disciplinati dal Capo V.

2.  L’applicazione del presente Codice non trasferisce al Cerchio di Garanzia competenze tecniche, sanitarie, allocative o deliberative attribuite ad altri organi.

3.  Quando una segnalazione riguarda più ambiti, le relative procedure sono coordinate ai sensi dell’articolo 23. Ciascun organo conserva la competenza sul profilo attribuitogli dai Codici.

### Art. 4 — Cerchio di Garanzia: natura, composizione, incompatibilità e limiti

1.  È istituito il Cerchio di Garanzia quale organo indipendente preposto alla facilitazione riparativa e alla tutela delle garanzie procedurali previste dal presente Codice.

2.  Il Cerchio di Garanzia:

    a) non esercita poteri deliberativi ordinari o allocativi;

    b) non svolge valutazioni tecniche di conformità o di qualità riservate ad altri organi;

    c) non sostituisce gli organi competenti;

    d) esercita esclusivamente le funzioni di facilitazione riparativa, controllo procedurale, adozione delle misure cautelari attribuitegli e verifica dell’esecuzione degli accordi, e le altre funzioni che la Costituzione e i Codici gli attribuiscono espressamente, nei limiti stabiliti dalla Costituzione e dai Codici.

3.  Il Cerchio di Garanzia non istituisce al proprio interno organi di secondo grado, assemblee allargate o giurisdizioni permanenti. Il riesame è affidato al Collegio esterno disciplinato dall’articolo 17.

4.  Il Cerchio di Garanzia è composto da tre a sette persone, sorteggiate con procedura pubblica e tracciata tra quelle che hanno completato la formazione del comma 5 e dichiarato la propria disponibilità. Nessun componente svolge la funzione per più di novanta giorni consecutivi o per più di centottanta giorni complessivi nell’arco di trecentosessantacinque giorni; il rinnovo avviene a scaglioni, con passaggio di consegne verbalizzato. Tra due turni intercorrono almeno dodici mesi, ai sensi dell’articolo 4.4 della Costituzione. Il Cerchio di Garanzia non può essere accorpato ad alcun Consiglio.

5.  Per accedere al Cerchio di Garanzia è richiesta una formazione iniziale di almeno quaranta ore in materia di giustizia riparativa, facilitazione, Codici 1, 2 e 3 e trattamento dei dati. È inoltre richiesto un aggiornamento annuale di almeno quaranta ore, accompagnato da supervisione periodica. La mancanza della formazione iniziale impedisce l’inserimento nell’elenco dei sorteggiabili.

6.  Le competenze sono separate come segue:

    a) la valutazione tecnica di conformità, l’adozione o applicazione delle STV e delle SVS e l’esclusione tecnica di beni o servizi spettano al Consiglio Qualità, secondo gli articoli 15, 20 e 24 del Codice 2;

    b) i pareri specialistici in materia di salute, sicurezza, infrastruttura digitale o sovranità dei dati e limiti ecologici spettano ai Cerchi competenti, secondo il Codice 3, articolo 8, e il Codice 2, articolo 20, lettera g);

    c) le deliberazioni allocative, la determinazione del livello decisionale, dei quorum e delle maggioranze spettano all’Assemblea del Cerchio 1 o all’Assemblea Generale, secondo gli articoli 7, 7-bis, 7-ter, 7-quater, 12, 13 e 14 del Codice 3;

    d) il calcolo e la certificazione dei valori in UCR e la verifica anti-elusione spettano al Consiglio Contabilità, secondo gli articoli 9 e 11 del Codice 3 e gli articoli 20, comma 6, e 40, comma 4, del Codice 1;

    e) la tutela procedurale, la facilitazione riparativa, l’adozione delle misure cautelari attribuitegli e la qualificazione formale dei vizi deliberativi secondo il Codice 3 spettano al Cerchio di Garanzia.

7.  Nessun organo può cumulare, nel medesimo procedimento, le funzioni di istruttore, decisore e beneficiario diretto della decisione.

## CAPO II — PROCEDURA RIPARATIVA DI PRIMO GRADO

### Art. 5 — Segnalazione e volontarietà

1.  La segnalazione può essere presentata da chiunque abbia un interesse diretto o sia venuto a conoscenza di fatti rilevanti ai fini dell’articolo 3. La registrazione e l’accesso alla segnalazione seguono il livello “aventi diritto” previsto dall’articolo 15 del Codice 3. Su richiesta motivata, la segnalazione è trattata al livello riservato previsto dal medesimo articolo.

2.  Entro sette giorni dalla ricezione, il Cerchio di Garanzia svolge un esame preliminare e comunica una delle seguenti determinazioni:

    a) ammissione alla procedura riparativa;

    b) inammissibilità motivata, con indicazione della ragione e dell’eventuale procedura alternativa disponibile;

    c) proposta di mediazione diretta, quando la natura del conflitto e il consenso delle persone coinvolte la rendano appropriata.

3.  La partecipazione alla conferenza riparativa è volontaria. Il rifiuto di partecipare:

    a) non costituisce ammissione di responsabilità;

    b) non può essere considerato prova della fondatezza della segnalazione;

    c) non impedisce l’adozione delle misure di tutela, continuità, sospensione o esclusione previste dagli articoli 20 e 24 del Codice 2 e dagli articoli 8, 16, 17 e 18 del Codice 3, purché siano rispettati i presupposti e le garanzie stabiliti dai rispettivi Codici.

4.  La presentazione della segnalazione non equivale all’accertamento di una violazione o di una responsabilità.

5.  Il segnalante è informato, entro un termine ragionevole, della ricezione della segnalazione e delle determinazioni preliminari, nei limiti consentiti dalla riservatezza e dalla protezione dei dati delle altre persone coinvolte.

### Art. 6 — Fasi della procedura

1.  La procedura ordinaria si articola nelle seguenti fasi:

    a) presentazione e registrazione della segnalazione ai sensi dell’articolo 5;

    b) esame preliminare di ammissibilità;

    c) ascolto separato delle persone coinvolte, salvo rinuncia espressa e informata;

    d) conferenza riparativa ai sensi dell’articolo 7;

    e) redazione dell’eventuale accordo riparativo ai sensi dell’articolo 8;

    f) esecuzione dell’accordo;

    g) verifica dell’adempimento ai sensi dell’articolo 21;

    h) chiusura della procedura;

    i) eventuale ricorso ai sensi dell’articolo 17.

2.  Il termine ordinario per la conclusione della procedura è di trenta giorni dalla comunicazione di ammissibilità. Il termine può essere prorogato per complessità del caso, indisponibilità motivata delle persone coinvolte o necessità di acquisire pareri specialistici. La proroga è motivata, comunicata alle parti e registrata nel fascicolo.

3.  La documentazione è conservata in un fascicolo di riferimento collegato, per le sole parti pertinenti, alla Relazione Allocativa prevista dall’articolo 10 del Codice 3 e ai livelli di trasparenza stabiliti dall’articolo 15 del medesimo Codice. Il collegamento non autorizza l’accesso a dati personali non necessari alla finalità deliberativa o riparativa.

4.  La procedura può essere sospesa per il tempo strettamente necessario quando:

    a) sia in corso un procedimento tecnico o deliberativo indispensabile per accertare un presupposto;

    b) sussista un rischio per la sicurezza delle persone coinvolte;

    c) una delle parti non possa partecipare per ragioni documentate.

La sospensione è motivata, comunicata alle parti e sottoposta a riesame periodico.

### Art. 7 — Conferenza riparativa

1.  La conferenza riparativa si svolge con la partecipazione:

    a) della persona cui è attribuita la condotta segnalata, se consenziente;

    b) della persona offesa, se consenziente;

    c) del facilitatore designato dal Cerchio di Garanzia;

    d) del Cerchio eventualmente impattato, tramite un referente individuato secondo il Codice 1;

    e) delle persone di supporto ammesse ai sensi dei commi seguenti.

2.  Il confronto diretto tra le parti costituisce modalità ordinaria, ma non è obbligatorio. Il facilitatore può organizzare ascolti separati, comunicazioni indirette o altra modalità idonea, tenendo conto della volontà e della sicurezza delle persone coinvolte.

3.  È ammessa la partecipazione di:

    a) una persona di fiducia scelta da ciascuna parte;

    b) un supporto tecnico specialistico, quando necessario per comprendere una STV o una SVS disciplinata dal Codice 2;

    c) un supporto legale, con funzione di assistenza e senza rappresentanza sostitutiva, salvo quanto previsto dal comma 4;

    d) ulteriori supporti la cui presenza sia necessaria per garantire una partecipazione consapevole e sicura.

4.  La rappresentanza in senso stretto è ammessa esclusivamente nei casi previsti dalla Costituzione o quando una persona non possa partecipare direttamente e le norme applicabili consentano la rappresentanza.

5.  La presenza dei supporti è subordinata al consenso della parte assistita e al rispetto delle regole di riservatezza. Il facilitatore può limitarne la partecipazione solo con motivazione riferita alla sicurezza, alla riservatezza o al corretto svolgimento della conferenza.

6.  Il facilitatore illustra alle parti:

    a) lo scopo e le fasi della conferenza;

    b) il carattere volontario della partecipazione e dell’accordo;

    c) le regole di riservatezza e registrazione;

    d) la possibilità di interrompere o sospendere la conferenza;

    e) le modalità di accesso al ricorso previsto dall’articolo 17.

7.  Il facilitatore assicura che ciascuna parte abbia avuto una possibilità effettiva di esporre la propria versione, senza pressioni, intimidazioni o ritorsioni.

### Art. 8 — Accordo riparativo

1.  L’accordo riparativo, se raggiunto, individua separatamente:

    a) i fatti condivisi;

    b) i fatti che restano contestati;

    c) i danni riconosciuti e quelli contestati;

    d) le misure di riparazione materiale, simbolica o relazionale concordate;

    e) gli impegni futuri e le misure per prevenire la reiterazione;

    f) il Piano di Non Recidiva, quando necessario;

    g) i termini, le modalità e i responsabili dell’esecuzione;

    h) le modalità di verifica;

    i) il trattamento, la conservazione e il livello di accesso ai dati relativi all’accordo.

2.  L’accordo può prevedere la riparazione di un danno riconosciuto anche quando le parti non concordino su tutti i fatti. La confessione integrale non può essere imposta né può costituire condizione per accedere alla procedura.

3.  L’accordo è redatto per iscritto e sottoscritto dalle parti partecipanti e dal facilitatore. È registrato al livello “aventi diritto” previsto dall’articolo 15 del Codice 3, salvo che una diversa classificazione sia necessaria e motivata per proteggere dati personali o informazioni riservate.

4.  L’accordo non può derogare alla Costituzione o a norme imperative dei Codici. Si applica l’articolo 2, comma 2, del Codice 3.

5.  Nessuna misura dell’accordo può imporre lavoro degradante, pericoloso o sproporzionato, né incidere su diritti fondamentali o sull’accesso al Paniere al di fuori dei casi e delle procedure previsti dai Codici.

6.  Se non è raggiunto un accordo, il facilitatore ne dà atto senza formulare giudizi di responsabilità. Restano disponibili le procedure previste dagli altri Codici, purché siano rispettate le competenze e le garanzie applicabili.

### Art. 9 — Misure cautelari e continuità

1.  Quando la segnalazione riguarda una decisione allocativa, il Cerchio di Garanzia valuta la sussistenza dei presupposti per le misure cautelari previste dall’articolo 17 del Codice 3.

2.  Entro settantadue ore dalla richiesta o dalla conoscenza di un rischio urgente, il Cerchio di Garanzia può adottare, con provvedimento motivato:

    a) la sospensione cautelare della decisione contestata, nei limiti consentiti dall’articolo 17 del Codice 3;

    b) l’imposizione o la richiesta di un piano di continuità, secondo l’articolo 17 del Codice 3 e l’articolo 24 del Codice 2;

    c) misure temporanee strettamente necessarie a preservare la sicurezza delle persone o l’efficacia del riesame.

3.  Deve essere preservata, ove tecnicamente possibile, la continuità dei servizi critici, compresi connettività, servizi digitali, manutenzione infrastrutturale e servizi sanitari specialistici. La sospensione che provochi un danno maggiore di quello derivante dal vizio contestato è vietata, secondo l’articolo 17, comma 4, del Codice 3, salvo che la prosecuzione comporti un rischio grave e immediato non altrimenti contenibile.

4.  La misura cautelare non costituisce accertamento anticipato di responsabilità. È riesaminata quando mutano i fatti o le condizioni che ne hanno giustificato l’adozione e cessa quando vengono meno i relativi presupposti.

5.  Il provvedimento indica la durata, le condizioni per la cessazione, gli eventuali obblighi di continuità e la procedura di riesame.

### Art. 10 — Raccordo con la disciplina dei vizi deliberativi

1.  La disciplina sostanziale della nullità, dell’annullabilità e dell’irregolarità sanabile è contenuta esclusivamente nell’articolo 18 del Codice 3.

2.  Il Cerchio di Garanzia non introduce categorie autonome di invalidità. Accerta e applica, nei limiti della propria competenza, gli effetti previsti dall’articolo 18 del Codice 3.

3.  Quando rileva elementi che possono integrare una nullità grave, il Cerchio di Garanzia:

    a) avvia, se necessario, una procedura riparativa d’ufficio;

    b) informa l’organo competente a rinnovare o correggere il procedimento;

    c) trasmette gli elementi pertinenti all’organo competente, rispettando i livelli di trasparenza e riservatezza;

    d) indica la disposizione del Codice 3 che può risultare violata.

4.  Ai fini del comma 3, costituiscono esempi di possibili vizi gravi:

    a) il conflitto di interessi occultato, ai sensi dell’articolo 16 del Codice 3;

    b) l’aggiramento di un parere vincolante negativo, ai sensi dell’articolo 8 del Codice 3;

    c) l’assenza della Relazione Allocativa, quando obbligatoria ai sensi dell’articolo 10 del Codice 3.

5.  La qualificazione e gli effetti del vizio restano disciplinati dal Codice 3. L’avvio della procedura riparativa non sostituisce il procedimento necessario per il rifacimento o la convalida dell’atto.

## CAPO III — MISURE RIPARATIVE, ESCLUSIONE E REGISTRO

### Art. 11 — Tipologie di misure riparative

1.  In relazione al caso e con il consenso richiesto, l’accordo riparativo può prevedere una o più delle seguenti misure:

    a) restituzione di beni o risorse;

    b) riparazione materiale del danno;

    c) attività a beneficio della comunità, nel rispetto delle garanzie del Codice 1;

    d) formazione o aggiornamento pertinenti alla condotta e alla prevenzione di nuovi danni;

    e) scuse formali o riconoscimento del danno, se liberamente concordati;

    f) limitazione temporanea di specifici ruoli deliberativi o di rappresentanza, solo se disposta dall’organo competente e secondo le procedure applicabili;

    g) accompagnamento, supervisione o verifica temporanea;

    h) misure organizzative volte a rimuovere le cause del conflitto o della violazione.

2.  La misura deve indicare il soggetto responsabile, la durata, le modalità di esecuzione e i criteri per dichiararne l’adempimento.

3.  Nessuna misura può eccedere le competenze del Cerchio di Garanzia o sostituire una deliberazione richiesta da un altro Codice.

### Art. 12 — Proporzionalità e limiti delle misure

1.  La misura riparativa è proporzionata alla gravità della condotta, al grado di intenzionalità, all’eventuale reiterazione, all’entità del danno e agli effetti sistemici sui beni comuni o sui Magazzini disciplinati dal Codice 1.

2.  La valutazione considera anche:

    a) la condotta successiva ai fatti;

    b) la collaborazione alla ricostruzione e alla riparazione, senza attribuire al silenzio o al rifiuto di partecipare valore di ammissione;

    c) la vulnerabilità delle persone coinvolte;

    d) la possibilità di prevenire la reiterazione con misure meno restrittive.

3.  Non sono ammesse misure afflittive. Restano ferme l’esclusione di categoria disposta per principio esclusivamente dall’Assemblea Generale, ai sensi dell’articolo 14 del Codice 3, e le misure di protezione del Capo V.

4.  Le misure che incidono su funzioni essenziali, diritti o accesso a servizi sono ammesse soltanto nei casi e con le garanzie stabiliti dalla Costituzione e dai Codici competenti.

### Art. 13 — Esclusione quale misura di extrema ratio e riparto delle competenze

1.  Le competenze in materia di esclusione sono ripartite come segue:

    a) il Codice 2 e il Consiglio Qualità valutano la non conformità tecnica di beni o servizi e, quando ne ricorrono i presupposti, dispongono la cessazione, la sostituzione o la migrazione secondo gli articoli 20 e 24 del Codice 2. Deve essere predisposto un Piano di Sostituzione e Continuità quando richiesto da tali disposizioni;

    b) il Cerchio di Garanzia gestisce il profilo riparativo e relazionale e può facilitare un Piano di Non Recidiva;

    c) il Codice 3 e gli organi da esso individuati determinano il livello deliberativo, il quorum e la maggioranza applicabili, secondo la matrice dell’articolo 7 e gli articoli 12, 13 e 14 del Codice 3.

2.  L’esclusione temporanea di un fornitore, o la limitazione temporanea dei ruoli e delle funzioni di un membro, può essere proposta o disposta soltanto dall’organo competente e dopo aver valutato:

    a) il fallimento documentato delle misure riparative ragionevolmente praticabili;

    b) il rifiuto di partecipare, senza che tale rifiuto costituisca prova di responsabilità;

    c) la gravità e l’eventuale reiterazione della violazione;

    d) la necessità e proporzionalità della misura;

    e) le garanzie procedurali e i rimedi previsti dai Codici.

3.  L’esclusione definitiva di un fornitore o l’esclusione di categoria per principio è deliberata esclusivamente dall’Assemblea Generale ai sensi dell’articolo 14 del Codice 3.

4.  La proposta di esclusione definitiva o di categoria è motivata e accompagnata dall’istruttoria tecnica del Consiglio Qualità, quando pertinente. Il Cerchio di Garanzia può riferire sugli aspetti procedurali e riparativi, ma non sostituisce l’istruttoria tecnica o la deliberazione dell’Assemblea Generale.

5.  Ai fini del riparto delle competenze:

    a) l’esclusione tecnica di un bene o servizio compete al Consiglio Qualità e agli organi deliberativi indicati dal Codice 2;

    b) le misure riparative e relazionali sono trattate dal Cerchio di Garanzia, mentre le limitazioni di status o ruolo sono disposte dall’organo individuato dai Codici;

    c) l’esclusione definitiva o di categoria per principio compete all’Assemblea Generale.

6.  La decadenza di una persona dallo status di membro è ammessa esclusivamente nei casi dell’articolo 1.3-bis della Costituzione e secondo il Capo V. La cessazione dello status per rifiuto persistente del CBO, prevista dall’articolo 7.3-bis della Costituzione, è disciplinata soltanto dall’articolo 29, comma 6-bis. Nessuna misura del presente articolo può privare un membro dei diritti dell’articolo 1.2 della Costituzione.

### Art. 13-bis — Verifica di conformità e disattivazione di attività e funzioni

1.  Quando i Codici rinviano al presente Codice per la verifica di conformità, la sospensione o la disattivazione di un’attività, di una funzione o di un’infrastruttura non conforme, si applicano le regole seguenti, salvo le disposizioni più specifiche del Codice di settore:

    a) la verifica di conformità è una valutazione tecnica del Consiglio competente secondo il Codice di settore; il Cerchio di Garanzia non la svolge, ai sensi dell’articolo 4, comma 2, lettera b);

    b) se l’adeguamento è tecnicamente impossibile, la disattivazione è deliberata dall’Assemblea del Cerchio 1 o, per le funzioni dei Cerchi 2 e 3, dall’Assemblea Generale, su proposta motivata del Consiglio competente, con le procedure dell’articolo 7 del Codice 3 quando la matrice le richiede;

    c) la proposta è accompagnata da un Piano di Sostituzione con termine finale certo. Quando la funzione garantisce prestazioni dei livelli 1 e 2 del Paniere, la disattivazione ha effetto soltanto dopo l’attivazione della funzione sostitutiva, salvo le misure urgenti della lettera d);

    d) la sospensione necessaria a fronteggiare un rischio grave e immediato è adottata secondo il Codice di settore e il Codice 14 ed è comunicata senza ritardo all’Assemblea;

    e) restano ferme le garanzie, le misure cautelari e i ricorsi del presente Codice e dell’articolo 17 del Codice 3. Quando la non conformità è imputabile a una persona, l’accertamento e le eventuali misure nei suoi confronti seguono i Capi II e V.

### Art. 14 — Registro riparativo

1.  Il Cerchio di Garanzia cura il Registro riparativo secondo i livelli di trasparenza previsti dall’articolo 15 del Codice 3. Il Registro distingue:

    a) dati pubblici aggregati e anonimizzati, comprese statistiche ed esiti complessivi;

    b) le informazioni relative al Registro Esclusioni previsto dall’articolo 15 del Codice 3, accessibili secondo le regole stabilite dal medesimo articolo;

    c) accordi, istruttorie, obiezioni e pareri accessibili agli aventi diritto;

    d) dati personali, credenziali e informazioni sulla sicurezza delle infrastrutture, accessibili esclusivamente ai soggetti autorizzati ai sensi dell’articolo 20, lettera g), del Codice 2 e delle disposizioni del Codice 6 in materia di dati sanitari.

2.  Il Registro riporta per ciascun procedimento almeno un identificativo, la data di apertura, lo stato della procedura, la data di chiusura e l’esito nella forma compatibile con il livello di trasparenza applicabile.

3.  È vietata la pubblicazione di informazioni finalizzata alla gogna, alla ritorsione o alla stigmatizzazione di una persona.

4.  Gli obblighi di trasparenza non autorizzano la divulgazione di dati personali o la violazione della sovranità dei dati.

5.  I tempi di conservazione, la rettifica, la cancellazione e l’accesso ai dati sono disciplinati dai Codici 2 e 7 e, per i dati sanitari, dal Codice 6.

## CAPO IV — TUTELE, RICORSI E DISPOSIZIONI FINALI

### Art. 15 — Terzietà, astensione e sostituzione

1.  Il componente del Cerchio di Garanzia che abbia un interesse personale nel caso, un rapporto diretto con una parte o altra circostanza idonea a comprometterne l’imparzialità dichiara il conflitto e si astiene.
2.  Le parti possono segnalare un possibile conflitto di interesse con istanza motivata. La decisione sull’astensione è adottata senza la partecipazione del componente interessato e verbalizzata.
3.  Se il conflitto riguarda l’intero Cerchio di Garanzia, i componenti sono sostituiti mediante sorteggio tra membri formati di altri Cerchi, secondo il meccanismo previsto dall’articolo 4, comma 4, del Codice 3 per la valutazione della validità delle obiezioni con soggetto sostitutivo indipendente.
4.  Il componente sostituto non può aver partecipato all’istruttoria contestata né avere un interesse diretto nell’esito.

### Art. 16 — Protezione del segnalante e divieto di ritorsione

1.  È vietata qualsiasi ritorsione nei confronti di chi presenta una segnalazione, partecipa a una procedura o fornisce informazioni in buona fede.
2.  La ritorsione costituisce una violazione autonoma e può determinare l’apertura di una nuova procedura ai sensi dell’articolo 5.
3.  Il Cerchio di Garanzia valuta, su richiesta o d’ufficio, le misure di protezione necessarie per prevenire intimidazioni, pressioni o pregiudizi durante la procedura.
4.  Le misure di protezione sono proporzionate, temporanee, motivate e non possono essere utilizzate per anticipare un giudizio di responsabilità.

### Art. 17 — Ricorso e Collegio di Riesame esterno

1.  Il primo grado si svolge mediante la procedura e, se raggiunto, l’accordo riparativo disciplinati dagli articoli 6, 7 e 8.

2.  La parte interessata può presentare ricorso entro quattordici giorni dalla comunicazione dell’esito di primo grado. Il ricorso è ammesso esclusivamente per:

    a) violazione delle regole procedurali;

    b) manifesta sproporzione della misura;

    c) violazione della Costituzione o di una norma imperativa dei Codici.

3.  Il ricorso è esaminato da un Collegio di Riesame ad hoc, esterno al Cerchio di Garanzia che ha gestito il primo grado e non permanente, composto da:

    a) un facilitatore formato, sorteggiato tra persone non appartenenti al Cerchio di Garanzia che ha gestito il caso;

    b) un componente del Consiglio Qualità non coinvolto nell’istruttoria contestata ai sensi del Codice 2;

    c) una persona sorteggiata tra i membri dell’Assemblea di un Cerchio 1 diverso da quello direttamente interessato, priva di poteri deliberativi allocativi nel procedimento di riesame.

4.  Il sorteggio è tracciato al livello previsto dall’articolo 15 del Codice 3. Nessun componente del primo grado può partecipare al secondo grado. Si applicano le regole di astensione e sostituzione dell’articolo 15 del presente Codice.

5.  Il Collegio è costituito per il singolo ricorso, decide entro quattordici giorni dalla costituzione e si scioglie una volta comunicata la decisione. La decisione non costituisce precedente vincolante e riguarda esclusivamente il caso esaminato. È pubblicata nell’Archivio previsto dall’articolo 35-bis.

6.  Per la validità della seduta è necessaria la presenza di tutti e tre i componenti. Il Collegio decide secondo il metodo del consenso previsto dall’articolo 4 del Codice 3. Se il consenso non è raggiunto, decide a maggioranza con motivazione; il dissenso è registrato secondo gli articoli 10 e 13 del Codice 3.

7.  Il Collegio può:

    a) confermare l’esito impugnato;

    b) annullarlo per vizio procedurale e rinviare il caso a una nuova conferenza con un facilitatore diverso;

    c) rimodulare la misura quando risulti manifestamente sproporzionata.

Il Collegio non può disporre un’esclusione definitiva o di categoria, riservata all’Assemblea Generale ai sensi dell’articolo 14 del Codice 3.

8.  Se il ricorso è presentato esclusivamente dalla persona destinataria della misura, il Collegio non può aggravare la misura impugnata.
9.  La decisione è registrata e comunicata alle parti secondo i livelli di trasparenza previsti dall’articolo 15 del Codice 3.

### Art. 18 — Connessione con il Codice 1: fabbisogno, produzione e Magazzini

1.  Quando la condotta segnalata ha causato un danno a beni comuni o ai Magazzini disciplinati dal Codice 1, la procedura valuta prioritariamente la riparazione materiale del danno e, ove necessario, un Piano di Non Recidiva.
2.  Il Cerchio di competenza produttivo può essere coinvolto per accertare le modalità tecniche di riparazione, senza assumere funzioni di accertamento della responsabilità riservate alla procedura applicabile.
3.  Per la verifica del danno e della relativa tracciabilità si applicano gli articoli 17 e 26 del Codice 1.

### Art. 19 — Connessione con il Codice 2: qualità, STV, SVS ed esclusioni

1.  La valutazione tecnica di conformità, l’applicazione delle STV e delle SVS e l’esclusione tecnica di beni o servizi competono al Consiglio Qualità secondo gli articoli 15, 20 e 24 del Codice 2. Il calcolo e la certificazione dei valori in UCR competono al Consiglio Contabilità secondo l’articolo 9 del Codice 3.
2.  La sovranità dei dati, la localizzazione, la gestione delle chiavi, i subfornitori e la giurisdizione sono disciplinati dall’articolo 20, lettera g), del Codice 2.
3.  Il Cerchio di Garanzia non valuta la conformità tecnica delle STV o delle SVS. Può esaminare esclusivamente i profili procedurali e riparativi che rientrano nella propria competenza.
4.  Quando la valutazione tecnica è necessaria per la procedura riparativa, il Cerchio di Garanzia richiede il parere all’organo competente senza sostituirsi ad esso.

### Art. 20 — Connessione con il Codice 3: deliberazione, soglie e Assemblea

1.  Le tipologie di decisione operativa, allocativa e costitutiva sono disciplinate dall’articolo 3 del Codice 3.
2.  Le obiezioni motivate, il metodo del consenso e la valutazione della validità delle obiezioni sono disciplinati dall’articolo 4 del Codice 3.
3.  Le soglie economiche e la metodologia delle UCR sono disciplinate dagli articoli 5 e 9 del Codice 3.
4.  La soglia di rischio, la valutazione preliminare documentata, la conferma nella STV o SVS definitiva e la prevalenza del livello più elevato sono disciplinate dagli articoli 6 e 7, comma 2, del Codice 3.
5.  La matrice vincolante, le procedure speciali o rafforzate e le relative garanzie sono disciplinate dagli articoli 7, 7-bis, 7-ter e 7-quater del Codice 3.
6.  I pareri vincolanti negativi e il divieto di aggirarli sono disciplinati dall’articolo 8 del Codice 3.
7.  La Relazione Allocativa è disciplinata dall’articolo 10 del Codice 3.
8.  Le disposizioni anti-elusione, la prevedibilità e la presunzione di 180 giorni sono disciplinate dall’articolo 11 del Codice 3.
9.  La composizione dell’Assemblea del Cerchio 1, la partecipazione, i quorum e il trattamento delle astensioni sono disciplinati dall’articolo 12 del Codice 3. I Consigli tecnici sono disciplinati dall’articolo 12-bis del medesimo Codice.
10. La decisione assembleare, la mediazione, la maggioranza qualificata e il denominatore dei partecipanti attivi, con esclusione degli astenuti nei casi previsti, sono disciplinati dall’articolo 13 del Codice 3. L’Obiezione di Coscienza o di Sostenibilità Ecologica è disciplinata dall’articolo 13-bis del medesimo Codice.
11. L’Assemblea Generale, la calibrazione delle soglie, l’esclusione di categoria per principio, la prima calibrazione entro sei mesi e la revisione almeno annuale sono disciplinate dall’articolo 14 del Codice 3.
12. La trasparenza differenziata è disciplinata dall’articolo 15 del Codice 3.
13. I conflitti di interesse sono disciplinati dall’articolo 16 del Codice 3.
14. Il ricorso e la continuità dei servizi sono disciplinati dall’articolo 17 del Codice 3.
15. Gli effetti della nullità, dell’annullabilità e dell’irregolarità sanabile sono disciplinati dall’articolo 18 del Codice 3.
16. Lo status e gli effetti degli Allegati Tecnici vincolanti per le metodologie sono disciplinati dall’articolo 19 del Codice 3.
17. I collegamenti intercodice e i relativi rinvii sono disciplinati dall’articolo 20 del Codice 3.

### Art. 21 — Verifica dell’adempimento

1.  Il Cerchio di Garanzia verifica l’adempimento degli accordi riparativi, di norma, a tre e a sei mesi dalla loro sottoscrizione. L’accordo può stabilire scadenze diverse quando la natura della misura lo richieda.

2.  La verifica è limitata agli obblighi previsti dall’accordo e non comporta controlli ulteriori sulla persona.

3.  In caso di inadempimento, il Cerchio di Garanzia ascolta le parti interessate e valuta:

    a) se l’inadempimento sia giustificato da un impedimento sopravvenuto;

    b) se sia possibile modificare i termini o le modalità di esecuzione;

    c) se sia necessario riaprire la conferenza con un facilitatore diverso;

    d) se sussistano i presupposti per proporre una misura ulteriore ai sensi dell’articolo 13.

4.  L’inadempimento non determina automaticamente l’esclusione o una sanzione. Le eventuali conseguenze sono adottate dall’organo competente secondo i Codici applicabili.

### Art. 22 — Riservatezza

1.  L’esito della procedura può essere pubblicato in forma aggregata. I dettagli personali restano riservati secondo i livelli di trasparenza previsti dall’articolo 15 del Codice 3 e dall’articolo 20, lettera g), del Codice 2.
2.  Le parti sono informate prima della conferenza delle modalità di registrazione, conservazione, accesso e pubblicazione dei dati. Il consenso delle parti non può derogare agli obblighi di protezione dei dati o autorizzare la divulgazione di informazioni appartenenti a terzi.
3.  I documenti della procedura sono accessibili esclusivamente ai soggetti autorizzati e nella misura necessaria allo svolgimento delle rispettive funzioni.
4.  Le informazioni raccolte nella procedura non possono essere riutilizzate per finalità incompatibili, né per profilazione, ritorsione o stigmatizzazione.

### Art. 23 — Divieto di duplicazione e coordinamento delle procedure

1.  La medesima condotta non può essere sottoposta a procedimenti paralleli aventi lo stesso oggetto e la stessa funzione.

2.  Sono ammesse procedure coordinate quando riguardano profili distinti e non duplicativi, tra cui:

    a) il profilo deliberativo disciplinato dal Codice 3;

    b) il danno alla persona o alla comunità;

    c) la violazione delle regole sui dati prevista dall’articolo 20, lettera g), del Codice 2;

    d) il rischio per la continuità dei servizi previsto dall’articolo 17 del Codice 3 e dall’articolo 24 del Codice 2;

    e) il profilo tecnico di competenza del Codice 2.

3.  Nei procedimenti coordinati è individuato un fascicolo di riferimento. La comunicazione tra gli organi è limitata alle informazioni necessarie e indica con chiarezza:

    a) l’oggetto di ciascun procedimento;

    b) l’organo competente per ciascun profilo;

    c) i pareri richiesti e acquisiti;

    d) le misure cautelari eventualmente adottate;

    e) i termini e gli effetti delle decisioni.

4.  La procedura coordinata non attribuisce a un organo la competenza spettante a un altro e non consente di duplicare misure o conseguenze per il medesimo fatto.

### Art. 24 — Entrata in vigore, Allegato Tecnico e compatibilità costituzionale

1.  Il presente Codice entra in vigore secondo la disposizione di coordinamento approvata con i Codici 2 e 3.
2.  L’Allegato Tecnico sulle Procedure Riparative integra il presente Codice e vincola le metodologie applicative nei limiti previsti dall’articolo 19 del Codice 3. L’Allegato si applica alle procedure disciplinate dagli articoli 2, 5, 6, 7, 8 e 11 del presente Codice.
3.  Il presente Codice attua i principi costituzionali di non accumulo del potere, sussidiarietà, consenso, trasparenza differenziata e garanzia procedurale. In caso di contrasto prevale la Costituzione.
4.  Prima del deposito definitivo della versione, è svolta una simulazione su un campione compreso tra otto e dieci casi concreti, costruiti sulla matrice dell’articolo 7 del Codice 3 e sulle procedure riparative dell’articolo 6 del presente Codice. Gli esiti della simulazione sono documentati e usati per individuare eventuali ambiguità redazionali o procedurali.

## CAPO V — ILLECITI, ORGANI GIUDICANTI E MISURE DI PROTEZIONE

### Art. 25 — Principi e garanzie comuni

1.  Il presente Capo attua gli articoli 1.3-bis, 7.3, 7.3-bis, 17.9, 18.7, 30 e 31 della Costituzione. La procedura riparativa dei Capi II, III e IV resta la via ordinaria e prioritaria. Gli organi del presente Capo intervengono quando essa non è accettata, non produce un accordo o non è adeguata alla gravità del fatto.

2.  Nessuno può essere sottoposto a una misura per un fatto che, al momento in cui è stato commesso, non era previsto come illecito dalla Costituzione o dai Codici. Le fattispecie non possono essere estese per analogia.

3.  La persona è presunta non responsabile fino alla decisione definitiva. Per i Gradi 4, 5 e 6 la responsabilità deve essere provata oltre ogni ragionevole dubbio. Il silenzio e il rifiuto di partecipare non valgono come ammissione.

4.  La persona cui è attribuito il fatto ha diritto:

    a) di conoscere i fatti contestati e gli elementi raccolti;

    b) ai due facilitatori di fiducia e alla persona di fiducia previsti dall’articolo 31.5 della Costituzione;

    c) di essere ascoltata, di presentare elementi e di chiedere l’ascolto di altre persone;

    d) a una decisione scritta e motivata;

    e) al riesame previsto dall’articolo 35.

5.  La persona offesa ha diritto alla protezione immediata, all’ascolto, a una persona di fiducia, all’informazione sull’andamento della procedura e alla riparazione. Non può esserle imposto alcun incontro con la persona cui è attribuito il fatto.

6.  Nessuna misura può avere finalità afflittiva. Tra le misure idonee è scelta la meno restrittiva. Nessuna misura può sopprimere le garanzie vitali dell’articolo 30.4 della Costituzione. Dopo la cessazione dello status prevista dall’articolo 29, comma 6-bis, alla persona restano garantiti i diritti dell’ultimo periodo dell’articolo 1.3 e dell’articolo 4.9 della Costituzione e la porzione assegnata ai sensi del suo articolo 7.3-bis.

7.  Ogni organo può essere assistito da un’IA di mediazione esclusivamente consultiva. Nessuna valutazione di responsabilità o di pericolosità può essere formulata o prevista da un’IA.

8.  Nessuno può essere giudicato due volte per lo stesso fatto. Si applica l’articolo 23.

9.  Ai fatti commessi da persone che non hanno compiuto diciotto anni si applicano esclusivamente misure riparative, educative e di protezione, definite con il Consiglio Cura e con il Consiglio delle Competenze. Non si applicano l’articolo 30, comma 3, e gli articoli 31, 32 e 33. Quando sussiste un pericolo concreto e attuale per l’incolumità altrui che le altre misure non possono contenere, il Tribunale di Garanzia, con la decisione definitiva che accerta un fatto di Grado 4, 5 o 6, può disporre, con sei voti su sette, un’accoglienza educativa protetta: la persona risiede presso persone o in una comunità educativa individuate con il Consiglio Cura, aperte, senza perimetro protetto né sorveglianza del Corpo di Tutela Civica, con un progetto educativo, un affiancamento quotidiano e la continuità dell’apprendimento e dei contatti con le persone care. L’accoglienza dura non più di dodici mesi ed è rinnovabile una sola volta con una nuova decisione; è riesaminata dal Tribunale almeno ogni tre mesi e cessa quando viene meno il pericolo. Se la persona compie diciotto anni durante l’accoglienza, questa prosegue entro la stessa durata in una collocazione adatta all’età.

### Art. 26 — Gradi di illecito

1.  Gli illeciti sono ordinati in sei gradi, ai sensi dell’articolo 30.2 della Costituzione:

    a) **Grado 1:** inosservanza lieve di una regola comune o conflitto che non ha prodotto un danno apprezzabile;

    b) **Grado 2:** violazione che ha prodotto un danno limitato e riparabile a una persona, a un animale o ai beni comuni;

    c) **Grado 3:** violazione grave o reiterata dei doveri di corresponsabilità, o danno rilevante ai beni comuni, senza violenza alla persona. Vi rientrano il rifiuto del CBO protratto oltre sessanta giorni senza giustificazione, ai sensi dell’articolo 7.3 della Costituzione; l’accumulo privato e la rendita vietati dalla Costituzione e dai Codici; la ritorsione contro chi segnala; la violazione grave delle regole sui dati; il maltrattamento di animali;

    d) **Grado 4:** attacco alle garanzie comuni o violenza alla persona che non rientra nei Gradi 5 e 6. Vi rientrano i fatti che la Costituzione qualifica di Grado 4 agli articoli 4.4, 15.2, 16.1, 16.5, 17.5 e 18.6; il ricatto relativo a risorse previsto dall’articolo 11 del Codice 15; l’acquisto o lo scambio del voto; la minaccia grave; le percosse e le lesioni non gravi; il danneggiamento doloso di infrastrutture vitali; l’uccisione o la sevizia di animali;

    e) **Grado 5:** violenza grave contro la persona. Vi rientrano le lesioni gravi volontarie, la violenza sessuale, gli atti sessuali con minori, il sequestro di persona e la riduzione di una persona in condizione di servitù;

    f) **Grado 6:** omicidio volontario, tortura e fatti di Grado 5 che hanno cagionato la morte o lesioni permanenti gravissime o sono stati commessi in danno di più persone.

2.  La qualificazione del grado spetta all’organo competente, con decisione motivata. In caso di dubbio si applica il grado inferiore.

3.  I Codici possono qualificare specifiche condotte entro i Gradi da 1 a 4. Le fattispecie dei Gradi 5 e 6 sono esclusivamente quelle del presente articolo. L’uso della forza nella difesa personale è qualificato secondo l’articolo 26-bis.

### Art. 26-bis — Difesa personale: non illiceità, eccesso e accertamento

1.  Non costituiscono illecito l’uso della forza, l’interposizione, il trattenimento e l’ingresso in un Cerchio 0 compiuti nei limiti dell’articolo 17.9 della Costituzione e dell’articolo 8-sexies del Codice 14, compresa la difesa da un animale che aggredisce una persona prevista dal comma 8 di quell’articolo.

2.  Non costituisce illecito l’eccesso, né l’errore sull’esistenza, sull’imminenza, sulla durata o sulla gravità dell’aggressione o del maltrattamento, dovuto a spavento, panico o turbamento scusabili nelle circostanze concrete. La scusabilità è valutata secondo le circostanze come apparivano alla persona nel momento del fatto, tenendo conto in particolare della rapidità degli eventi, della differenza di forza, dell’età, delle condizioni fisiche e psichiche della persona e delle violenze che essa aveva già subito dall’aggressore. Non è scusabile l’errore di chi ha cercato lo scontro per poter usare la forza, né quello di chi ha agito per il solo timore di un’aggressione futura, senza un pericolo concreto e immediato.

3.  Fuori dal caso del comma 2, l’uso della forza oltre lo stretto necessario, durante un’aggressione o un maltrattamento in corso e allo scopo di farli cessare, costituisce illecito di Grado 4, anche quando ne sono derivate lesioni gravi o la morte. Quando l’eccesso ha cagionato soltanto un danno lieve e riparabile costituisce illecito di Grado 2; quando non ha cagionato alcun danno apprezzabile, di Grado 1.

4.  L’uso della forza che non costituisce difesa ai sensi dell’articolo 8-sexies, comma 5, del Codice 14, compresa la forza diretta a uccidere o a ferire gravemente quando non era necessaria a far cessare l’aggressione, è qualificato secondo l’articolo 26, comma 1. L’aggressione subita è considerata nella scelta delle misure.

5.  L’accertamento si svolge come segue:

    a) il Cerchio di Garanzia riceve la comunicazione prevista dall’articolo 8-sexies, comma 10, del Codice 14, o la segnalazione ai sensi dell’articolo 5, apre il fascicolo, ascolta separatamente le persone coinvolte ai sensi dell’articolo 28, comma 2, e attiva la protezione di chi ne ha bisogno;

    b) il Cerchio di Garanzia trasmette senza ritardo il caso al Tribunale di Garanzia quando dal fatto sono derivate la morte o lesioni gravi; quando vi sono elementi di un eccesso non scusabile o di un fatto previsto dal comma 4; quando la forza è stata usata tra persone che appartengono allo stesso Cerchio 0 o vi convivono, o contro un minore o una persona che non è in grado di tutelarsi; quando la forza è stata usata da o contro un componente del Corpo di Tutela Civica; quando lo chiede la persona contro cui la forza è stata usata, la persona difesa o chi ha usato la forza;

    c) negli altri casi il Cerchio di Garanzia, se non emergono elementi di illecito, lo comunica con determinazione motivata alle persone coinvolte ai sensi dell’articolo 5, comma 2, lettera b). La determinazione non accerta la responsabilità e non impedisce la richiesta di trasmissione della lettera b);

    d) il Tribunale di Garanzia accerta se sono stati rispettati i limiti dell’articolo 8-sexies del Codice 14, se ricorre il comma 2 e, in caso contrario, il grado. Quando resta un dubbio ragionevole sulla sussistenza della difesa, la responsabilità per l’uso della forza non è accertata, ai sensi dell’articolo 25, comma 3. Quando più persone invocano la difesa, il Tribunale accerta chi ha iniziato l’aggressione. Quando accerta un eccesso di Grado 1 o 2, il Tribunale trasmette il caso al Cerchio di Garanzia per la procedura dell’articolo 28, comma 1, lettera a); l’accertamento dei fatti resta fermo;

    e) l’ingresso in un Cerchio 0 a fini di difesa o di soccorso urgente previsto dall’articolo 8-sexies, comma 9, del Codice 14 è comunicato in ogni caso al Tribunale di Garanzia, che entro ventiquattro ore verifica se è avvenuto nei limiti di quel comma e dell’articolo 5.1, lettera a), della Costituzione e dispone, se necessario, la protezione delle persone che vi abitano. L’ingresso fuori da quei limiti è qualificato secondo l’articolo 26.

6.  La difesa invocata non impedisce le misure cautelari dell’articolo 34, i percorsi di protezione dell’articolo 7-bis del Codice 12 a tutela di ciascuna delle persone coinvolte, né l’accertamento dell’aggressione iniziale. Quando la forza è stata usata tra persone che appartengono allo stesso Cerchio 0 o vi convivono, il Cerchio di Garanzia:

    a) ascolta ciascuna persona separatamente e senza la presenza dell’altra;

    b) offre a ciascuna, se lo chiede, la separazione e un alloggio provvisorio ai sensi dell’articolo 34;

    c) informa il Consiglio Cura quando nel Cerchio 0 vivono minori o persone che non sono in grado di tutelarsi;

    d) quando la difesa è invocata più di una volta nello stesso Cerchio 0 nell’arco di ventiquattro mesi, propone in ogni caso un percorso di protezione e ne tiene conto nella trasmissione al Tribunale di Garanzia.

7.  Ai fatti commessi da persone che non hanno compiuto diciotto anni si applica l’articolo 25, comma 9. Per l’eccesso nella difesa sono ammesse soltanto misure riparative, educative e di sostegno, definite con il Consiglio Cura; non può essere disposta l’accoglienza educativa protetta. Il Consiglio Cura offre sostegno al minore che si è difeso o ha difeso altre persone.

8.  Anche quando l’uso della forza non costituisce illecito, la procedura riparativa dei Capi II, III e IV resta disponibile, su base volontaria, per tutte le persone coinvolte. Chi si è difeso nei limiti dell’articolo 8-sexies del Codice 14 non è tenuto alla riparazione.

9.  Durante la transizione si applica l’articolo 37. La valutazione prevista dal presente articolo ha effetto soltanto nell’ordinamento interno e non sostituisce quella delle autorità dello Stato. Chi ha usato la forza è informato del diritto all’assistenza legale prevista dalla legge vigente.

### Art. 27 — Organi competenti

1.  Per gli illeciti di Grado 1 e 2 è competente l’Assemblea di Chiarimento del Cerchio 1. Essa opera come sezione dell’Assemblea composta da sette persone sorteggiate per ciascun caso tra i membri estranei ai fatti ed è assistita, senza diritto di voto, da un facilitatore del Cerchio di Garanzia.
2.  Per gli illeciti di Grado 3 è competente il Consiglio di Trasformazione, composto da cinque persone sorteggiate per ciascun caso: tre tra i membri del Cerchio 1 estranei ai fatti e due tra i membri di altre Comunità del medesimo Cerchio 2.
3.  Per gli illeciti di Grado 4, 5 e 6, per la revisione urgente entro ventiquattro ore e per le altre funzioni di garanzia attribuite dai Codici è competente il Tribunale di Garanzia del Cerchio 2, composto da sette persone sorteggiate per ciascun caso dall’elenco dell’articolo 36. I componenti appartengono a Comunità diverse da quelle della persona cui è attribuito il fatto o che è interessata dalla decisione e della persona offesa; almeno tre possiedono una formazione giuridica validata secondo il Codice 5.
4.  Gli organi sono costituiti per il singolo caso e si sciolgono con la decisione. Nessuno può far parte di più di tre collegi nell’arco di dodici mesi. Si applicano le regole di astensione dell’articolo 15. Negli organi dei commi 1, 2 e 3 sono sorteggiate soltanto persone che hanno compiuto diciotto anni; le persone dai sedici anni possono partecipare in affiancamento, senza voto.
5.  Le decisioni sono assunte per consenso. In mancanza, è richiesta la maggioranza dei due terzi dei componenti. Per le misure degli articoli 30, comma 3, e 31 sono necessari sei voti su sette.
6.  Il Cerchio di Garanzia riceve le segnalazioni, facilita la procedura riparativa, cura l’istruttoria preliminare e custodisce i fascicoli. Non accerta la responsabilità e non dispone misure, salvo quanto previsto dagli articoli 9 e 34 del presente Codice e dall’articolo 7-bis, comma 3, lettera b), del Codice 12. Adotta inoltre gli altri atti che i Codici gli attribuiscono espressamente, come la nomina del rappresentante temporaneo dell’articolo 7-bis, comma 5, del Codice 12, il parere e l’autorizzazione dell’articolo 10, commi 6 e 7, del Codice 6 e il riesame dell’articolo 2-bis, comma 4, lettera d), del Codice 6.

### Art. 28 — Procedura

1.  Ricevuta la segnalazione ai sensi dell’articolo 5, il Cerchio di Garanzia qualifica in via provvisoria il grado e:

    a) per i Gradi 1 e 2 avvia la procedura riparativa; se non è accettata o non produce un accordo nei termini dell’articolo 6, trasmette il caso all’Assemblea di Chiarimento;

    b) per il Grado 3 trasmette il caso al Consiglio di Trasformazione, dopo aver proposto la procedura riparativa;

    c) per i Gradi 4, 5 e 6 trasmette senza ritardo il caso al Tribunale di Garanzia e attiva la protezione della persona offesa.

2.  L’istruttoria comprende l’ascolto separato delle persone coinvolte e la raccolta degli elementi utili, nel rispetto dell’articolo 18 della Costituzione. Gli accertamenti sanitari richiedono il consenso della persona, secondo il Codice 6.

3.  L’udienza non è pubblica quando lo chiedono la persona offesa o le esigenze di tutela di un minore. La decisione è pubblicata in forma anonimizzata, secondo l’articolo 14.

4.  La decisione è adottata, di norma, entro trenta giorni per i Gradi 1 e 2, entro sessanta giorni per il Grado 3 ed entro centoventi giorni per i Gradi 4, 5 e 6. La proroga è motivata e comunicata alle parti.

5.  La decisione accerta i fatti, il grado e la responsabilità e indica le misure, la loro durata, le modalità di verifica e i termini di riesame.

### Art. 29 — Misure per i Gradi da 1 a 4

1.  Per i Gradi 1 e 2 sono ammesse esclusivamente le misure dell’articolo 11, salvo la sospensione prevista dal comma 4-bis per il rifiuto del CBO. Non sono ammesse altre limitazioni dei diritti.

2.  Per il Grado 3 il Consiglio di Trasformazione definisce con la persona un Piano di Trasformazione di durata non superiore a dodici mesi, rinnovabile una sola volta. Il Piano può comprendere la rimodulazione delle mansioni, l’affiancamento, la riparazione del danno e, solo se necessario, la sospensione del CdR e dell’accesso ai beni non essenziali e l’esclusione temporanea dai sorteggi per gli incarichi.

3.  Costituiscono giustificazione del rifiuto del CBO, ai sensi dell’articolo 7.3 della Costituzione:

    a) l’obiezione di coscienza rispetto a una mansione, con assegnazione di un’attività equivalente;

    b) le esenzioni, riduzioni e sospensioni dell’articolo 11 del Codice 1 e gli impedimenti riconosciuti secondo i Codici 6 e 12;

    c) l’assenza delle condizioni di sicurezza, dei DPI o della formazione richiesti dai Codici 1 e 14;

    d) la pendenza di un ricorso con effetto sospensivo;

    e) per la persona cresciuta nella Confederazione, il periodo che precede la scelta prevista dall’articolo 26.4 della Costituzione o la scadenza del relativo termine, ai sensi dell’articolo 6, comma 6, del Codice 5.

4.  Prima di ogni misura per il rifiuto del CBO la persona è informata del diritto al Patto di Convivenza Autonoma, ai sensi dell’articolo 4.9 della Costituzione.

4-bis. In attuazione dell’articolo 7.3 della Costituzione, il rifiuto del CBO che non costituisce ancora illecito di Grado 3 è trattato come segue:

a) chiunque ne abbia conoscenza, compreso il Consiglio di Magazzino, lo segnala al Cerchio di Garanzia ai sensi dell’articolo 5. Il Cerchio di Garanzia verifica se ricorre una giustificazione del comma 3 e, se non ricorre, trasmette il caso all’Assemblea di Chiarimento, costituita ai sensi dell’articolo 27, comma 1;

b) l’Assemblea di Chiarimento ascolta la persona, valuta con il Consiglio di Magazzino la rimodulazione delle mansioni, propone una mediazione facilitata dal Cerchio di Garanzia e informa la persona per iscritto ai sensi del comma 4. I sessanta giorni dell’articolo 7.3 della Costituzione decorrono dal giorno di questa informazione; non si computano i periodi in cui ricorre una giustificazione del comma 3;

c) se, decorsi almeno quattordici giorni dall’informazione della lettera b), la rimodulazione e la mediazione non hanno avuto esito, l’Assemblea di Chiarimento può disporre, con decisione motivata, la sospensione del CdR e dell’accesso alle risorse non essenziali. Restano integri il Paniere, l’alloggio, le cure, l’apprendimento, il voto e gli altri diritti dell’articolo 1.2 della Costituzione;

d) la sospensione cessa di diritto quando la persona riprende il CBO, verificato dal Consiglio di Magazzino, o quando sopravviene una giustificazione del comma 3. L’Assemblea di Chiarimento la revoca, su richiesta della persona, quando ne vengono meno i presupposti;

e) decorsi i sessanta giorni, se il rifiuto persiste il Cerchio di Garanzia trasmette il caso al Consiglio di Trasformazione ai sensi dell’articolo 28, comma 1, lettera b); altrimenti la sospensione cessa. La sospensione già disposta prosegue fino alla decisione del Consiglio di Trasformazione e comunque non oltre sessanta giorni dalla trasmissione; dopo la decisione prosegue soltanto se il Piano del comma 2 la prevede;

f) contro la sospensione è ammesso ricorso al Collegio di Riesame ai sensi dell’articolo 35, comma 1. Il ricorso non sospende la misura, salvo diversa decisione del Collegio, e non interrompe il termine della lettera b).

In deroga all’articolo 27, comma 4, l’Assemblea di Chiarimento resta costituita per il caso fino alla cessazione della sospensione o alla trasmissione della lettera e). La sospensione non accerta un illecito e non è iscritta come misura per illecito.

5.  Per il Grado 4 il Tribunale di Garanzia può disporre, oltre alle misure riparative:

    a) l’esclusione dai sorteggi per gli incarichi e per i Consigli, per non più di trentasei mesi;

    b) un percorso di trasformazione con verifiche periodiche;

    c) il divieto di avvicinarsi a persone o luoghi determinati, o l’allontanamento protettivo temporaneo per non più di dodici mesi, con assegnazione di un altro alloggio adeguato;

    d) la consegna o la disattivazione degli strumenti impiegati per commettere il fatto.

6.  Nessuna misura del presente articolo comporta contenimento o perdita dello status di membro. Fa eccezione soltanto la cessazione dello status per rifiuto persistente del CBO prevista dal comma 6-bis, in attuazione dell’articolo 7.3-bis della Costituzione.

6-bis. In attuazione dell’articolo 7.3-bis della Costituzione, il rifiuto del CBO che persiste dopo il Grado 3 è trattato come segue:

a) concluso il Piano di Trasformazione del comma 2, compreso il rinnovo se disposto, il Consiglio di Trasformazione accerta se il rifiuto persiste senza giustificazione. Non costituiscono rifiuto le giustificazioni del comma 3, le esenzioni, riduzioni e sospensioni dell’articolo 11 del Codice 1, l’obiezione di coscienza e gli impedimenti per malattia, disabilità, età o gravidanza riconosciuti secondo i Codici 6 e 12. In caso di dubbio il rifiuto non è accertato;

b) se il rifiuto persiste, il Cerchio di Garanzia informa la persona per iscritto delle conseguenze previste dal presente comma, del diritto al Patto di Convivenza Autonoma ai sensi del comma 4 e della possibilità di riprendere il CBO. Decorsi trenta giorni senza ripresa, trasmette il caso al Tribunale di Garanzia;

c) il Tribunale di Garanzia ascolta la persona con le garanzie dell’articolo 25, comma 4, verifica i presupposti delle lettere a) e b) e può dichiarare, con sei voti su sette, la cessazione dello status di membro. Contro la decisione è ammesso il riesame dell’articolo 35, comma 2. La decisione produce effetti quando è definitiva e la porzione della lettera e) è consegnata; fino ad allora la persona resta membro. La procedura si estingue se la persona riprende il CBO prima che la decisione produca effetti;

d) la cessazione produce gli effetti dell’articolo 4.8 della Costituzione: la persona perde l’accesso al Paniere e ai Magazzini Comuni, l’alloggio comune, il CdR, i servizi confederati, il voto e gli incarichi. Conserva i Beni d’Uso Personale, l’acqua potabile, le cure d’emergenza salvavita, l’energia essenziale dell’articolo 15.2 della Costituzione e gli altri diritti dell’articolo 4.9 della Costituzione;

e) con la stessa decisione il Tribunale assegna alla persona in custodia d’uso una porzione della quota riservata al Patto, ai sensi dell’articolo 4-bis, comma 10, del Codice 10, con l’accesso all’acqua necessaria, senza abitazione e senza attrezzi o altri beni della Comunità. La persona può costruirvi un riparo con le proprie forze, nel rispetto delle condizioni ecologiche della porzione. Il trasferimento si svolge senza uso della forza sulla persona, con le modalità dell’articolo 32-bis, comma 2, lettera e);

f) la persona può chiedere in ogni momento la riammissione ai sensi dell’articolo 4.8 della Costituzione, riprendendo il CBO o, se nel frattempo ricorre un’esenzione, una riduzione, una sospensione o un impedimento del comma 3, senza altra condizione. La riammissione non può essere negata per il rifiuto passato e ha effetto dalla richiesta; la porzione torna alla quota. Un nuovo rifiuto è trattato da capo secondo il comma 4-bis;

g) i figli minori conservano lo status di membro e tutti i diritti. Il Tribunale decide nel loro interesse, con la stessa decisione o con una decisione separata, dove e con chi vivono, ai sensi dell’articolo 7-bis, comma 3-bis, del Codice 12. Se vivono con la persona, l’alloggio, il Paniere e i servizi che spettano loro sono assicurati nel luogo in cui vivono. La cessazione non toglie, da sola, la responsabilità di cura né il consenso alle cure previsto dall’articolo 2-ter del Codice 6, e non costituisce grave negligenza o pregiudizio ai sensi dell’articolo 7-bis del Codice 12;

h) il rifiuto che persiste dopo la cessazione non costituisce un nuovo illecito.

Durante la transizione la cessazione consiste nell’esclusione dal Cerchio pilota ai sensi dell’articolo 37, comma 4, e la porzione è assegnata soltanto nelle forme consentite dalla legge vigente, ai sensi dell’articolo 4-bis, comma 9, del Codice 10.

### Art. 30 — Gradi 5 e 6: regola delle due possibilità

1.  La prima decisione definitiva che accerta un fatto di Grado 5 o 6 dà sempre luogo a un percorso di protezione e di trasformazione. Le misure estreme dell’articolo 31 sono riservate alla recidiva.

2.  Il percorso comprende, secondo necessità:

    a) la protezione della persona offesa e, se lo desidera, il suo accompagnamento;

    b) l’allontanamento protettivo dalla Comunità in cui vive la persona offesa, con collocazione in un’altra Comunità informata dei fatti e disponibile ad accogliere la persona;

    c) il divieto territoriale, che può essere assistito dal dispositivo di localizzazione alle condizioni dell’articolo 33;

    d) un percorso di trasformazione intensivo, con verifiche almeno semestrali;

    e) la riparazione del danno, nelle forme accettate dalla persona offesa;

    f) l’esclusione dai sorteggi per gli incarichi e per i Consigli per la durata del percorso.

3.  Quando sussiste un pericolo concreto e attuale per l’incolumità altrui, che non può essere contenuto con le misure del comma 2, il Tribunale di Garanzia può disporre il contenimento protettivo in una Comunità di accompagnamento. La Comunità di accompagnamento è una Comunità aperta, informata dei fatti e disponibile ad accogliere la persona, distinta dalla Comunità di Contenimento dell’articolo 32: non ha perimetro protetto né sorveglianza del Corpo di Tutela Civica. La decisione stabilisce l’obbligo di permanenza nella Comunità e un affiancamento quotidiano, con un percorso di trasformazione; il Cerchio di Garanzia della Comunità di accompagnamento ne verifica il rispetto e riferisce al Tribunale almeno ogni tre mesi. La persona non è trattenuta con la forza; il suo allontanamento è comunicato senza ritardo al Tribunale di Garanzia, che può rivedere le misure nei limiti del presente articolo e dell’articolo 34. Il contenimento protettivo dura finché persiste il pericolo ed è riesaminato almeno ogni sei mesi. La sua durata complessiva non può superare cinque anni per il Grado 5 e dieci anni per il Grado 6.

4.  Durante il contenimento protettivo la persona conserva lo status di membro e le garanzie dell’articolo 32, comma 2.

5.  Il percorso si conclude con una decisione del Tribunale di Garanzia che ne accerta l’esito e, se positivo, dispone la piena reintegrazione.

### Art. 31 — Recidiva e misure estreme

1.  Le misure estreme dell’articolo 1.3-bis della Costituzione possono essere disposte soltanto quando ricorrono congiuntamente tutte le condizioni seguenti:

    a) una precedente decisione definitiva ha accertato a carico della persona un fatto di Grado 5 o 6;

    b) un nuovo fatto di Grado 5 o 6 è accertato con decisione definitiva;

    c) sussiste un pericolo concreto e attuale per l’incolumità altrui;

    d) nessuna misura meno restrittiva è idonea a proteggere le persone.

2.  La decisione dichiara la decadenza dallo status di membro e dispone, in alternativa, il Contenimento ad Alta Sicurezza o l’Allontanamento Definitivo dai Cerchi interessati. L’Allontanamento Definitivo è preferito quando è sufficiente a proteggere le persone.

3.  La decisione che dispone una misura estrema è sempre sottoposta al riesame dell’articolo 35, anche in assenza di ricorso, e diventa definitiva solo dopo la conferma.

4.  I casi e le misure del presente articolo non possono essere estesi.

### Art. 32 — Regime del Contenimento e dell’Allontanamento

1.  Il Contenimento ad Alta Sicurezza si svolge in una Comunità di Contenimento con perimetro protetto, sotto la sorveglianza del Corpo di Tutela Civica, secondo l’articolo 30.3 della Costituzione e il Codice 14.
2.  La persona conserva il diritto a un alloggio individuale, al cibo, all’acqua, all’energia minima e alle cure sanitarie. Ha inoltre diritto ai contatti con le persone care, all’apprendimento, ad attività significative, al percorso di trasformazione e all’assistenza dei facilitatori di fiducia.
3.  Sono vietati l’isolamento, la contenzione e la sedazione usati come sanzione, il lavoro imposto e ogni trattamento inumano o degradante.
4.  Il Contenimento non ha durata predeterminata e non è perpetuo. Il Tribunale di Garanzia, in composizione diversa da quella che ha deciso, riesamina la pericolosità almeno ogni dodici mesi e, su richiesta della persona, ogni sei mesi. Quando viene meno il pericolo concreto e attuale, la misura cessa ed è avviato un percorso di reintegrazione, con riammissione allo status di membro.
5.  Un Cerchio di Garanzia appartenente a un diverso Cerchio 2 visita la Comunità di Contenimento almeno ogni tre mesi, anche senza preavviso, e pubblica una relazione in forma anonimizzata.
6.  L’Allontanamento Definitivo comporta il divieto permanente di risiedere e di accedere ai Cerchi in cui vivono la persona offesa e la comunità colpita. La persona è ricollocata in un altro Cerchio la cui Assemblea, informata dei fatti, sia disponibile ad accoglierla, oppure mediante Patto di Convivenza Autonoma ai sensi dell’articolo 4.9-bis della Costituzione. Restano ferme le garanzie del comma 2.
7.  Il divieto territoriale può essere assistito dal dispositivo dell’articolo 33.

### Art. 32-bis — Persone che vivono mediante Patto e allontanamento dall’abitato comune

1.  Alla persona che vive mediante Patto di Convivenza Autonoma il presente Capo si applica con i seguenti adattamenti:

    a) non si applicano le misure che presuppongono lo status di membro, compresi la decadenza dell’articolo 31, comma 2, la sospensione del CdR e l’esclusione dai sorteggi;

    b) in loro luogo l’organo competente può disporre la revisione del Patto: la modifica delle sue condizioni o, quando la protezione delle persone lo richiede, la collocazione della porzione presso un altro Cerchio 1 secondo l’articolo 4-bis, comma 6, del Codice 10, informato dei fatti;

    c) l’allontanamento protettivo degli articoli 29, comma 5, lettera c), e 30, comma 2, lettera b), e, soltanto quando ricorrono tutte le condizioni dell’articolo 31, comma 1, l’Allontanamento Definitivo si eseguono con la revisione della lettera b);

    d) la violazione delle condizioni del Patto è qualificata secondo l’articolo 26 e non comporta la cessazione del Patto.

1-bis. Alla persona accolta senza aderire in una Comunità associata, ai sensi dell’articolo 21-bis, comma 9, del Codice 15, si applica il comma 1, lettera a). In luogo della revisione del Patto, l’organo competente può disporre l’allontanamento protettivo dalla Comunità, con l’offerta del Patto di Convivenza Autonoma presso un altro Cerchio 1.

2.  L’allontanamento previsto dall’articolo 4.9-ter della Costituzione si svolge come segue:

    a) il Cerchio di Garanzia, su segnalazione ai sensi dell’articolo 5, accerta che la persona risiede stabilmente nell’abitato comune senza essere membro, senza Patto e senza contribuzione, oltre il termine dell’ospitalità dell’articolo 4.9, lettera b), della Costituzione e fuori dai casi dell’articolo 4-bis, comma 7, del Codice 10, dell’articolo 21-bis, comma 9, del Codice 15 e dell’articolo 26.5 della Costituzione;

    b) il Cerchio 1 offre per iscritto il Patto, con l’indicazione della porzione individuata ai sensi dell’articolo 4-bis del Codice 10, e informa la persona del diritto di entrare o rientrare nella Confederazione; il Cerchio di Garanzia propone una mediazione;

    c) il rifiuto è persistente quando la persona ha rifiutato o lasciato senza risposta due offerte, la seconda presentata dopo la mediazione e almeno trenta giorni dopo la prima;

    d) il Cerchio di Garanzia trasmette allora il caso al Tribunale di Garanzia, che ascolta la persona con le garanzie dell’articolo 25, comma 4, verifica che la porzione sia sufficiente all’autosufficienza ai sensi dell’articolo 4.9-bis della Costituzione e può disporre l’allontanamento dall’abitato comune con l’assegnazione d’ufficio della porzione;

    e) l’allontanamento è eseguito senza uso della forza sulla persona e consiste nella cessazione dell’accesso ordinario all’abitato comune e nella messa a disposizione della porzione e dei mezzi per trasferire i beni d’uso personale, secondo il Codice 11;

    f) restano garantiti l’acqua potabile, le cure d’emergenza salvavita e la protezione dei minori, ai sensi dell’articolo 1.3 della Costituzione, e i diritti dei minori del nucleo previsti dall’articolo 4.9-bis della Costituzione;

    g) la persona può in ogni momento accettare il Patto o entrare nella Confederazione, e la procedura si estingue. Contro la decisione è ammesso il riesame dell’articolo 35, comma 2.

3.  Durante la transizione si applica l’articolo 37, comma 3: l’allontanamento del comma 2 non è eseguito.

### Art. 33 — Dispositivo di localizzazione

1.  Il dispositivo di localizzazione previsto dall’articolo 18.7 della Costituzione può essere disposto soltanto con decisione definitiva del Tribunale di Garanzia per un fatto di Grado 5 o 6, a tutela diretta della persona offesa o della Comunità.
2.  Il dispositivo non è biometrico e non registra audio né video. Rileva esclusivamente la violazione del perimetro di protezione o del divieto territoriale stabilito dalla decisione.
3.  La misura dura non più di dodici mesi ed è rinnovabile solo con una nuova decisione motivata.
4.  I dati sono cifrati con chiave frammentata e sono accessibili soltanto in caso di violazione del perimetro o del divieto. Gli accessi sono registrati e ispezionabili. I dati non pertinenti sono distrutti automaticamente entro settantadue ore. Sono vietati gli usi predittivi e la profilazione.
5.  Il dispositivo è disposto soltanto come alternativa meno restrittiva al contenimento protettivo o al Contenimento ad Alta Sicurezza, con il consenso della persona, e non può aggiungersi ad essi. Se la persona non acconsente, il Tribunale valuta le altre misure degli articoli 30 e 31.

### Art. 34 — Misure cautelari e revisione urgente

1.  In presenza di un pericolo immediato per l’incolumità di una persona, il Cerchio di Garanzia o il Corpo di Tutela Civica possono disporre la separazione immediata delle persone e l’allontanamento provvisorio da un luogo, secondo il Codice 14.
2.  Ogni misura che limita la libertà di movimento è comunicata senza ritardo al Tribunale di Garanzia, che la convalida, la modifica o la revoca entro ventiquattro ore. In mancanza di convalida la misura cessa.

2-bis. Con la stessa procedura il Tribunale convalida entro ventiquattro ore l’ingresso del Corpo di Tutela Civica in un Cerchio 0 previsto dall’articolo 8-ter, comma 3, del Codice 14: verifica che sia avvenuto nei limiti di quel comma e dell’articolo 5.1, lettera a), della Costituzione e dispone, se necessario, la protezione delle persone e dell’animale.

3.  La misura cautelare dura non più di trenta giorni. È rinnovabile con decisione motivata fino alla decisione sul fatto e non costituisce accertamento anticipato di responsabilità.
4.  Alla persona sottoposta a misura cautelare sono garantiti un alloggio adeguato, il Paniere e l’assistenza dell’articolo 25, comma 4.

### Art. 35 — Riesame e definitività

1.  Contro le decisioni dell’Assemblea di Chiarimento e del Consiglio di Trasformazione è ammesso ricorso al Collegio di Riesame dell’articolo 17, entro quattordici giorni dalla comunicazione. In questi ricorsi il componente dell’articolo 17, comma 3, lettera b), è sostituito da una persona con formazione giuridica validata secondo il Codice 5, sorteggiata dall’elenco dell’articolo 36, comma 1, lettera a).
2.  Contro le decisioni del Tribunale di Garanzia è ammesso, entro trenta giorni, il riesame davanti a un secondo Tribunale di Garanzia, sorteggiato in un diverso Cerchio 2. Finché esiste un solo Cerchio 2, il secondo Tribunale è sorteggiato tra persone diverse e appartenenti ad altre Comunità.
3.  Se il riesame è chiesto soltanto dalla persona destinataria della misura, questa non può essere aggravata.
4.  La decisione è definitiva quando non è stato chiesto il riesame nei termini o quando è stata confermata, salvo quanto previsto dal comma 6.
5.  La decisione definitiva è riveduta in ogni tempo quando emergono elementi nuovi che dimostrano l’errore dell’accertamento.
6.  Le decisioni del Tribunale di Garanzia che accertano un fatto di Grado 5 o 6 sono sempre sottoposte al riesame del comma 2, anche in assenza di richiesta, e diventano definitive solo dopo la conferma, ai sensi dell’articolo 31.6 della Costituzione. Fino alla conferma si applicano soltanto le misure cautelari dell’articolo 34.

### Art. 35-bis — Archivio delle decisioni

1.  Le decisioni definitive degli organi previsti dal presente Capo e quelle del Collegio di Riesame sono pubblicate nell’Archivio federato delle decisioni, con i fatti accertati, il grado, le misure e la motivazione.
2.  La pubblicazione avviene in forma anonimizzata, a tutela della persona offesa, della persona destinataria della misura e dei minori. Quando nel contesto locale l’identificazione sarebbe comunque possibile, è pubblicato soltanto il principio applicato.
3.  Le decisioni non costituiscono precedente vincolante. L’organo che decide un caso analogo consulta l’Archivio e, se si discosta dall’orientamento prevalente, ne indica espressamente le ragioni.
4.  Ogni anno uno dei Cerchi di Garanzia delle Comunità del Cerchio 2, designato a rotazione in coordinamento con gli altri ai sensi dell’articolo 36, comma 1, pubblica una sintesi degli orientamenti e delle divergenze rilevate. La sintesi non ha valore normativo; può fondare una proposta di modifica dei Codici.

### Art. 36 — Elenchi federati e sorteggio

1.  Il Cerchio di Garanzia custodisce, in coordinamento con gli altri Cerchi di Garanzia del Cerchio 2:

    a) l’elenco delle persone formate e disponibili per gli organi del presente Capo;

    b) l’elenco federato delle persone con competenza L3 disponibili per gli audit, i collegi e i pareri indipendenti previsti dai Codici.

2.  Il sorteggio è pubblico e tracciato secondo l’articolo 15 del Codice 3.

3.  Non può essere sorteggiato dagli elenchi del comma 1 chi appartiene al Cerchio 1 interessato, cioè a quello della persona cui è attribuito il fatto o che è interessata dalla decisione, della persona offesa o dell’attività sottoposta ad audit o a parere, o vi ha svolto attività negli ultimi ventiquattro mesi, né chi ha un interesse nell’esito. Il presente comma non si applica ai componenti che i Codici fanno sorteggiare tra i membri del Cerchio 1 interessato, come quelli dell’articolo 27, commi 1 e 2.

4.  Salvo diversa disposizione dei Codici, l’incarico di audit o di parere non supera trenta giorni. Il tempo dedicato è computato nel CBO.

### Art. 37 — Regime transitorio e rapporto con l’ordinamento vigente

1.  Fino al completamento della transizione disciplinata dal Codice 16, e in ogni territorio in cui si applica la giurisdizione di uno Stato, il presente Capo vale come ordinamento interno e volontario tra i membri, le persone che vivono mediante Patto di Convivenza Autonoma, che lo accettano con il Patto, e le persone accolte ai sensi dell’articolo 21-bis, comma 9, del Codice 15, che lo accettano con l’accoglienza.
2.  I fatti che costituiscono reato secondo l’ordinamento vigente restano soggetti alla giurisdizione dello Stato. Nessuno può essere dissuaso dal rivolgersi alle autorità; chi è in pericolo è aiutato a farlo. Sono rispettati gli obblighi di segnalazione e di denuncia previsti dalla legge.
3.  Durante la transizione non possono essere eseguite misure di contenimento, di allontanamento coattivo o di localizzazione. L’articolo 25, comma 9, per l’accoglienza educativa protetta, e gli articoli 30, comma 3, 31, 32, 33 e 34 si applicano soltanto per le misure di protezione non coercitive e per gli effetti sull’appartenenza al Cerchio.
4.  Durante la transizione la decadenza dallo status di membro consiste nell’esclusione dal Cerchio pilota, disposta secondo lo statuto dell’ente e la legge applicabile.
5.  Finché non è costituito un Bacino, o nel Bacino non si possono sorteggiare i componenti richiesti, le funzioni che i Codici attribuiscono al Tribunale di Garanzia, compreso il secondo Tribunale dell’articolo 35, comma 2, per il quale, costituito il Bacino, prevale il secondo periodo di quel comma, al Collegio di Riesame e al Consiglio di Trasformazione, e la sostituzione del Cerchio di Garanzia prevista dall’articolo 15, comma 3, sono esercitate da un collegio dello stesso numero di componenti, sorteggiato dall’elenco pubblico delle persone formate di altri Cerchi pilota o di enti affini che hanno accettato il presente Capo, tenuto ai sensi dell’articolo 36. Se l’elenco non consente il sorteggio nel termine, il collegio è sorteggiato, in deroga agli articoli 17, comma 3, 27, commi 2 e 3, e 36, comma 3, tra i membri del Cerchio pilota estranei ai fatti, alle persone coinvolte e a ogni grado precedente, sul modello dell’articolo 35, comma 2. Il collegio che svolge un riesame è composto da persone diverse da quelle che hanno deciso. Il collegio formato soltanto da membri non può disporre l’accoglienza educativa protetta dell’articolo 25, comma 9, né le misure degli articoli 30, comma 3, 31 e 33. Se nessun collegio può essere costituito entro il termine di una convalida, la misura cessa.
6.  Dopo la chiusura della transizione, in ogni territorio in cui si applica la giurisdizione di uno Stato continuano ad applicarsi i commi 2, 3 e 4 e le disposizioni dei Codici che, per il periodo della transizione, rinviano al presente articolo o limitano gli interventi sulle persone a quanto consentito dalla legge vigente, tra cui gli articoli 1, comma 4, 26-bis, comma 9, 29, comma 6-bis, ultimo periodo, e 32-bis, comma 3, del presente Codice, gli articoli 2-bis, comma 3-quater, lettera f), 2-ter, comma 6, e 8, comma 10, del Codice 6, l’articolo 4-bis, comma 9, del Codice 10, gli articoli 7-bis, commi 2 e 3-ter, e 7-ter, comma 9, del Codice 12 e gli articoli 8-quinquies, comma 6, e 8-sexies, comma 13, del Codice 14. In questi casi i riferimenti al Cerchio pilota si intendono riferiti al Cerchio 1.
