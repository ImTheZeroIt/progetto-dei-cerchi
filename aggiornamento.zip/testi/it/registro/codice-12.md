---
titolo: "CODICE 12 — CURA DI COMUNITÀ, FRAGILITÀ FUNZIONALI E SALUTE DI COMUNITÀ"
breve: "Codice 12 — Cura di comunità"
versione: "V1.7"
gruppo: "codici"
ordine: 12
id: "codice-12"
slug: "codice-12"
allineamento: "Costituzione V.39; Codice 1 V1.12; Codice 2 V1.9; Codice 3 V1.13; Codice 4 V1.10; Codice 5 V1.7; Codice 6 V1.9; Codice 7 V1.10; Codice 8 V1.7; C.1-Annex A V1.7; Codice 9 V3.4; Codice 10 V1.8; Codice 11 V1.6; Codice 13 V1.9; Codice 14 V1.10; Codice 15 V1.13; Codice 16 V1.11."
---

## Art. 1 — Oggetto, definizioni e ambito di competenza

1.  Il presente Codice disciplina l’organizzazione della cura di comunità, la presa in carico delle fragilità funzionali, la gestione degli spazi e degli strumenti di cura e la programmazione del tempo necessario a garantire le prestazioni essenziali. Tali risorse costituiscono beni comuni infrastrutturali funzionali all’attuazione del Paniere di Sufficienza, alla tutela della salute e all’accesso all’abitare.

2.  Ai fini del presente Codice si intende per:

    a) **cura di comunità**: l’insieme delle attività di supporto alla vita quotidiana, relazionale e domestica, di accompagnamento, di sostegno educativo e di assistenza pratica che non costituiscono prestazioni cliniche;

    b) **fragilità funzionale**: una condizione temporanea o permanente che limita l’autonomia della persona nello svolgimento di una o più funzioni essenziali ricomprese nei livelli 1 e 2 del Paniere, indipendentemente dalla presenza, dall’assenza o dalla qualificazione di una diagnosi clinica;

    c) **Paniere Cura**: la componente del Paniere di Sufficienza disciplinato dal Codice 1 che comprende il tempo minimo di cura, l’accesso agli spazi di cura e, quando necessario, il supporto nei pasti, nell’igiene, nell’accompagnamento e nel riposo protetto;

    d) **spazi di cura**: gli spazi e le strutture destinati, secondo necessità e pianificazione territoriale, alla cucina di supporto alle persone fragili, alla lavanderia comune, all’infanzia da zero a tre anni, al riposo protetto, all’assistenza di prossimità non clinica e all’accoglienza temporanea di comunità;

    e) **piano individuale di cura**: il documento riservato che, sulla base del bisogno funzionale accertato e nel rispetto della volontà della persona, individua le prestazioni necessarie, i soggetti responsabili, la durata prevista e le date o condizioni di riesame;

    f) **Scheda Sicurezza di cura**: il documento operativo che individua i rischi connessi a una specifica attività di cura e stabilisce le misure preventive, le competenze richieste, le procedure di interruzione e le modalità di sostituzione in caso di indisponibilità di una risorsa essenziale;

    g) **STV Cura**: la Scheda Tecnica di Validazione, adottata secondo l’articolo 3-bis del Codice 2, che definisce standard, quantità minime, procedure e modalità operative dei servizi disciplinati dal presente Codice.

3.  Sono beni comuni infrastrutturali inalienabili:

    a) il tempo minimo di cura necessario a garantire i livelli 1 e 2 del Paniere;

    b) gli spazi di cura essenziali del Cerchio 1 e le relative dotazioni comuni;

    c) l’inventario degli ausili di base e dei presidi non clinici destinati alla cura di comunità;

    d) le conoscenze essenziali di cura e le relative STV e Schede Sicurezza;

    e) il bilancio aggregato del tempo di cura.

    La gestione di tali beni non può comportare appropriazione esclusiva, rendita o esclusione ingiustificata delle persone aventi diritto.

4.  Il Codice 12 disciplina in via esclusiva, nell’ambito della propria materia, l’organizzazione della cura di comunità, l’accertamento della fragilità funzionale, il Paniere Cura, il tempo di cura e la funzione interna degli spazi di cura. Restano attribuite:

    a) al Codice 6 la diagnosi, le prestazioni cliniche, la nutrizione clinica e gli altri atti sanitari;

    b) al Codice 9 la produzione e la preparazione degli alimenti e la gestione tecnico-organizzativa delle mense collettive;

    c) al Codice C.1-Annex A la fabbricazione e la standardizzazione degli ausili;

    d) al Codice 10 la destinazione d’uso e la localizzazione territoriale degli spazi;

    e) ai Codici 1, 4 e 14, ciascuno per la propria materia, le disposizioni generali sul Paniere, sulle garanzie e sulla sicurezza.

5.  Il presente Codice persegue i seguenti obiettivi:

    a) garantire la continuità dei livelli 1 e 2 del Paniere anche in presenza di fragilità funzionale;

    b) impedire la formazione di rendite sulle prestazioni essenziali di cura;

    c) assicurare una distribuzione equa, verificabile e sostenibile del tempo di cura;

    d) prevenire l’isolamento e il ricorso ingiustificato a forme di istituzionalizzazione;

    e) promuovere, quando appropriato e desiderato dalla persona, il recupero o il mantenimento dell’autonomia.

## Art. 2 — Principi della cura di comunità

1.  **Universalità.** Ogni persona ha diritto alle prestazioni essenziali del Paniere Cura corrispondenti ai livelli 1 e 2, senza subordinazione alla contribuzione individuale al CBO e secondo le garanzie previste dal Codice 1.
2.  **Autonomia della fragilità funzionale.** La fragilità funzionale costituisce una condizione rilevante ai fini della cura di comunità, distinta dalla diagnosi clinica. Il suo accertamento non richiede, di per sé, una valutazione sanitaria. Gli atti clinici restano disciplinati dal Codice 6.
3.  **Prossimità e continuità.** La cura essenziale è organizzata, per quanto possibile, entro il Cerchio 1. Le prestazioni che richiedono competenze o strutture non disponibili localmente sono garantite mediante la rete federata di cui all’articolo 6.
4.  **Priorità e scarsità.** Le priorità generali del Paniere sono quelle stabilite dal Codice 1, articolo 32. In caso di insufficienza del tempo di cura, la riduzione riguarda in primo luogo le attività dell’ultimo livello della sequenza dell’articolo 4, comma 7, e procede verso i livelli superiori, nel rispetto della gerarchia del Codice 1 e senza pregiudicare le prestazioni essenziali dei livelli 1 e 2. All’interno delle priorità applicabili, le decisioni tengono conto dell’urgenza, della gravità del bisogno e del rischio di interruzione della cura.
5.  **Non accumulo e non monetizzabilità.** Il tempo essenziale di cura non è monetizzabile né accumulabile individualmente in misura tale da sottrarre disponibilità agli altri aventi diritto. L’eventuale limite tecnico di accumulo è definito mediante STV, sulla base della capacità effettiva del servizio e con criteri pubblici.
6.  **Trasparenza e riservatezza.** Gli inventari degli spazi e delle dotazioni, nonché i bilanci del tempo di cura, sono pubblicati in forma aggregata e non identificativa. I dati individuali necessari alla presa in carico sono trattati esclusivamente per tale finalità, secondo il Codice 7, articolo 2.2.
7.  **Reversibilità e riesame.** Quando la fragilità è temporanea, il piano individuale di cura prevede, se appropriato, un percorso di sostegno all’autonomia e un termine o una condizione di riesame. Il riesame non può determinare l’interruzione automatica delle prestazioni essenziali in assenza di una nuova valutazione.
8.  **Dignità, volontà e proporzionalità.** Le prestazioni sono organizzate nel rispetto della dignità, delle preferenze e della volontà della persona. Le limitazioni dell’autonomia sono ammesse soltanto nei casi e con le garanzie previste dall’ordinamento applicabile e dai Codici competenti.

## Art. 3 — Consiglio Cura

1.  Ogni Cerchio 1 istituisce un Consiglio Cura composto da tre a cinque membri, sorteggiati secondo l’articolo 12-bis del Codice 3. La composizione assicura competenze adeguate, almeno di livello L2 o L3, nell’ambito della cura di comunità, del sostegno all’infanzia da zero a tre anni, della grande età, della disabilità e dell’organizzazione dei servizi di prossimità.

2.  I componenti sono sorteggiati secondo l’articolo 12-bis del Codice 3, restano in carica un anno e non possono essere nuovamente sorteggiati nello stesso Consiglio prima di dodici mesi dalla fine del mandato. La sostituzione, la dichiarazione dei conflitti di interesse e la verbalizzazione delle decisioni seguono le procedure del Codice 3.

3.  Il Consiglio Cura:

    a) propone e attua il Paniere Cura e coordina gli spazi di cura;

    b) redige, aggiorna e applica le Schede Sicurezza relative alle attività di cura, all’igiene, all’infanzia e all’accompagnamento;

    c) propone e aggiorna le STV Cura secondo le procedure del Codice 2;

    d) programma il bilancio aggregato del tempo di cura e coordina i turni, nel rispetto della libertà individuale e delle competenze dei partecipanti;

    e) organizza la formazione di livello L1 per la cura di base e di livello L2 per le attività specialistiche previste dal Codice 5;

    f) alimenta il Registro Dipendenze disciplinato dal Codice 15;

    g) coordina le attività con i Consigli Salute, Agroecologico, Habitat, Produzione e Biodiversità, ciascuno entro la propria competenza.

4.  Gli atti del Consiglio Cura si distinguono in:

    a) **atti tecnici vincolati**, adottati in attuazione di una STV o di una Scheda Sicurezza vigente;

    b) **proposte e decisioni discrezionali**, adottate secondo il metodo del consenso e le procedure del Codice 3, previa pubblicazione per almeno settantadue ore, salvo i casi di urgenza motivata.

    La pubblicazione non comprende dati personali o informazioni che consentano di identificare le persone prese in carico.

5.  I pareri obbligatori dei Consigli competenti non trasferiscono la titolarità della decisione. La decisione è assunta congiuntamente soltanto quando un Codice lo prevede espressamente.

6.  In assenza di una Scheda Sicurezza vigente, l’attività interessata non può essere avviata o proseguita nelle modalità non valutate. Il Consiglio Cura individua, ove possibile, una modalità sostitutiva conforme che assicuri la continuità dei livelli 1 e 2. Ogni deroga temporanea è motivata, limitata allo stretto necessario e sottoposta a verifica.

## Art. 4 — Paniere Cura e accertamento della fragilità funzionale

1.  Il Paniere Cura dei livelli 1 e 2 comprende, secondo il bisogno accertato:

    a) il tempo minimo di cura;

    b) il supporto durante il pasto, quando la persona non sia autonoma nell’assunzione;

    c) l’igiene assistita;

    d) l’accompagnamento essenziale;

    e) il riposo protetto;

    f) l’accesso allo spazio per l’infanzia da zero a tre anni, quando necessario.

2.  Il Paniere Cura è quantificato principalmente in ore di assistenza per persona per settimana. La STV Paniere Cura definisce almeno le prestazioni comprese, gli standard minimi, le modalità di distribuzione giornaliera, i criteri di urgenza, i tempi di risposta e le procedure di riesame. Gli standard non possono essere ridotti in modo da compromettere i livelli 1 e 2 del Paniere.

3.  La segnalazione di un bisogno può essere presentata dalla persona interessata o da chiunque rilevi una necessità di cura. La segnalazione:

    a) dà avvio alla valutazione funzionale;

    b) consente, in presenza di un bisogno essenziale, l’attivazione provvisoria delle prestazioni necessarie per un periodo massimo di settantadue ore, in attesa della valutazione;

    c) non può essere utilizzata per avviare trattamenti clinici o per attribuire una diagnosi.

    In presenza di un rischio immediato per la vita, la salute o l’incolumità della persona, sono attivate senza ritardo le procedure di emergenza dei Codici competenti.

4.  Il Consiglio Cura valuta la condizione funzionale entro settantadue ore dalla segnalazione, sulla base di criteri pubblici contenuti nella STV. L’intervento del Consiglio Salute è richiesto soltanto quando siano necessarie competenze sanitarie o quando emergano profili di rischio clinico. La valutazione funzionale non costituisce diagnosi e non può sostituire un accertamento sanitario previsto dal Codice 6.

5.  Il piano individuale di cura indica almeno:

    a) il bisogno funzionale rilevato;

    b) le prestazioni e la frequenza necessarie;

    c) la data di avvio e la durata prevista;

    d) il referente responsabile del coordinamento;

    e) i tempi e i criteri di riesame;

    f) le modalità di continuità o sostituzione in caso di indisponibilità del servizio.

    La persona interessata partecipa alla definizione del piano con le modalità di comunicazione e di sostegno appropriate. Per una fragilità temporanea il riesame è svolto entro novanta giorni, salvo necessità di anticiparlo.

6.  La lista minima delle prestazioni del Paniere Cura è approvata dall’Assemblea su proposta del Consiglio Cura. È richiesto il parere obbligatorio del Consiglio Salute limitatamente ai profili sanitari. La lista, gli standard e le procedure sono pubblicati nella STV Paniere Cura.

7.  Le priorità operative si applicano nel rispetto del Codice 1, articolo 32, e secondo la seguente sequenza di livelli, da valutare in relazione all’urgenza e al bisogno individuale:

    a) livello 1: sopravvivenza, igiene essenziale e riposo protetto;

    b) livello 2: cura dell’infanzia da zero a tre anni e sostegno alle persone in grande età non autosufficienti;

    c) livello 3: convalescenza e periodo successivo al parto;

    d) livello 4: sostegno al mantenimento o al recupero dell’autonomia;

    e) livello 5: ulteriori prestazioni di cura.

## Art. 5 — Servizi, tempo di cura e coordinamento con gli altri Codici

1.  Ogni Cerchio 1 assicura l’accesso effettivo ai seguenti servizi di base, direttamente o mediante una rete condivisa:

    a) cucina di supporto alle persone fragili, funzionalmente coordinata con le mense del Codice 9;

    b) lavanderia comune;

    c) spazio per l’infanzia da zero a tre anni;

    d) spazio di riposo protetto;

    e) accompagnamento di prossimità.

    Le modalità di erogazione sono definite in modo da garantire accessibilità, continuità e sicurezza.

2.  Il Cerchio 1 è responsabile, in forma collettiva, della disponibilità del monte-ore necessario a garantire i livelli 1 e 2. La partecipazione individuale avviene secondo disponibilità, competenze e regole del Codice 3. Non sono ammesse imposizioni incompatibili con la libertà individuale, con le condizioni della persona o con le competenze richieste. La mancata disponibilità individuale non può comportare la perdita del diritto della persona fragile alle prestazioni essenziali.

3.  Il tempo di cura è registrato in forma aggregata per programmare i servizi, verificare la copertura dei livelli 1 e 2 e individuare carenze. La registrazione non può essere impiegata per profilare le persone che ricevono o prestano cura al di fuori delle finalità consentite dal Codice 7.

4.  Le competenze sono ripartite come segue:

    a) il Codice C.1-Annex A disciplina la fabbricazione, la riparazione e la standardizzazione degli ausili;

    b) il Codice 9 disciplina la produzione e la preparazione degli alimenti e la gestione tecnico-organizzativa delle mense;

    c) il Codice 12 disciplina l’assistenza alla persona fragile nell’accesso e nell’accompagnamento al pasto, nel consumo assistito, nell’igiene e nell’uso quotidiano degli ausili.

    Il presente Codice non attribuisce al Consiglio Cura la competenza a produrre ausili o a organizzare la preparazione degli alimenti.

5.  Per le prestazioni di livello 4 o 5, prima di richiedere nuove risorse è verificata la possibilità di riuso o recupero di ausili, abbigliamento e spazi, purché la soluzione sia sicura, adeguata al bisogno e non riduca la qualità delle prestazioni essenziali.

6.  È garantito il diritto al domicilio delle persone anziane e non autosufficienti, con supporto comunitario a turni incluso nel CBO, ai sensi dell’articolo 27 della Costituzione. Le Case Comuni autogestite sono una scelta della persona e non possono costituire una destinazione coatta.

## Art. 6 — Spazi, rete federata e territorio

1.  Ogni Cerchio 1 attiva e mantiene gli spazi di cura necessari, direttamente o mediante accordi di rete. Gli spazi sono accessibili, possono essere suddivisi in aree funzionali e dispongono di Schede Sicurezza aggiornate per le attività effettivamente svolte.
2.  La destinazione d’uso e la localizzazione degli spazi sono disciplinate dal Codice 10. Il Codice 12 disciplina la funzione di cura svolta al loro interno, senza modificare la destinazione territoriale o i vincoli di competenza del Codice 10.
3.  La Confederazione assicura in ogni Cerchio 2 almeno una struttura federata con competenze avanzate ogni tre o quattro Cerchi 1 che lo compongono. La pianificazione, deliberata dall’Assemblea Generale del Cerchio 2, individua i servizi disponibili e le modalità di accesso. Le strutture garantiscono, secondo necessità, competenze di pediatria sociale, supporto alla disabilità complessa e spazi temporanei di emergenza.
4.  L’accesso alle strutture federate avviene secondo criteri pubblici, non discriminatori e compatibili con l’urgenza del bisogno. L’inventario delle risorse è condiviso tra i Cerchi interessati e aggiornato con le modalità stabilite dalla STV.
5.  La misurazione dei servizi è limitata ai dati necessari per la sicurezza, la programmazione del tempo di cura e la verifica del Paniere Cura. I dati individuali eventualmente necessari per la presa in carico restano riservati; gli indicatori pubblici sono aggregati e non profilanti. È vietata la profilazione individuale comportamentale non necessaria alle finalità del presente Codice, in conformità al Codice 7, articolo 2.2.

## Art. 7 — Sicurezza, formazione e diritto di interruzione

1.  Nessuna attività rivolta a persone fragili può essere avviata senza una Scheda Sicurezza vigente e adeguata all’attività. La Scheda è validata dal Consiglio Cura, previo parere obbligatorio del Consiglio Salute per i profili relativi a rischio sanitario, igiene e pasti assistiti. La titolarità della validazione resta al Consiglio Cura, salvo i casi in cui un Codice preveda espressamente una validazione congiunta.

2.  Le Schede Sicurezza di cura sono coordinate con le disposizioni del Codice 1, articolo 27, e del Codice 14, ciascuno per la propria competenza. In caso di rischio sanitario o clinico si applicano le procedure del Codice 6.

3.  I presidi essenziali per la cura di comunità sono gestiti nel Magazzino Salute disciplinato dal Codice 6. Sono disponibili senza oneri per la persona interessata, sottoposti a manutenzione e registrati nell’inventario pertinente. L’indisponibilità di un presidio essenziale comporta la sospensione della sola attività che non può essere svolta in sicurezza; il Consiglio Cura attiva, ove tecnicamente possibile, una funzione sostitutiva conforme per assicurare la continuità dei livelli 1 e 2.

4.  La formazione minima richiesta è la seguente:

    a) livello L1 per l’accesso operativo agli spazi fragili e per le attività di cura di base;

    b) livello L2 per le attività che coinvolgono l’infanzia, le persone in grande età non autosufficienti o le persone con disabilità, secondo la classificazione del Codice 5;

    c) livello L3 per la progettazione delle attività di cura, la redazione delle STV e le funzioni di validazione previste dal presente Codice.

5.  Chiunque rilevi un rischio immediato per una persona fragile interrompe l’attività interessata, adotta le misure urgenti di protezione consentite e informa senza ritardo il Consiglio Cura e gli altri Consigli competenti. L’interruzione effettuata in buona fede per prevenire un danno non può comportare ritorsioni o pregiudizi per la persona segnalante.

## Art. 7-bis — Protezione dei minori e delle persone temporaneamente incapaci

1.  In caso di violenza, grave negligenza o pregiudizio a danno di un minore o di una persona che non è in grado di tutelarsi, il Consiglio Cura attiva senza ritardo un percorso di protezione, ai sensi dell’articolo 26.3 della Costituzione. Il percorso comprende la messa in sicurezza, l’ascolto e, se necessario, l’accoglienza temporanea presso persone di fiducia o in uno spazio protetto.
2.  Il fatto è segnalato al Cerchio di Garanzia per le procedure del Codice 4. Le segnalazioni nella Rete sono limitate alle informazioni necessarie alla tutela. Durante la transizione si applica l’articolo 37 del Codice 4.
3.  La separazione di un minore dal proprio Cerchio 0 è ammessa soltanto come misura temporanea di protezione, quando il minore non può essere messo in sicurezza restando nel Cerchio 0. È disposta:

    a) in presenza di un pericolo immediato, ai sensi dell’articolo 34, comma 1, del Codice 4;

    b) negli altri casi di violenza, grave negligenza o pregiudizio, dal Cerchio di Garanzia su proposta motivata del Consiglio Cura, dopo aver ascoltato il minore e, salvo che ciò lo esponga a pericolo, le persone che ne hanno la responsabilità di cura.

La separazione è comunicata senza ritardo al Tribunale di Garanzia, che la convalida, la modifica o la revoca entro ventiquattro ore; in mancanza di convalida cessa. Il minore è accolto, se possibile, presso persone di sua fiducia. La convalida indica chi prende, durante la separazione, le decisioni quotidiane e presta il consenso alle cure ai sensi dell’articolo 2-ter del Codice 6. La separazione convalidata dura fino alla decisione del comma 3-bis e cessa con essa. Non si applica l’articolo 34, comma 3, del Codice 4.

3-bis. Entro trenta giorni dalla convalida il Tribunale di Garanzia prende la decisione stabile sull’affidamento, dopo aver ascoltato il minore, assistito dalla persona di fiducia prevista dall’articolo 31.5 della Costituzione, le persone che ne hanno la responsabilità di cura, con le garanzie dell’articolo 25, comma 4, del Codice 4, e il Consiglio Cura. Il termine è prorogabile una sola volta, per non più di altri trenta giorni, con decisione motivata, quando un elemento necessario non può essere acquisito prima, come una valutazione sanitaria del minore. Alla scadenza il Tribunale decide allo stato degli atti; se la decisione non è adottata, la separazione cessa. Tenendo conto della volontà del minore secondo l’età e la maturità, dispone:

a) il rientro nel Cerchio 0, eventualmente con un percorso di sostegno; oppure

b) soltanto quando il rientro esporrebbe il minore a violenza, grave negligenza o pregiudizio che un percorso di sostegno non può evitare, l’affidamento a persone che assumono la responsabilità di cura ai sensi dell’articolo 24.3 della Costituzione, indicando se essa resta condivisa con le persone che la esercitavano o è sospesa per loro, e come sono mantenuti i rapporti con loro, salvo che ciò nuoccia al minore.

La decisione è riesaminata dal Tribunale almeno ogni sei mesi e in ogni momento su richiesta del minore o delle persone che avevano la responsabilità di cura. Contro di essa è ammesso il riesame dell’articolo 35, comma 2, del Codice 4. Il presente comma si applica anche alla decisione su dove e con chi vivono i figli minori della persona che cessa di essere membro ai sensi dell’articolo 29, comma 6-bis, del Codice 4; la decisione è presa prima che la cessazione produca effetti e non richiede la separazione del comma 3. In tal caso la cessazione non costituisce, da sola, violenza, grave negligenza o pregiudizio ai sensi della lettera b), e il Tribunale può disporre anche che il minore viva con la persona sulla porzione assegnata, con l’alloggio, il Paniere e i servizi che gli spettano come membro. Il presente comma si applica anche, su segnalazione del Consiglio Cura o di chiunque vi abbia interesse, quando nessuno esercita la responsabilità di cura del minore o più persone se la contendono; il termine decorre dalla segnalazione e il Tribunale indica chi assume la responsabilità di cura.

3-ter. Durante la transizione la separazione contro la volontà di chi ha la responsabilità di cura e le decisioni del comma 3-bis spettano alle autorità dello Stato competenti, ai sensi dell’articolo 37 del Codice 4. Il Consiglio Cura segnala il caso, sostiene il minore e collabora alla sua accoglienza.

4.  Ogni persona può designare in anticipo un rappresentante per il caso di incapacità, anche con il testamento biologico previsto dall’articolo 8-bis del Codice 6.
5.  In mancanza di designazione e in caso di urgenza, il Cerchio di Garanzia nomina entro ventiquattro ore un rappresentante temporaneo, scelto nell’ordine tra le persone del Cerchio 0 indicate dalla persona, la sua persona di fiducia e una persona sorteggiata con competenza L2 nella cura, priva di conflitti di interesse. L’incarico dura non più di trenta giorni ed è rinnovabile con decisione motivata fino alla nomina del rappresentante stabile prevista dall’articolo 2-ter, comma 5, del Codice 6, che il Cerchio di Garanzia chiede al Tribunale di Garanzia quando l’incapacità dura o si prevede che duri oltre sessanta giorni.
6.  Il rappresentante decide secondo la volontà espressa o presumibile della persona e, in mancanza, secondo il suo migliore interesse. L’incarico cessa quando la persona recupera la capacità.

## Art. 7-ter — Scelta residenziale e uscita dei minori dalla Confederazione

1.  In attuazione dell’articolo 26.2 della Costituzione, il minore che ha compiuto quattordici anni e ha raggiunto l’autonomia può scegliere di vivere in un Cerchio 0 diverso da quello delle persone che ne hanno la responsabilità di cura, nella stessa o in un’altra Comunità, con il consenso di chi vi abita, oppure in un alloggio assegnato ai sensi dell’articolo 47-ter del Codice 1. La scelta non modifica lo status di membro né i diritti dell’articolo 26 della Costituzione. Il minore può in ogni momento tornare a vivere con le persone che ne hanno la responsabilità di cura.

2.  L’autonomia è valutata congiuntamente dal Consiglio Cura e dal Consiglio delle Competenze, su richiesta del minore. Entro trenta giorni dalla richiesta essi ascoltano il minore, assistito, se lo desidera, dalla persona di fiducia prevista dall’articolo 31.5 della Costituzione, le persone che ne hanno la responsabilità di cura e chi lo accoglie, e verificano:

    a) che la scelta sia libera, stabile e non determinata da pressioni di altre persone;

    b) che il minore sia in grado di provvedere alla propria vita quotidiana con il sostegno disponibile;

    c) che la nuova collocazione sia sicura e gli assicuri l’alloggio, il Paniere, le cure, l’apprendimento e i rapporti con le persone care.

La decisione è motivata e indica chi prende le decisioni quotidiane e come sono mantenuti i rapporti con le persone che hanno la responsabilità di cura, salvo che ciò nuoccia al minore. La responsabilità di cura e il consenso alle cure previsto dall’articolo 2-ter del Codice 6 restano a chi li esercita, salvo una decisione del Tribunale di Garanzia ai sensi dell’articolo 7-bis, comma 3-bis.

3.  La scelta residenziale e l’opposizione delle persone che hanno la responsabilità di cura non costituiscono, da sole, violenza, grave negligenza o pregiudizio ai sensi dell’articolo 7-bis. Se la richiesta rivela violenza, grave negligenza o pregiudizio, il Consiglio Cura attiva il percorso di protezione dell’articolo 7-bis, che prevale sulla procedura del presente articolo.

4.  Contro la decisione del comma 2, o se essa non è presa nel termine, il minore e ciascuna persona che ne ha la responsabilità di cura possono ricorrere entro quattordici giorni al Tribunale di Garanzia, che decide entro trenta giorni con le garanzie dell’articolo 7-bis, comma 3-bis, tenendo conto della volontà del minore secondo l’età e la maturità. Contro la decisione del Tribunale è ammesso il riesame dell’articolo 35, comma 2, del Codice 4.

4-bis. Il minore è membro dalla nascita, o dall’arrivo nella Comunità, se lo è almeno una delle persone che ne hanno la responsabilità di cura. Negli altri casi l’adesione è resa con le regole di età dell’articolo 26.5 della Costituzione: dal compimento del sedicesimo anno dal minore stesso, prima da chi ne ha la responsabilità di cura, nel suo interesse e dopo averlo informato e ascoltato. Ai fini dell’articolo 26.4 della Costituzione è cresciuta nella Confederazione la persona che è stata membro da minore per almeno un anno.

5.  Dal compimento del sedicesimo anno il minore può rendere da sé la dichiarazione dell’articolo 4.8 della Costituzione, ai sensi dell’articolo 26.5 della Costituzione. La dichiarazione è preceduta da un colloquio con il Consiglio Cura, nel quale il minore può farsi assistere dalla persona di fiducia; il Consiglio lo informa degli effetti dell’articolo 4.8, dei diritti che conserva ai sensi del comma 8, del Patto di Convivenza Autonoma e della riammissione, e verifica con lui dove e con chi vivrà. Il colloquio si svolge entro quattordici giorni dalla richiesta; decorso il termine senza colloquio, la dichiarazione può essere resa comunque. Le persone che hanno la responsabilità di cura sono informate, salvo che ciò esponga il minore a pericolo. Se, prima del diciottesimo anno, il minore non è in grado di decidere, si applica il comma 6.

6.  Fino al compimento del sedicesimo anno la dichiarazione dell’articolo 4.8 della Costituzione per il minore è resa da chi ne ha la responsabilità di cura, soltanto nell’interesse del minore, dopo averlo informato e ascoltato in modo adatto all’età; il parere del minore ha un peso crescente con l’età e la maturità, ai sensi dell’articolo 26.2 della Costituzione. Se le persone responsabili sono più d’una, decidono d’accordo. La dichiarazione che una persona rende per sé non si estende ai minori di cui ha la responsabilità di cura.

7.  Entro quattordici giorni dalla dichiarazione del comma 5 o del comma 6, possono rivolgersi al Tribunale di Garanzia il minore, ciascuna persona che ne ha la responsabilità di cura o il Consiglio Cura. Il Tribunale ascolta il minore, assistito dalla persona di fiducia, e le persone responsabili e decide entro trenta giorni:

    a) per la dichiarazione del comma 5, verifica soltanto che sia libera e informata e che il minore sia in grado di decidere, senza valutarne l’opportunità; il ricorso non ne sospende gli effetti;

    b) per la dichiarazione del comma 6, decide secondo l’interesse del minore, tenendo conto del suo parere; fino alla decisione la dichiarazione non produce effetti per il minore. Se il minore resta membro, il Tribunale decide anche dove e con chi vive, ai sensi dell’articolo 7-bis, comma 3-bis.

Contro la decisione è ammesso il riesame dell’articolo 35, comma 2, del Codice 4.

8.  Il minore che non è più membro conserva in ogni caso l’acqua potabile, le cure d’emergenza salvavita e la protezione dei minori garantite dall’articolo 1.3 della Costituzione, i diritti dell’articolo 26 della Costituzione richiamati dall’articolo 4.9-bis, compreso l’accesso alle cure e all’apprendimento, e gli altri diritti dell’articolo 4.9, salvo il limite della lettera b). Ai sensi dell’articolo 26.5 della Costituzione può continuare a vivere nel proprio Cerchio 0, con il consenso di chi vi abita, fino al compimento del diciottesimo anno; nel frattempo riceve il Paniere per sé e non gli si applica l’articolo 4.9-ter della Costituzione. Può chiedere in ogni momento la riammissione ai sensi dell’articolo 4.8 della Costituzione.

9.  Durante la transizione il presente articolo si applica nei limiti consentiti dalla legge vigente sulla responsabilità di cura e sulla partecipazione dei minori agli enti, ai sensi dell’articolo 37 del Codice 4. La scelta residenziale contro la volontà di chi ha la responsabilità di cura e le decisioni del Tribunale previste dai commi 4 e 7 spettano alle autorità dello Stato competenti; il Consiglio Cura sostiene il minore.

## Art. 8 — Registro Dipendenze della cura

1.  Il Consiglio Cura alimenta il Registro Dipendenze disciplinato dal Codice 15, indicando almeno:

    a) **dipendenze materiali**, relative ad ausili, presidi o spazi non disponibili nella Confederazione, disponibili soltanto oltre la soglia temporale critica definita nella STV o non sostituibili localmente;

    b) **dipendenze da competenze**, relative a competenze di livello L2 o L3 non disponibili nel bacino di cui all’articolo 6, comma 3;

    c) **dipendenze esterne**, relative a servizi di cura esterni alla Confederazione necessari per garantire la continuità dei livelli 1 e 2.

2.  Per ogni dipendenza critica il Registro indica:

    a) la risorsa o competenza mancante;

    b) il servizio e i livelli del Paniere interessati;

    c) il responsabile del piano di riduzione della dipendenza;

    d) le misure temporanee di continuità e mitigazione del rischio;

    e) il termine finale previsto per il superamento della dipendenza o per una nuova valutazione motivata.

3.  Il piano di uscita deve prevedere un termine finale certo. Qualora il superamento non sia tecnicamente realizzabile entro tale termine, il Consiglio Cura propone una revisione motivata del piano e delle misure di continuità; la revisione non può limitarsi a prorogare la dipendenza senza indicare interventi e responsabilità.

4.  Ogni anno è svolto un audit federato sull’autonomia della cura da parte di componenti L3 indipendenti, sorteggiati secondo l’articolo 36 del Codice 4. L’audit valuta anche la copertura effettiva dei livelli 1 e 2 e il rispetto della riservatezza.

## Art. 9 — Divieti, garanzie e rimedi

1.  È vietato:

    a) realizzare rendite sul Paniere Cura dei livelli 1 e 2, sugli spazi essenziali, sul tempo minimo di cura o sui presidi essenziali;

    b) subordinare a pagamento o a licenza esclusiva l’accesso alle STV salvavita e alle Schede Sicurezza;

    c) riservare in via esclusiva o accumulare tempo di cura, spazi o ausili oltre i limiti tecnici, quando ciò riduca la disponibilità per altre persone aventi diritto;

    d) negare o sospendere una prestazione essenziale del Paniere Cura come misura sanzionatoria;

    e) trasferire a soggetti esterni il controllo degli spazi di cura essenziali;

    f) utilizzare dati sulla fragilità funzionale per profilazioni o finalità diverse dalla presa in carico e dalle finalità tecniche espressamente consentite dal Codice 7;

    g) disporre l’istituzionalizzazione forzata di una persona, salvo una collocazione temporanea strettamente necessaria a fronte di un rischio immediato, adottata alle condizioni e con le garanzie dell’articolo 8, commi da 4 a 10, del Codice 6; per i minori si applicano inoltre l’articolo 8 del Codice 6 e, se la collocazione li separa dal Cerchio 0, l’articolo 7-bis, comma 3. Gli eventuali trattamenti sanitari restano disciplinati dal Codice 6 e dalle relative garanzie.

2.  Le violazioni del comma 1 costituiscono violazioni sostanziali. L’accertamento, le misure cautelari, la sospensione o la disattivazione della funzione e i rimedi sono adottati secondo il Codice 4. Il Consiglio Cura documenta i fatti e attiva le procedure previste, senza sostituirsi agli organi competenti per l’accertamento o per l’applicazione dei rimedi.

3.  La sospensione o la disattivazione di una funzione non conforme non può interrompere le prestazioni dei livelli 1 e 2 quando sia possibile garantirle mediante una funzione sostitutiva tecnicamente conforme. In caso di rischio immediato, si applicano le misure urgenti previste dai Codici competenti, con contestuale attivazione della continuità assistenziale per quanto possibile.

4.  La persona interessata o chi dimostri un interesse qualificato può ricorrere alla Garanzia secondo il Codice 4, entro quattordici giorni dalla comunicazione della decisione o dalla conoscenza effettiva della violazione. Il ricorso può riguardare vizi procedurali, manifesta irragionevolezza tecnica, discriminazione o sproporzione. Il ricorso non sospende automaticamente le misure urgenti necessarie a prevenire un danno, salvo diversa decisione dell’organo competente.

## Art. 10 — Attuazione, coordinamento e prevalenza

1.  Il presente Codice si coordina, per le rispettive materie, con:

    a) il Codice 1, articoli 27 e 32, per le Schede Sicurezza e l’ordine di priorità del Paniere;

    b) il Codice 2, per le STV;

    c) il Codice 3, per le deliberazioni e il metodo del consenso;

    d) il Codice 4, per la Garanzia e i rimedi;

    e) il Codice 5, per i livelli di competenza e formazione;

    f) il Codice 6, per la salute, le prestazioni cliniche e il Magazzino Salute;

    g) il Codice 7, articolo 2.2, per le regole sulla rete e sui dati;

    h) il Codice 8, per le risorse idriche eventualmente necessarie agli spazi di cura;

    i) il Codice C.1-Annex A, per gli ausili;

    j) il Codice 9, per la produzione alimentare e le mense;

    k) il Codice 10, per la destinazione territoriale degli spazi;

    l) i Codici 13, 14 e 15, per le rispettive materie, inclusi biodiversità, sicurezza e Registro Dipendenze.

2.  Entro sei mesi dall’entrata in vigore, ogni Cerchio 1:

    a) censisce, con modalità rispettose della riservatezza, i bisogni funzionali rilevanti per la continuità dei livelli 1 e 2;

    b) censisce gli spazi di cura, le dotazioni e le disponibilità di tempo;

    c) attiva il Paniere Cura minimo mediante STV provvisoria e Schede Sicurezza minime.

3.  Entro dodici mesi dall’entrata in vigore, ogni Cerchio 1:

    a) istituisce il Consiglio Cura;

    b) garantisce l’accesso agli spazi di cura minimi;

    c) attiva l’inventario federato degli ausili;

    d) adotta le STV definitive per i livelli 1 e 2;

    e) individua il proprio nodo della Rete Cura federata.

    In presenza di sovrapposizioni documentate dei carichi transitori relativi ai Codici 9, 10 e 12, l’Assemblea può concedere una proroga motivata, per un periodo non superiore a sei mesi. La proroga indica le attività ancora da completare, i responsabili e le scadenze intermedie e non può sospendere la garanzia dei livelli 1 e 2.

4.  Le funzioni esistenti che risultino in violazione dell’articolo 9 sono sottoposte senza ritardo a verifica secondo il Codice 4. Entro novanta giorni dall’entrata in vigore deve essere avviato, per ciascuna funzione interessata, un percorso documentato di adeguamento oppure, se l’adeguamento è tecnicamente impossibile, il procedimento di disattivazione previsto dal Codice 4. Il piano individua la funzione sostitutiva e un termine finale certo. La disattivazione di una funzione che garantisce i livelli 1 e 2 avviene soltanto dopo l’attivazione della sostituzione, salvo le misure urgenti necessarie a fronteggiare un rischio immediato, adottate con le garanzie del Codice 4.

5.  In caso di sovrapposizione normativa, ciascun Codice prevale limitatamente alla materia che gli è attribuita:

    a) il Codice 12 per l’organizzazione della cura di comunità, l’accertamento della fragilità funzionale, il Paniere Cura e la funzione interna degli spazi di cura;

    b) il Codice 6 per diagnosi, prestazioni cliniche, nutrizione clinica e rischi sanitari;

    c) il Codice 9 per produzione e preparazione degli alimenti e gestione tecnico-organizzativa delle mense;

    d) il Codice 10 per destinazione d’uso e localizzazione territoriale degli spazi;

    e) il Codice C.1-Annex A per fabbricazione e standardizzazione degli ausili;

    f) il Codice 14 per i profili di sicurezza di sua competenza.

    La prevalenza è limitata all’oggetto specifico e non comporta l’assorbimento delle competenze attribuite agli altri Codici. In caso di conflitto non risolvibile mediante interpretazione coordinata, gli organi competenti definiscono una soluzione congiunta secondo le procedure dell’ordinamento, assicurando nel frattempo le misure di protezione necessarie e la continuità dei livelli 1 e 2.
