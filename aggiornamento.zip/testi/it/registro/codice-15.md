---
titolo: "CODICE 15 — RAPPORTI ESTERNI E SALDO MONDIALE"
breve: "Codice 15 — Rapporti esterni e Saldo"
versione: "V1.13"
gruppo: "codici"
ordine: 15
id: "codice-15"
slug: "codice-15"
allineamento: "Costituzione V.40; Codice 1 V1.12; Codice 2 V1.9; Codice 3 V1.13; Codice 4 V1.11; Codice 5 V1.7; Codice 6 V1.9; Codice 7 V1.10; Codice 8 V1.7; C.1-Annex A V1.7; Codice 9 V3.4; Codice 10 V1.8; Codice 11 V1.6; Codice 12 V1.7; Codice 13 V1.9; Codice 14 V1.10; Codice 16 V1.11."
---

## TITOLO PRELIMINARE — DISPOSIZIONI GENERALI

### Art. 1 — Oggetto, presupposto e principi

1.  Il presente Codice disciplina il calcolo e la compensazione delle differenze geografiche tra produzione e fabbisogno dei beni, delle risorse e dei servizi compresi nel Paniere di Sufficienza di cui al Codice 1. Disciplina inoltre il Registro Dipendenze e i rapporti della Confederazione con i soggetti esterni.
2.  Il Saldo opera tra i Cerchi confederati alla scala effettivamente raggiunta dalla Confederazione: di Bacino, di Bioregione e, quando la Confederazione comprende l’intera umanità, mondiale. Le espressioni «Saldo Unico Mondiale» e «Pool Mondiale» indicano il Saldo e il Pool alla scala raggiunta. Fino ad allora i rapporti con i soggetti esterni, le clausole di autonomia strategica e le contromisure in caso di ricatto relativo a risorse sono disciplinati dal Capo IV; le misure transitorie sono disciplinate dal Codice 16.
3.  All’interno della Confederazione, i beni del Paniere di Sufficienza non sono oggetto di compravendita o scambio mercantile. La loro distribuzione avviene tramite il Saldo Unico Mondiale. Lo scambio mercantile è ammesso esclusivamente nei rapporti esterni, secondo il Capo IV e il Codice 16.
4.  Il Saldo Unico Mondiale è fondato su dati verificabili, criteri uniformi, tracciabilità delle risorse e decisioni umane. I sistemi automatizzati possono elaborare dati e formulare proposte, ma non possono assumere autonomamente decisioni di allocazione o trasferimento.

## CAPO I — SALDO UNICO MONDIALE, LAVORO MINIMO NECESSARIO E RISERVE

### Art. 2 — Definizioni contabili e sequenza di calcolo

1.  Ai fini del presente Codice si intende per:

    a) **P — Prodotto Contabilizzabile**: la quantità di una risorsa conforme agli standard di qualità applicabili e verificata secondo le procedure del Codice competente. Per i beni soggetti a Scheda Tecnica di Validazione si applica la STV prevista dal Codice 2;

    b) **B — Bisogno Reale Validato**: il fabbisogno umano validato dal Consiglio competente, comprensivo delle perdite ordinarie di conservazione e trasporto e delle quantità necessarie alla semina, alla manutenzione ordinaria e alla continuità operativa. B non comprende la Riserva Tecnica Non Federabile di cui all’articolo 5;

    c) **Saldo Lordo**: il risultato della sottrazione di B da P, calcolato secondo la formula **P − B**;

    d) **Saldo Disponibile**: la quantità positiva del Saldo Lordo che rimane dopo l’accantonamento della Riserva Tecnica Non Federabile. La riserva riduce esclusivamente un saldo positivo e non aumenta un deficit;

    e) **Saldo Federabile**: la parte del Saldo Disponibile che è conforme, fisicamente disponibile e logisticamente prelevabile, secondo l’accertamento previsto dall’articolo 3;

    f) **TRU — Tempo Residuo di Utilità**: il periodo durante il quale una risorsa conserva la propria utilità d’uso secondo gli standard applicabili;

    g) **Pool Mondiale**: l’insieme delle disponibilità costituite dai Saldi Federabili accertati;

    h) **Riserva Federata**: la quota del Pool Mondiale non ancora assegnata a una specifica destinazione e mantenuta per una successiva allocazione.

2.  Per ogni risorsa e periodo contabile si applica obbligatoriamente la seguente sequenza:

    **P → B → Saldo Lordo → Riserva Tecnica Non Federabile → Saldo Disponibile → Saldo Federabile → Pool Mondiale → allocazione.**

3.  Il calcolo è effettuato come segue:

    a) se P − B è pari o inferiore a zero, il risultato costituisce il deficit e non è ulteriormente ridotto per effetto della Riserva Tecnica;

    b) se P − B è positivo, la Riserva Tecnica è sottratta dal surplus fino a concorrenza dello stesso;

    c) la quantità residua, se positiva e accertata come fisicamente e logisticamente disponibile, costituisce il Saldo Federabile.

4.  Le quantità necessarie a semina, manutenzione ordinaria e continuità operativa sono conteggiate una sola volta: o nel calcolo di B come fabbisogno ordinario del periodo, oppure come Riserva Tecnica ai sensi dell’articolo 5, se rispondono ai requisiti di quest’ultima. La stessa quantità non può essere imputata contemporaneamente a entrambe le voci.

5.  Il periodo contabile è trimestrale. Il Paniere di Sufficienza e gli allegati tecnici definiscono unità di misura, scorte iniziali, criteri per il calcolo delle perdite ordinarie e modalità di riconciliazione dei dati tra periodi consecutivi. La gestione logistica può operare con aggiornamenti più frequenti, fermo restando il rendiconto trimestrale.

### Art. 3 — Dichiarazione e accertamento del Saldo Federabile

1.  Ogni Cerchio 1, 2 e 3 dichiara trimestralmente, per ciascuna risorsa di propria competenza:

    a) il Prodotto Contabilizzabile;

    b) il Bisogno Reale Validato;

    c) il Saldo Lordo;

    d) la Riserva Tecnica accantonata;

    e) il Saldo Disponibile;

    f) il Saldo Federabile proposto.

2.  Le dichiarazioni dei diversi Cerchi sono coordinate in modo da evitare la duplicazione delle stesse quantità. Ogni risorsa fisica è registrata una sola volta come disponibilità originaria; le registrazioni dei Cerchi 2 e 3 riportano dati consolidati e non sono sommate nuovamente ai dati dei Cerchi che vi sono compresi.

3.  L’accertamento del Saldo Federabile è un procedimento tecnico svolto dal Consiglio di Magazzino del Cerchio presso cui la risorsa è custodita. Il Consiglio:

    a) verifica la conformità dei dati dichiarati;

    b) verifica la disponibilità fisica e logistica della risorsa;

    c) consulta le STV, i registri di settore e il Registro Dipendenze pertinente;

    d) registra le motivazioni di eventuali rettifiche;

    e) resta responsabile dell’accertamento anche quando si avvale di verifiche automatizzate.

4.  Le procedure di controllo e verifica seguono i Codici 1 e 2. Il Registro Dipendenze contribuisce a rappresentare i vincoli e le dipendenze che incidono sulla disponibilità, ma non sostituisce i registri contabili e di magazzino necessari a documentare P, B, scorte e trasferimenti.

5.  Il Saldo Federabile accertato è iscritto nel Pool Mondiale secondo criteri oggettivi prestabiliti. L’organo competente per l’allocazione non può modificare discrezionalmente la qualificazione tecnica della risorsa come federabile; può deliberare esclusivamente la sua destinazione e le modalità del trasferimento secondo le priorità del presente Codice.

6.  L’iscrizione nel Pool deriva dall’accertamento delle condizioni previste dal presente Codice e non da una deliberazione politica sulla natura della risorsa.

### Art. 4 — Saldo Unico Mondiale

1.  Il surplus positivo accertato come federabile è custodito fisicamente nel magazzino del Cerchio presso cui si trova, ma è contabilizzato come parte del Pool Mondiale. A titolo esemplificativo, se P è pari a 100, B è pari a 80 e non occorre accantonare una Riserva Tecnica, il Saldo Federabile proposto è pari a 20, subordinatamente alla verifica della disponibilità fisica e logistica.
2.  Un deficit accertato attiva la procedura di copertura da parte del Pool Mondiale secondo le priorità dell’articolo 8. L’avvio della procedura è automatico; l’assegnazione e il trasferimento sono deliberati dall’organo umano competente ai sensi dell’articolo 9.
3.  La gestione delle disponibilità non dà luogo a rapporti bilaterali di fornitura tra Cerchi. Opera un unico Pool Mondiale Logistico. Nessun Cerchio può pretendere di scegliere il destinatario finale del proprio surplus o di conoscere l’origine specifica della risorsa assegnata a copertura di un deficit, fatti salvi gli obblighi di tracciabilità e trasparenza previsti dal presente Codice.

### Art. 5 — Riserva Tecnica Non Federabile e Riserva Federata

1.  La **Riserva Tecnica Non Federabile** è costituita dalle quantità strettamente necessarie alla continuità tecnica e infrastrutturale del Cerchio. Può comprendere, secondo necessità documentata, pezzi di ricambio, energia per la continuità, materiali per riparazioni d’emergenza e sementi di conservazione.

2.  La Riserva Tecnica è validata dal Consiglio competente, resta esclusa dal Pool Mondiale e non è ordinariamente trasferibile. Il trasferimento straordinario è ammesso soltanto in presenza di un’emergenza documentata e secondo le procedure di sicurezza e coordinamento previste dal Codice 1.

3.  Il limite massimo della Riserva Tecnica è determinato, per ciascuna risorsa, sulla base cumulativa di:

    a) fabbisogno tecnico documentato;

    b) rischio di interruzione del servizio o dell’infrastruttura;

    c) tempo necessario per ottenere una risorsa sostitutiva;

    d) capacità di ripristino locale.

    Il limite è riesaminato almeno una volta all’anno. Le quantità eccedenti sono riclassificate come Saldo Disponibile e sottoposte all’accertamento di cui all’articolo 3.

4.  La **Riserva Federata** è una parte del Pool Mondiale non ancora assegnata a una destinazione specifica. È conservata esclusivamente per una futura ridistribuzione e non può essere utilizzata per creare scarsità artificiale o per finalità speculative.

5.  La Riserva Federata è registrata con indicazione della quantità, della categoria della risorsa, della motivazione dell’accantonamento, del TRU e della data entro cui è opportuno procedere all’allocazione. Le informazioni sulla localizzazione sono pubblicate soltanto quando la loro diffusione non crei rischi per la sicurezza o la conservazione della risorsa; il dettaglio tecnico resta accessibile agli organi competenti.

6.  È vietato l’**Accumulo Estrattivo**, inteso come trattenimento di risorse finalizzato a creare scarsità artificiale, attendere un incremento di valore o assicurare un uso esclusivo. Sono ammesse esclusivamente le riserve disciplinate dal presente articolo e ogni altra forma di accantonamento espressamente prevista dai Codici competenti.

### Art. 6 — Prevenzione dello spreco

1.  L’Intelligenza Artificiale Gestionale disciplinata dal Codice 7 segnala il superamento delle soglie di rischio spreco definite dalle STV e indica il TRU residuo. La segnalazione costituisce un supporto tecnico e non sostituisce la valutazione e la decisione del Consiglio di Magazzino.
2.  Il Consiglio di Magazzino del Cerchio presso cui la risorsa è custodita decide e attua, entro un massimo ordinario di settantadue ore dalla segnalazione, le misure necessarie di trasformazione o riciclo; la riassegnazione tramite il Pool è decisa entro lo stesso termine dal Consiglio previsto dall’articolo 9-bis. Se la riassegnazione non è decisa in tempo utile, il Consiglio del Cerchio di custodia destina la risorsa secondo l’articolo 15, comma 2, del Codice 1. Il termine è ridotto quando necessario per intervenire prima della scadenza del TRU e non può mai comportare che l’intervento avvenga dopo che la risorsa abbia perso la propria utilità.
3.  Quando il TRU è inferiore a sette giorni, l’intervento è disposto senza ritardo, tenendo conto dei tempi effettivi di trasporto, trasformazione e impiego della risorsa.
4.  La perdita di una Riserva Federata per omissione o ritardo ingiustificato nella riassegnazione costituisce danno alla Confederazione ed è trattata secondo il Codice 4.

## CAPO II — MECCANISMO OPERATIVO, LOGISTICA FEDERALE E GARANZIE

### Art. 7 — Lavoro Minimo Necessario Globale

1.  Per ciascun Cerchio, il fabbisogno di lavoro necessario alla produzione e alla gestione delle risorse è determinato secondo la seguente formula:

    **Lavoro Necessario = Bisogno Locale Validato + Quota di Bisogno Globale assegnata dal Pool Mondiale.**

2.  Il presente Codice determina il fabbisogno complessivo di lavoro necessario alla gestione della quota federata. L’assegnazione delle persone, delle squadre e delle modalità organizzative è disciplinata dal Codice 1, secondo criteri di prossimità, competenza e sicurezza.

3.  Il tempo di lavoro effettivamente necessario alla produzione, conservazione, preparazione e trasferimento della quota federata è riconosciuto ai fini del CBO secondo la disciplina del Codice 1. Tale attività non costituisce lavoro gratuito.

4.  La quota di CBO imputabile al Pool è calcolata in base al lavoro effettivamente necessario e documentato; non è determinata mediante una conversione automatica tra unità fisiche di prodotto e ore di lavoro.

### Art. 8 — Calcolo, proposta e priorità di allocazione

1.  L’IA del Cerchio Intermedio prevista dall’articolo 22.2 della Costituzione elabora, per il proprio Cerchio 2, almeno ogni ventiquattro ore una mappa aggiornata delle disponibilità federabili e dei deficit dichiarati. Le mappe dei Cerchi 2 sono scambiate mediante i protocolli aperti dell’articolo 5-ter, comma 3, del Codice 7 e, tra Cerchi Estesi, mediante il protocollo distribuito dell’articolo 19.7 della Costituzione; nessun sistema le riunisce in un modello centrale, ai sensi dell’articolo 5-ter, comma 2, del Codice 7. La mappa considera almeno:

    a) quantità e ubicazione delle risorse;

    b) energia necessaria per ciascun trasferimento;

    c) deperibilità e TRU;

    d) urgenza e livello del bisogno;

    e) capacità e sicurezza delle infrastrutture logistiche.

    Il sistema formula proposte di flusso ottimizzato, ma non assume decisioni di allocazione o trasferimento.

2.  Nell’ambito del Pool Mondiale, le proposte sono ordinate secondo le seguenti priorità:

    a) bisogni vitali immediati, secondo l’articolo 32 del Codice 1;

    b) risorse il cui TRU imminente comporti un concreto rischio di spreco, secondo l’articolo 6;

    c) bisogni produttivi indispensabili a mantenere la capacità produttiva necessaria;

    d) costituzione o reintegro delle riserve federate per eventi prevedibili.

3.  La gerarchia del comma 2 disciplina esclusivamente l’allocazione interna al Pool e non sostituisce la gerarchia generale delle attività stabilita dall’articolo 32 del Codice 1. In caso di conflitto prevale quest’ultimo. A parità di priorità, è preferito il percorso logistico che richiede minore energia, purché rispetti i tempi, la sicurezza e l’integrità della risorsa.

4.  Ogni proposta indica i dati utilizzati, le priorità applicate, le alternative considerate e gli eventuali margini di incertezza. Le proposte e le deliberazioni sono conservate per consentirne la verifica successiva.

### Art. 9 — Organi competenti e formazione delle decisioni

1.  Ai sensi dell’articolo 38 del Codice 1, l’Intelligenza Artificiale Gestionale è uno strumento di calcolo, ottimizzazione e proposta. Nessuna proposta di flusso diventa esecutiva senza una deliberazione dell’organo umano competente.

2.  Le funzioni sono ripartite come segue:

    a) **accertamento del Saldo Federabile**: Consiglio di Magazzino locale competente, ai sensi dell’articolo 3;

    b) **elaborazione delle proposte di flusso**: Intelligenza Artificiale Gestionale, sotto supervisione umana;

    c) **decisione di allocazione e trasferimento**: Consiglio di Magazzino del Cerchio 2 o del Cerchio 3, secondo l’articolo 9-bis, entro i criteri approvati dall’Assemblea Generale; le decisioni che eccedono i criteri spettano all’Assemblea Generale;

    d) **opposizione motivata al trasferimento**: Consiglio di Magazzino del Cerchio cedente, anche su richiesta dell’Assemblea, nei termini e per i motivi previsti dall’articolo 11;

    e) **verifica dell’opposizione**: Collegio di Riesame costituito ai sensi dell’articolo 17 del Codice 4 tra persone estranee ai Cerchi interessati.

3.  La deliberazione di trasferimento identifica la risorsa, la quantità, il termine, il percorso previsto e le misure necessarie per garantirne la consegna e l’integrità.

4.  L’organo deliberativo non può alterare i criteri tecnici di accertamento del saldo al di fuori delle procedure di verifica e impugnazione previste. Se emergono errori nei dati o nell’accertamento, la decisione è rinviata o ricalcolata secondo le procedure applicabili.

### Art. 9-bis — Consigli di Magazzino dei Cerchi 2 e 3

1.  In attuazione degli articoli 5.1, lettere c) e d), e 10.5 della Costituzione, ogni Cerchio 2 e ogni Cerchio 3 istituisce un Consiglio di Magazzino, che decide l’allocazione e il trasferimento delle risorse del Pool:

    a) il Consiglio del Cerchio 2 decide sui trasferimenti tra le Comunità di Base del proprio Bacino;

    b) il Consiglio del Cerchio 3 decide sui trasferimenti tra Cerchi 2 diversi compresi nel proprio ambito;

    c) i trasferimenti tra Cerchi 3 diversi sono decisi con deliberazioni concordi dei Consigli dei Cerchi 3 interessati.

2.  Il Consiglio è composto da cinque a sette persone con competenza validata nella gestione dei magazzini o nella logistica, sorteggiate tra le persone delle Comunità comprese nel Cerchio. Non più di due componenti appartengono alla stessa Comunità di Base o, per il Cerchio 3, allo stesso Cerchio 2. Si applicano i commi 4, 5, 8, 9 e 11 dell’articolo 12-bis del Codice 3. La revoca spetta all’Assemblea Generale del Cerchio o all’Assemblea della Comunità di provenienza, ai sensi dell’articolo 12-bis, comma 6-bis, lettera d), del Codice 3.

3.  Il Consiglio decide nel rispetto delle priorità dell’articolo 8 e dei criteri approvati ogni anno dall’Assemblea Generale del Cerchio ai sensi dell’articolo 14 del Codice 3, con il Dossier dell’articolo 33 della Costituzione. I criteri indicano almeno:

    a) l’applicazione delle priorità dell’articolo 8 alle risorse del Cerchio;

    b) la consistenza e i tempi di impiego della Riserva Federata;

    c) i criteri di scelta tra destinazioni di pari priorità;

    d) le quantità o i valori in UCR oltre i quali la decisione spetta all’Assemblea Generale.

4.  Le decisioni conformi ai criteri sono atti tecnici vincolati ai sensi dell’articolo 12-bis, comma 9, del Codice 3 e non richiedono un nuovo Dossier. Le decisioni che eccedono i criteri o i limiti della lettera d) del comma 3 spettano all’Assemblea Generale, che nei casi d’urgenza delibera ai sensi dell’articolo 14, comma 9, del Codice 3. Fino all’approvazione dei primi criteri, il Consiglio decide soltanto sui bisogni vitali immediati e sulle risorse a rischio di spreco, secondo l’articolo 8, comma 2, lettere a) e b).

5.  Il Consiglio decide sulle proposte di flusso entro quarantotto ore; sui bisogni vitali immediati senza ritardo e comunque entro ventiquattro ore; sulle risorse a rischio di spreco entro il termine dell’articolo 6. Se il Consiglio non decide in tempo su un bisogno vitale immediato, il Consiglio di Magazzino del Cerchio presso cui la risorsa è custodita può eseguire la proposta di flusso conforme all’articolo 8 e ai criteri; l’esecuzione è registrata e comunicata senza ritardo al Consiglio competente. Per le risorse a rischio di spreco si applica l’articolo 6, comma 2.

6.  Le decisioni sono comunicate ai Cerchi interessati. Restano ferme l’opposizione dell’articolo 11 e la verifica dell’articolo 9, comma 2, lettera e); ogni Comunità interessata può chiedere la stessa verifica contro una decisione di allocazione. La richiesta non sospende il trasferimento, salvo l’articolo 11, comma 3. Contro le decisioni di allocazione la verifica del presente comma sostituisce il ricorso dell’articolo 17, comma 1-bis, del Codice 3, che resta ammesso per i soli vizi di procedura e di competenza.

7.  Durante la transizione il Consiglio del Cerchio 2 è istituito nel Bacino e quello del Cerchio 3 nella Federazione minima, ai sensi dell’articolo 1, commi 5 e 6, del Codice 16.

### Art. 10 — Logistica federale

1.  Il trasporto inter-Cerchi e interregionale delle risorse del Paniere avviene ordinariamente tramite la rete ferroviaria federata prevista dall’articolo 11.2 della Costituzione, in quanto modalità a elevata capacità e a minore costo energetico, quando adeguata alla risorsa e compatibile con i tempi di consegna.
2.  Il trasporto dell’ultimo miglio, dalla stazione ferroviaria al Magazzino locale, è disciplinato dal Codice 1 e può avvalersi, secondo disponibilità e sicurezza, di cargo-bike, mezzi elettrici, trattori e carrelli.
3.  Ogni trasferimento è registrato indicando almeno la tipologia e la quantità della risorsa, il Cerchio di origine e quello di destinazione, l’energia impiegata e il CBO necessario. I dati pubblici non comprendono informazioni la cui divulgazione possa compromettere la sicurezza delle persone o delle infrastrutture; il dettaglio logistico è accessibile agli organi competenti.
4.  Le modalità di trasporto rispettano le Schede Sicurezza applicabili e i parametri dei Codici competenti in materia di salute, ambiente, territorio e risorsa trasportata.

### Art. 11 — Opposizione, trasparenza, divieto di ricatto e garanzia dei bisogni vitali

1.  Ogni proposta di prelievo dal Pool Mondiale è comunicata alle Assemblee e ai Consigli di Magazzino dei Cerchi interessati. Il Consiglio di Magazzino del Cerchio cedente, anche su richiesta dell’Assemblea, può presentare opposizione motivata entro settantadue ore dalla comunicazione, indicando:

    a) l’emergenza locale documentata;

    b) il rischio concreto che il trasferimento comprometta un bisogno vitale o una continuità tecnica essenziale;

    c) gli elementi che dimostrano un errore nell’accertamento o nella classificazione della risorsa;

    d) le eventuali alternative disponibili nel Pool.

2.  L’opposizione non costituisce un veto definitivo né può fondarsi su una preferenza politica o sulla volontà di trattenere un surplus. Essa attiva la verifica prevista dall’articolo 9, comma 2, lettera e), secondo le procedure del Codice 4.

3.  In attesa della verifica, il trasferimento può essere sospeso per il tempo strettamente necessario quando la documentazione presentata indichi un rischio concreto e immediato. La sospensione è motivata, limitata nel tempo e riesaminata con urgenza. Non può essere utilizzata per impedire indefinitamente l’allocazione di una risorsa federabile.

4.  La verifica considera la fondatezza dell’emergenza locale, l’accuratezza dei dati, la possibilità di sostituire la risorsa con un’altra disponibilità del Pool e gli effetti della sospensione sul bisogno destinatario. L’esito è motivato e comunicato ai Cerchi interessati.

5.  È vietato condizionare la cessione o il trasferimento di una risorsa appartenente al Pool all’ottenimento di un’altra utilità, di una decisione politica o di un vantaggio. Tale condotta costituisce ricatto relativo a risorse.

6.  In caso di ricatto accertato, le misure e le sanzioni sono applicate secondo il Codice 4 e incidono sulla responsabilità dell’organo o dei soggetti responsabili. Non possono determinare l’isolamento logistico del Cerchio né la sospensione o la limitazione dell’accesso dei suoi membri ai beni vitali.

7.  La trasparenza sui flussi è assicurata mediante registrazioni verificabili delle disponibilità, delle decisioni e dei trasferimenti, nel rispetto della sicurezza logistica, della protezione dei dati e delle competenze stabilite dai Codici 7 e 14.

## CAPO III — REGISTRO DIPENDENZE

### Art. 12 — Registro Dipendenze

1.  È istituito il Registro Dipendenze, registro federato delle dipendenze della Confederazione da beni, servizi, competenze, infrastrutture e funzioni ecologiche esterni o non sostituibili. È tenuto in ogni Cerchio 1 dal Consiglio di Magazzino ed è consolidato nei Cerchi 2 e 3 senza duplicazioni.

2.  Il Registro è alimentato dai Consigli secondo i Codici di settore e, per le dipendenze proprietarie, secondo l’articolo 5 del Codice 2. Ciascun Consiglio resta responsabile dei dati della propria materia.

3.  Per ogni dipendenza il Registro indica almeno:

    a) la descrizione e la categoria: materiale, tecnologica, logistica, energetica, idrica, di competenze, ecologica, territoriale o da soggetti esterni;

    b) la funzione e il livello del Paniere interessati;

    c) la classificazione ai sensi del comma 4;

    d) il responsabile e le misure di continuità.

4.  La dipendenza è critica quando la sua interruzione comprometterebbe il Paniere o una funzione dei livelli da 1 a 3 e non è disponibile un’alternativa entro la soglia temporale definita dalla STV applicabile. La dipendenza proprietaria critica assoluta resta vietata ai sensi dell’articolo 5 del Codice 2.

5.  Ogni dipendenza critica è accompagnata da un Piano di Uscita che indica l’obiettivo verificabile, il responsabile, le risorse, le misure intermedie e un termine finale certo. Il Piano è approvato dall’Assemblea su proposta del Consiglio competente. Se l’uscita non è tecnicamente possibile entro il termine, il Piano è riesaminato con motivazione; il riesame non può limitarsi a prorogare la dipendenza.

5-bis. Per le materie prime il Piano di Uscita indica riduzione del fabbisogno, riuso, riciclo e recupero. Non può indicare nuove estrazioni. Si applica il comma 5.

5-ter. **Dipendenze strutturali.** Una dipendenza critica è strutturale quando il bene, il componente o la competenza non possono essere prodotti o sostituiti, nel prevedibile futuro, a una scala raggiungibile dalla Confederazione, come accade per molti farmaci, componenti elettronici, metalli e batterie. La qualificazione è motivata nel Registro dal Consiglio competente, con il parere del Consiglio omologo di un’altra Comunità. Per la dipendenza strutturale il Piano di Uscita del comma 5 è sostituito da un Piano di Garanzia, che indica: a) le scorte di sicurezza; b) almeno due fonti di approvvigionamento indipendenti, quando esistono; c) le misure di riduzione del fabbisogno, di riuso e di riparazione; d) le alternative in sperimentazione e le competenze da formare; e) per ciascuna misura un responsabile e un termine certo. Il Piano di Garanzia è approvato dall’Assemblea ed è riesaminato almeno ogni ventiquattro mesi; a ogni riesame si verifica se la dipendenza è ancora strutturale o se può avere un Piano di Uscita. Si applica il comma 5-bis.

6.  Il Registro è pubblicato in forma aggregata. Le informazioni che espongono vulnerabilità delle infrastrutture sono accessibili secondo l’articolo 15 del Codice 3.

7.  **Dipendenze da persone.** Costituisce dipendenza critica di competenze la funzione dei livelli da 1 a 3, o l’amministrazione di un’infrastruttura critica, che meno di tre persone formate sono in grado di svolgere nel Cerchio 1 o, per le funzioni condivise, nel Cerchio 2. Il Piano di Uscita consiste nella formazione di altre persone secondo il Codice 5 e nella documentazione della funzione nel Magazzino del Sapere. Fino al suo completamento la funzione è assicurata anche mediante il reperimento federato e il tele-affiancamento dell’articolo 13.

### Art. 13 — Reperimento federato delle competenze e tele-affiancamento

1.  Quando una competenza L2 o L3 necessaria a una funzione dei livelli da 1 a 3 non è disponibile nel Cerchio, il Consiglio competente attiva il reperimento federato mediante richiesta in Rete al Cerchio 2 e, se necessario, al Cerchio 3. La risposta è data entro ventiquattro ore per le emergenze vitali ed entro settantadue ore negli altri casi.

2.  Il reperimento avviene, secondo il caso, mediante:

    a) l’invio della persona interessata al servizio competente;

    b) l’invio temporaneo della competenza al Cerchio richiedente;

    c) il tele-affiancamento supervisionato da una persona L3, quando è appropriato e sicuro.

3.  Il tempo prestato a favore di un altro Cerchio è computato nel CBO ai sensi dell’articolo 30 del Codice 1 e dell’articolo 7 del presente Codice.

4.  La carenza è iscritta nel Registro come dipendenza da competenze ed è accompagnata da un piano di formazione secondo il Codice 5.

5.  Fino a quando la competenza non è disponibile nella Confederazione, il ricorso a servizi esterni segue il Capo III del Codice 2.

### Art. 14 — Audit di autonomia

1.  Gli audit federati annuali previsti dai Codici di settore sono coordinati in un piano annuale di Cerchio 2. Le persone incaricate sono sorteggiate secondo l’articolo 36 del Codice 4.
2.  L’audit verifica la completezza del Registro, l’avanzamento dei Piani di Uscita e l’insorgere di nuove dipendenze. Il rapporto è pubblicato; il Cerchio interessato dispone di quindici giorni per presentare osservazioni. È ammesso ricorso al Cerchio di Garanzia secondo il Codice 4.
3.  Gli esiti degli audit rilevano ai fini delle soglie del Codice 16.

## CAPO IV — RAPPORTI ESTERNI NELLA FASE DI COESISTENZA

### Art. 15 — Ambito e principi

1.  Il presente Capo disciplina i rapporti dei Cerchi con le persone, gli enti, le imprese e le autorità esterni alla Confederazione, fino a quando essa non comprenda l’intera umanità.

2.  I rapporti esterni si fondano sui principi seguenti:

    a) legalità: sono rispettati l’ordinamento vigente nel territorio e gli obblighi fiscali e contrattuali;

    b) non violenza e cooperazione: chi non aderisce non è trattato come avversario;

    c) trasparenza e tracciabilità;

    d) riduzione progressiva delle dipendenze;

    e) divieto di rendita e di profitto.

3.  Gli scambi con l’esterno servono esclusivamente a soddisfare i bisogni non ancora coperti dall’autoproduzione federata e a cedere eccedenze reali. Sono eccedenze reali i beni eccedenti che non sono destinati al Pool ai sensi dell’articolo 15, comma 1-bis, del Codice 1. È vietata l’esportazione a fini di profitto, ai sensi dell’articolo 11.1 della Costituzione.

### Art. 16 — Soggettività giuridica e titolarità dei beni

1.  Durante la coesistenza ogni Cerchio opera attraverso un ente senza scopo di lucro riconosciuto dall’ordinamento locale, individuato con il parere di un professionista legale. Lo statuto recepisce, nei limiti consentiti dalla legge, i principi della Costituzione: indivisibilità del patrimonio, divieto di distribuzione di utili, voto individuale e rotazione degli incarichi.
2.  La terra, gli edifici e gli impianti conferiti o acquisiti sono intestati all’ente con vincoli statutari di inalienabilità, indivisibilità e destinazione. In caso di scioglimento il patrimonio è devoluto a un altro Cerchio o a un ente con le medesime finalità.
3.  Gli incarichi che la legge impone all’ente sono conferiti per sorteggio e ruotano con la frequenza massima consentita. Chi li ricopre è vincolato alle deliberazioni dell’Assemblea e non acquisisce poteri ulteriori.
4.  Il conferimento di beni da parte delle persone è volontario e documentato. L’atto indica se il conferimento è definitivo o in uso temporaneo. I beni in uso temporaneo restano iscritti nell’inventario provvisorio dell’articolo 6 del Codice 16 e sono restituiti in caso di recesso anteriore al trasferimento al regime definitivo.

### Art. 17 — Cassa comune e mezzi di pagamento esterni

1.  I mezzi di pagamento esterni sono detenuti esclusivamente dalla Cassa comune dell’ente, ai sensi dell’articolo 3.5-bis della Costituzione. La Cassa ha una contabilità separata, pubblicata in forma aggregata. Non circola tra i membri e non dà accesso ai Magazzini.
2.  La Cassa è alimentata dal contributo proporzionale previsto dall’articolo 19-bis, da contributi volontari dei membri, dalla cessione di eccedenze reali e di beni obsoleti ai sensi dell’articolo 15 del Codice 1, da donazioni prive di condizioni e dalle prestazioni verso l’esterno deliberate dall’Assemblea.
3.  La Cassa è impiegata per gli acquisti residuali di beni necessari non autoproducibili, per i servizi esterni ammessi secondo il Codice 2, per gli obblighi fiscali e legali, per la tutela legale, per il sostegno all’avvio della vita autonoma di chi lascia la Confederazione ai sensi dell’articolo 49, comma 6, del Codice 1, per le spese della transizione e, durante la transizione, per l’estinzione di debiti dei membri verso terzi, con pagamento diretto al creditore e secondo regole pubbliche uguali per tutti. Le decisioni seguono la matrice dell’articolo 7 del Codice 3.
4.  Nessun membro riceve denaro dalla Cassa come corrispettivo del proprio contributo; è ammesso il rimborso delle spese documentate. I redditi esterni delle persone restano nella loro disponibilità, alle condizioni dell’articolo 19-bis. Nessuno può essere escluso dal Paniere per non aver contribuito alla Cassa.
5.  La Cassa non può essere impiegata per investimenti speculativi né per generare rendita. La riserva non supera il fabbisogno documentato di dodici mesi di spese esterne necessarie; l’eccedenza è destinata ai Piani di Uscita o al mutualismo tra Cerchi.
6.  I trasferimenti tra Casse di Cerchi diversi avvengono soltanto come mutualismo, senza interessi e senza obbligo di restituzione. È vietato contrarre debiti finanziari che determinino una dipendenza critica.

### Art. 18 — Fornitori, acquisti e pratiche commerciali

1.  Nel soddisfare un fabbisogno che richiede il ricorso all’esterno è seguito, di norma, il seguente ordine di preferenza:

    a) altri Cerchi della Confederazione;

    b) cooperative, enti non lucrativi e soggetti dell’economia sociale;

    c) imprese locali;

    d) altri fornitori.

2.  La compatibilità del rapporto con il fornitore è valutata separatamente dalla conformità tecnica del bene o del servizio, disciplinata dal Codice 2. La valutazione considera almeno:

    a) il rispetto dei diritti di chi lavora e l’assenza di sfruttamento;

    b) l’impatto ecologico e il trattamento degli animali;

    c) le pratiche ingannevoli e la creazione artificiale di dipendenze;

    d) la trasparenza delle condizioni.

3.  I contratti sono stipulati in forma scritta, prevedono clausole di uscita e non possono contenere esclusive o penali che determinino una dipendenza. Sono approvati secondo la matrice dell’articolo 7 del Codice 3.

4.  L’esclusione di un singolo fornitore spetta agli organi competenti secondo i Codici 2 e 3; l’esclusione di categoria per principio spetta all’Assemblea Generale.

5.  È tenuto un registro pubblico dei fornitori e dei contratti in corso, nel rispetto dei livelli di trasparenza del Codice 3.

### Art. 19 — Prestazioni verso l’esterno e attività esterne dei membri

1.  I Cerchi possono cedere all’esterno eccedenze reali e prestare servizi, senza fine di profitto. Il ricavato è versato alla Cassa comune.
2.  È vietato organizzare la produzione in funzione del mercato esterno. La quota di CBO destinata a produzioni per l’esterno è deliberata dall’Assemblea e non supera la misura necessaria a coprire gli acquisti esterni necessari.
3.  Le attività lavorative esterne svolte dalle persone durante la coesistenza sono libere e non costituiscono CBO, salvo il lavoro nelle filiere essenziali che il Cerchio computa nel CBO durante la coesistenza, alle condizioni dell’articolo 16, comma 2, lettera d), del Codice 16. Nessuno può essere indotto ad abbandonarle.
4.  La condivisione con l’esterno di STV, Schede, saperi e sementi libere è promossa ed è effettuata con licenze libere.

### Art. 19-bis — Redditi e patrimoni esterni delle persone

1.  **Natura transitoria.** Sono redditi esterni i compensi, le pensioni, i sussidi, le rendite e ogni altra entrata che una persona percepisce da soggetti esterni alla Confederazione. Esistono soltanto finché esistono soggetti esterni e mezzi di pagamento esterni, ai sensi dell’articolo 3.5-ter della Costituzione. Restano nella disponibilità della persona.

2.  **Neutralità interna.** I redditi e i patrimoni esterni non attribuiscono alcun vantaggio nell’accesso al Paniere, ai Magazzini, ai beni comuni, al CdR, agli incarichi o alle decisioni. Tra i membri è vietato impiegarli per:

    a) acquistare beni o servizi che i Codici assegnano secondo il bisogno;

    b) retribuire il lavoro di un altro membro o far svolgere ad altri il proprio CBO;

    c) concedere prestiti a interesse o costituire rendite;

    d) ottenere consenso, voti o incarichi.

3.  **Contributo proporzionale.** Chi percepisce redditi esterni e fruisce del Paniere contribuisce alla Cassa comune in proporzione al reddito, perché le spese esterne sostenute dalla Cassa giovano a tutti. La misura è deliberata ogni anno dall’Assemblea a maggioranza qualificata ed è uguale per tutti. In prima applicazione è pari a un decimo del reddito esterno, al netto delle imposte e degli obblighi legali verso terzi, e non può superare un quinto. Il contributo riguarda i redditi, non i patrimoni.

4.  **Garanzie.** Il mancato versamento non comporta l’esclusione dal Paniere né la sospensione dei diritti dell’articolo 1.2 della Costituzione. È trattato come inosservanza di una regola comune secondo il Codice 4, preferendo la mediazione e la rimodulazione.

5.  **Riservatezza e trasparenza.** La persona dichiara ogni anno al Consiglio Contabilità, in forma riservata, la fascia in cui ricade il proprio reddito esterno. Sono pubblicati soltanto dati aggregati per Cerchio: numero di persone per fascia e totale dei contributi. La dichiarazione è conservata per dodici mesi ed è vietato ogni uso diverso dal calcolo del contributo, in conformità al Codice 7, articolo 2.2.

6.  **Pari accesso alle spese esterne.** Una quota della Cassa, deliberata dall’Assemblea, garantisce a chi non ha redditi esterni le spese esterne necessarie, comprese quelle per documenti, obblighi legali, cure non disponibili nella Confederazione e viaggi per motivi familiari o sanitari.

7.  **Patrimoni esterni.** I beni che una persona possiede fuori dalla Confederazione restano suoi secondo l’ordinamento vigente. Non possono essere dati in affitto o in uso oneroso ad altri membri né impiegati per assumere membri. Il conferimento all’ente previsto dall’articolo 16 è volontario, non attribuisce privilegi e rende il bene un Bene Comune.

8.  **Riduzione e cessazione.** I Piani di Uscita riducono progressivamente il bisogno di redditi esterni. Il presente articolo cessa di applicarsi quando la Confederazione comprende l’intera umanità: da quel momento non esistono redditi esterni e le Casse comuni sono chiuse. Fino ad allora la facoltà dell’articolo 2, comma 9, del Codice 16 continua ad applicarsi anche dopo la chiusura della transizione.

### Art. 20 — Autonomia strategica, ricatto relativo a risorse e contromisure

1.  Per ogni bene o servizio necessario privo di alternativa interna sono previsti una scorta di sicurezza ai sensi dell’articolo 16 del Codice 1, la pluralità dei fornitori quando è possibile e un Piano di Uscita.
2.  Si ha ricatto esterno relativo a risorse quando un soggetto esterno subordina la fornitura di un bene o servizio necessario a una decisione dei Cerchi o a un vantaggio indebito, o ne minaccia l’interruzione a tale scopo.
3.  Le contromisure sono esclusivamente lecite e non violente: attivazione del Pool e del mutualismo federato, sostituzione accelerata, cessazione del rapporto, pubblicità dei fatti, tutela legale e ricorso alle autorità competenti. Sono vietate le ritorsioni sulle persone e il danneggiamento.
4.  In caso di aggressione si applica la difesa civile non violenta prevista dall’articolo 16.4 della Costituzione e dall’articolo 8-ter del Codice 14, nei limiti della legge vigente ai sensi dell’articolo 15, comma 2, lettera a); è escluso il sabotaggio, come nell’articolo 11, comma 2, lettera c), del Codice 16.

### Art. 21 — Adesione di comunità esterne e recesso

1.  La comunità esterna che chiede l’adesione ai sensi dell’articolo 4.5 della Costituzione sottoscrive la Costituzione e sceglie se aderire come Comunità associata, ai sensi dell’articolo 21-bis, o adottando anche i Codici. Nel secondo caso applica il Codice 16 secondo l’articolo 3, comma 7, del medesimo Codice.
2.  Il Cerchio 2 di riferimento verifica esclusivamente i protocolli di interoperabilità tecnologica e logistica e, per la Comunità associata, l’equivalenza al confine dell’articolo 21-bis e il rispetto delle regole fondamentali che essa dichiara ai sensi del comma 6 di quell’articolo. La verifica è conclusa entro novanta giorni e non può introdurre valutazioni politiche o ideologiche ulteriori.
3.  Il recesso di un Cerchio 1 segue gli articoli 4.6 e 4.7 della Costituzione. Le modalità tecniche sono concordate con il Cerchio 2 in modo da garantire la continuità del Paniere per tutte le persone interessate.

### Art. 21-bis — Comunità associate ed equivalenza al confine

1.  **Regole fondamentali e strumenti.** Ai sensi dell’articolo 4.5 della Costituzione, sono regole fondamentali, obbligatorie per ogni Comunità, i Titoli I, IV, V e VII della Costituzione, gli articoli 19.1, 21, 30.1, 30.2 e 36.1 e il Nucleo Inviolabile dell’articolo 37.4. La Comunità associata è una Comunità di Base ai fini della Costituzione e dei Codici, salvo quanto stabilito dal presente articolo. Le regole di gestione dei Codici, tra cui il CBO e il CdR, i Magazzini, gli organi e i Consigli interni e le forme dei loro sorteggi, le assemblee e i quorum interni, la giustizia del Codice 4 per i conflitti interni e le fasi del Codice 16, sono strumenti. La Comunità associata conserva il proprio ordinamento interno se rispetta le regole fondamentali e garantisce l’equivalenza al confine del comma 2. Restano fermi anche nella vita interna i principi del Nucleo Inviolabile, tra cui il contributo di ogni persona adulta abile dell’articolo 2.3, il sorteggio, la rotazione e il divieto di esercizio professionale e permanente della politica e della funzione giudiziaria degli articoli 4.3, 4.4, 6.5 e 31.2 e i divieti dell’articolo 36.1 della Costituzione. Vale anche nelle decisioni interne il diritto di voto e deliberazione di ogni membro dal compimento del quattordicesimo anno, ai sensi degli articoli 26.2 e 36.1 della Costituzione.

2.  **Equivalenza al confine.** La Comunità associata garantisce al confine con i Cerchi 2 e 3:

    a) a ogni membro i diritti dell’articolo 1.2 della Costituzione, compresi i livelli 1 e 2 del Paniere e le cure, e a chiunque vi si trovi le garanzie dell’articolo 1.3; il diritto di lasciare la Comunità e la Confederazione ai sensi degli articoli 4.8 e 5.2 della Costituzione; il ricorso agli organi comuni di garanzia del comma 5 per chi afferma che un proprio diritto è stato violato;

    b) l’inventario delle risorse e la dichiarazione trimestrale del Saldo nel formato comune degli articoli 2 e 3; l’accertamento dell’articolo 3, comma 3, è svolto dall’organo indicato dal suo ordinamento interno ed è verificato dal Consiglio di Magazzino del Cerchio 2. Usare il Pool è facoltativo: in deroga all’articolo 3, commi 5 e 6, e all’articolo 15, comma 1-bis, del Codice 1, il Saldo Federabile accertato della Comunità entra nel Pool soltanto se essa usa il Pool ai sensi del comma 3. Anche se non lo usa, la parte del suo Saldo Federabile accertato fatta di alimenti, acqua e beni per le cure è messa a disposizione del Pool quando un’altra Comunità ha un deficit accertato di bisogni vitali immediati, secondo le priorità dell’articolo 8, comma 2, lettera a), e la Comunità riceve dal Pool, alle stesse condizioni, la copertura dei propri deficit di bisogni vitali immediati;

    c) una quota di lavoro per le funzioni comuni dei Cerchi 2 e 3 e per la quota federata dell’articolo 7, determinata per l’intera Comunità e non per persona, con gli stessi criteri usati per le altre Comunità; la Comunità la ripartisce al proprio interno secondo il proprio ordinamento. Durante la transizione la quota può essere resa anche in beni; il versamento alla Cassa comune del Cerchio 2 per spese esterne comuni è ammesso come mutualismo ai sensi dell’articolo 17, comma 6, e non sostituisce la quota di lavoro;

    d) persone nelle liste di sorteggio degli organi comuni dei Cerchi 2 e 3, alle stesse condizioni delle altre Comunità;

    e) il voto individuale e segreto di ogni membro nelle Assemblee Generali, senza delega, ai sensi degli articoli 34.4 e 36.1 della Costituzione;

    f) gli standard comuni dei beni che scambia con le altre Comunità, compresa la STV del Codice 2;

    g) il transito e l’ospitalità dei membri delle altre Comunità, nei limiti della capacità di carico, secondo il proprio ordinamento e con almeno l’area di sosta attrezzata dell’articolo 12.1 della Costituzione.

3.  **Strumenti comuni e strumenti adottati.** Quando la Comunità associata usa uno strumento comune, come il Pool, lo scambio tra Magazzini o la Rete federata, ne segue le regole. Può adottare in ogni momento singoli strumenti dei Codici, con deliberazione presa secondo il proprio ordinamento e comunicata al Cerchio 2; da quel momento ne applica le regole. Lo strumento adottato può essere lasciato con lo stesso procedimento, con un preavviso di novanta giorni e senza pregiudizio per le procedure in corso. Una Comunità che applica i Codici può diventare associata soltanto con la maggioranza dell’articolo 4.6 della Costituzione e dopo la verifica del comma 6; chi non è d’accordo può trasferirsi con le garanzie dell’articolo 5.2 della Costituzione.

4.  **Rinvio dei Codici.** Per la Comunità associata:

    a) le disposizioni dei Codici che regolano strumenti di gestione interna si applicano soltanto se e da quando li adotta;

    b) le disposizioni della Costituzione e dei Codici che attuano le regole fondamentali valgono per i diritti, i divieti e i limiti che stabiliscono; gli organi e le procedure interni con cui esse li attuano possono essere sostituiti da organi e procedure del suo ordinamento interno che ottengono lo stesso risultato, fermo il comma 5;

    c) i riferimenti della Costituzione e dei Codici al CBO, ai Magazzini, agli organi e alle assemblee del Cerchio 1, per la vita interna, si intendono fatti agli istituti corrispondenti del suo ordinamento interno; se l’istituto corrispondente manca, si applica l’organo del Cerchio 2 o un organo condiviso. Il contributo di lavoro che l’ordinamento interno chiede a ogni persona adulta abile vale come CBO ai fini degli articoli 2.3 e 4.4 della Costituzione; ai fini dell’articolo 7.3-bis vale soltanto entro il limite dell’articolo 3 del Codice 1 e con le giustificazioni dell’articolo 29, comma 3, del Codice 4;

    d) gli obblighi che i Codici pongono ai membri come tali, compresi il CBO del Codice 1 e la giustizia del Codice 4 per i conflitti interni, valgono per i membri delle Comunità che adottano i Codici, salvo il comma 5; ai membri della Comunità associata si applicano le regole fondamentali, i diritti delle persone e le regole degli strumenti comuni che usano;

    e) nel dubbio se una disposizione regoli uno strumento di gestione o attui le regole fondamentali, la disposizione che tutela una persona o un limite ecologico si considera attuazione delle regole fondamentali; la questione può essere sottoposta da chiunque vi abbia interesse al collegio del comma 5, lettera d).

5.  **Conflitti, garanzie e ricorsi.** Per la Comunità associata:

    a) gli illeciti di Grado 4, 5 e 6 commessi nella Comunità associata sono sempre di competenza del Tribunale di Garanzia, secondo il Codice 4 e fermo il suo articolo 37. La segnalazione di un fatto che può costituire illecito di Grado 4, 5 o 6 è trasmessa senza ritardo dall’organo interno, o presentata direttamente da chiunque, al Cerchio di Garanzia di un’altra Comunità del Cerchio 2, sorteggiato per il caso, che ne qualifica il grado ai sensi dell’articolo 28 del Codice 4; l’ordinamento interno non può trattenerla. Finché non esiste un Cerchio 2, si applica l’articolo 37, comma 5, del Codice 4;

    b) la comunicazione dell’articolo 8-sexies, comma 10, del Codice 14 è fatta all’organo interno equivalente e, in copia, al Cerchio di Garanzia sorteggiato ai sensi della lettera a), che svolge le funzioni dell’articolo 26-bis, comma 5, lettere a)–c), e comma 6, del Codice 4; l’eccesso di Grado 1 o 2 accertato è rimesso all’ordinamento interno;

    c) gli altri conflitti interni sono risolti secondo l’ordinamento interno; il rifiuto del contributo di lavoro che può condurre alle misure dell’articolo 7.3-bis della Costituzione è trattato dagli organi degli articoli 27, 28 e 29, commi 4-bis e 6-bis, del Codice 4, a partire dalla segnalazione del comma 4-bis, lettera a), dell’articolo 29; la sospensione del CdR del comma 4-bis, lettera c), si applica soltanto se la Comunità ha adottato il CdR. I conflitti con altre Comunità seguono il Codice 4, con la mediazione del Cerchio 2 prevista dall’articolo 5.1, lettera c), della Costituzione;

    d) chi afferma che un proprio diritto è stato violato nella Comunità associata può ricorrere, con le regole dell’articolo 17 del Codice 3, a tre componenti sorteggiati tra i componenti dei Cerchi di Garanzia di altre Comunità, appartenenti a Comunità diverse; si applicano gli articoli 15 e 37, comma 5, del Codice 4. Il ricorso è ammesso in ogni momento finché la violazione dura; il collegio può annullare l’atto interno e ordinare la misura necessaria a ristabilire il diritto; se la Comunità non la esegue, il Cerchio 2 assicura il diritto alla persona, anche con la ricollocazione;

    e) la valutazione dell’autonomia prevista dall’articolo 26.2 e il percorso di protezione dell’articolo 26.3 della Costituzione e le funzioni degli articoli 7-bis e 7-ter del Codice 12 sono svolti dal Consiglio Cura di un’altra Comunità del Cerchio 2 o da un Consiglio Cura condiviso o, fino all’attivazione del Codice 12, dal Consiglio Salute di un’altra Comunità, ai sensi dell’articolo 3, comma 1, lettera f), del Codice 16 e, per la valutazione dell’autonomia, dal Consiglio delle Competenze della stessa Comunità o da quello condiviso, al quale chiunque può segnalare un caso; la separazione del minore segue l’articolo 7-bis, comma 3, del Codice 12, ed è disposta dal Cerchio di Garanzia sorteggiato ai sensi della lettera a), con la convalida del Tribunale di Garanzia; durante la transizione si applica l’articolo 7-bis, comma 3-ter, del Codice 12;

    f) le misure degli articoli 1.3-bis e 7.3-bis della Costituzione e ogni misura che limita la libertà personale sono adottate soltanto dagli organi comuni, secondo il Codice 4; le misure urgenti dell’articolo 34, comma 1, del Codice 4 possono essere disposte dall’organo interno o dal Corpo di Tutela Civica e sono convalidate dal Tribunale di Garanzia entro ventiquattro ore, ai sensi del comma 2 dello stesso articolo. L’organo interno che svolge le funzioni del Corpo di Tutela Civica è soggetto agli articoli 8-ter, 8-quater e 8-quinquies del Codice 14; il suo ingresso in un Cerchio 0 è convalidato dal Tribunale di Garanzia ai sensi dell’articolo 8-ter, comma 3, di quel Codice;

    g) l’ordinamento interno non può privare un membro dell’alloggio, del Paniere o delle cure né escluderlo dalla Comunità; l’allontanamento è disposto soltanto dagli organi comuni nei casi del Codice 4. Se la convivenza non è più possibile, la Comunità e la persona concordano con il Cerchio 2 la ricollocazione, con il CBO ponte e la dotazione di Casa Ponte dell’articolo 49 del Codice 1.

6.  **Verifica e Piano di raccordo.** La comunità che chiede di aderire come Comunità associata descrive il proprio ordinamento interno per quanto serve a mostrare come garantisce il comma 2 e dichiara come rispetta le regole fondamentali. Il Cerchio 2 di riferimento, e durante la transizione il Consiglio Transizione dell’unità che la accoglie ai sensi dell’articolo 3, comma 7, lettera c), del Codice 16, verifica soltanto l’equivalenza al confine e il rispetto delle regole fondamentali, entro novanta giorni e senza valutazioni politiche o ideologiche, ai sensi dell’articolo 21, comma 2. Finché non esiste un Bacino che la accoglie, la verifica è svolta da tre persone sorteggiate dall’elenco dell’articolo 37, comma 5, del Codice 4, appartenenti a Cerchi pilota o a enti affini diversi, con gli stessi limiti. L’esito è motivato e pubblicato. Se un elemento manca, chi svolge la verifica e la comunità concordano un Piano di raccordo con tempi definiti, che cambia soltanto ciò che serve al confine e, nella vita interna, soltanto ciò che non rispetta le regole fondamentali; il resto della vita interna non è toccato. Il Piano non può essere imposto: finché l’equivalenza e il rispetto delle regole fondamentali non sono raggiunti, la comunità resta esterna e può collegarsi alla Confederazione con accordi ai sensi del Capo IV, senza adesione. Finché non esiste un Bacino che la accoglie, le funzioni che il presente articolo e l’articolo 8-bis, comma 1, del Codice 14 attribuiscono al Cerchio 2 e ai suoi organi sono svolte dalla deliberazione congiunta dei Cerchi pilota e delle Comunità associate che la verifica ha coinvolto, ai sensi dell’articolo 14, comma 10, del Codice 3, e dai collegi dell’articolo 37, comma 5, del Codice 4.

7.  **Dopo l’adesione.** Se un elemento del comma 2 viene meno o una regola fondamentale non è più rispettata, il Cerchio 2 lo segnala e si concorda un Piano di raccordo con le regole del comma 6. Se il Piano non è concordato o non è attuato nei tempi, l’Assemblea Generale del Cerchio 2 può dichiarare cessata l’associazione, con le garanzie dell’articolo 4.7, lettera c), della Costituzione per le persone. Restano sempre applicabili i diritti delle persone e i ricorsi del comma 5.

8.  **Persone che non aderiscono.** Le persone che vivono stabilmente nella Comunità associata senza aderire personalmente non sono membri: non votano nelle Assemblee Generali e non entrano nelle liste di sorteggio degli organi comuni. Possono restarvi secondo l’ordinamento interno, alle condizioni del comma 9, oppure chiedere il Patto di Convivenza Autonoma, che può essere concordato anche con la Comunità associata, ai sensi dell’articolo 4.9, lettera c), della Costituzione. Si applicano loro le garanzie e le regole degli articoli 1.3, 4.9, 4.9-bis e 4.9-ter della Costituzione, salvo quanto previsto dal comma 9 per chi è accolto dall’ordinamento interno.

9.  **Conviventi accolti dall’ordinamento interno.** In attuazione dell’articolo 4.5 della Costituzione, alla persona che vive stabilmente nella Comunità associata senza aderire non si applicano, finché l’ordinamento interno la accoglie, il limite dell’articolo 4.9, lettera b), e l’articolo 4.9-ter della Costituzione. Valgono per lei le regole seguenti:

    a) è a carico della Comunità che la ospita: non preleva dai Magazzini delle altre Comunità e dei Cerchi 2 e 3 né dal Pool, neppure tramite la copertura dei deficit prevista dal comma 2, lettera b), salvo l’acqua potabile, le cure d’emergenza salvavita e l’energia essenziale garantite a chiunque dagli articoli 1.3 e 15.2 della Costituzione, e non riceve CdR; per il resto le sue necessità non entrano nel Bisogno Reale Validato con cui si accerta il deficit; ciò che riceve dalla Comunità che la ospita, anche dal suo Magazzino, è a carico di questa;

    b) la quota di lavoro del comma 2, lettera c), è determinata contando tutte le persone che vivono stabilmente nella Comunità, membri e non membri;

    c) non vota nelle Assemblee Generali e non entra nelle liste di sorteggio degli organi comuni, ai sensi del comma 8;

    d) conserva le garanzie dell’articolo 1.3 della Costituzione e il ricorso agli organi comuni del comma 5, lettera d); ogni lavoro che svolge per la Comunità è volontario e non può essere preteso;

    e) può aderire in qualsiasi momento ed è informata per iscritto dalla Comunità, ogni anno, di questo diritto;

    f) se le persone accolte senza aderire sono più dei membri, il Cerchio 2 di riferimento, o chi svolge la verifica ai sensi del comma 6, verifica ogni anno che non vi sia sfruttamento; se lo accerta, si applicano il comma 5, lettera d), e il comma 7;

    g) ai suoi figli minori si applicano l’articolo 4.9-bis, ultimo periodo, della Costituzione e l’articolo 4-bis, comma 2, lettera f), del Codice 10; la lettera a) non esclude, per i minori, la copertura dei deficit di bisogni vitali immediati prevista dal comma 2, lettera b).
