#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Primo bilancio delle ore di una Comunità tipo.

Rifà i conti della bozza dell'Allegato Tecnico UCR (bozze/allegato-ucr.md).
Ogni numero è un'ipotesi dichiarata: per provarne un'altra basta cambiarla qui sotto e rieseguire

    python3 strumenti/bilancio_ore.py

Le fonti di ogni valore sono elencate nella bozza. Dove non c'è una fonte, il valore è segnato «ipotesi».
Il conto vale a regime, con le regole in vigore il 27 ottobre 2026. La tabella del CdR (strumenti/simula_cdr.py)
usa il CBO stimato da questo programma.
"""

# ------------------------------------------------------------------ popolazione
PERSONE = 150

# Struttura per età dell'UE al 1° gennaio 2024 (Eurostat, demo_pjanind), in percentuale
ETA = {"0-17": 17.8, "70-74": 5.3, "75+": 10.2}
ETA["18-69"] = 100 - sum(ETA.values())
SOTTO_3 = 2.57           # bambini sotto i tre anni, % della popolazione (Eurostat, demo_pjan)
SOTTO_1 = 0.806          # nati nell'anno, % della popolazione (Eurostat, demo_pjan)
GENITORI_PER_BAMBINO = 1.8    # ipotesi: qualche bambino ha fratelli sotto i tre anni o un solo genitore
ALTRE_RIDUZIONI = 0.05   # ipotesi: disabilità grave, caregiver, malattia, riduzione modulata per gravidanza, lutto
                         # e crisi (Cod. 1, art. 11, c. 1, lett. a, b, c ed e)
DICIOTTENNI = 1.1        # ipotesi: una leva annuale, circa l'1,1% della popolazione. Chi cresce nella Confederazione ha il
                         # CBO volontario fino alla scelta della Cost. 26.4, cioè fino a dodici mesi dopo i 18 anni
                         # (Cod. 5, art. 6, c. 6): non è contato tra i contributori
QUOTA_ESSENZIALI = 0.10  # ipotesi, solo per la transizione: quota dei contributori che lavora fuori in una filiera
                         # essenziale e se la vede computare nel CBO (Cod. 16, art. 16, c. 2, lett. d; Cod. 15, art. 19, c. 3)

LIMITE_ORE = 15          # Cod. 1, art. 3
SETTIMANE = 52

# ------------------------------------------------------------------ economia esterna (UE, 2024)
ORE_UE = 353_652.743e6   # ore lavorate nell'UE (Eurostat, nama_10_a10_e)
ABITANTI_UE = 449_306_184
PIL_UE = 18_043_409.9e6  # euro correnti (Eurostat, nama_10_gdp)
OCCUPATI_UE = 219_422.70e3
QUOTE_ORE = {            # % delle ore lavorate nell'UE (Eurostat, nama_10_a10_e e nama_10_a64_e)
    "agricoltura": 4.6, "industria alimentare": 2.26, "ristorazione e alloggio": 5.12,
    "manifattura": 14.3, "energia, acqua, rifiuti": 1.42, "costruzioni": 7.5,
    "trasporti e magazzini": 5.59, "sanità": 5.80, "assistenza sociale": 3.82, "istruzione": 5.74,
}

# ------------------------------------------------------------------ Paniere Alimentare (bozza del Paniere)
GRAMMI = {"cereali": 275, "legumi": 100, "frutta secca": 75, "ortaggi": 300, "frutta": 200,
          "tuberi": 50, "olio": 40}
PERDITE = 0.15           # ipotesi: perdite, scarti e semente
DIVARIO_BIO = 0.20       # rese senza chimica di sintesi: -19,2% (Ponisio e altri, 2015)
RESA = {                 # t/ha, Italia 2024 (FAO, da Our World in Data)
    "cereali": 3.66, "legumi": 2.08, "tuberi": 28.78, "ortaggi": 32.17, "frutta": 15.45,
    "frutta secca": 1.33 * 0.47,     # nocciole in guscio per resa in sgusciato (46-48%); il 2024 è un anno di crisi
                                     # del raccolto italiano: in un anno normale la resa in guscio è più alta
    "olio": 2.61 * 0.40,             # girasole per resa in olio (circa 40%)
}
ORE_ETTARO = {           # ore per ettaro all'anno, dalle tabelle regionali italiane (Lazio 2008, Sardegna 2019, Sicilia 2024).
                         # Ortaggi 700: valore prudente, al limite alto (Sardegna 719, Sicilia 334-467). Girasole 24, come
                         # nella tabella del Lazio. Non è applicato l'aumento per il biologico (+5% nella tabella siciliana).
    "cereali": 45, "legumi": 80, "tuberi": 300, "ortaggi": 700, "frutta": 530,
    "frutta secca": 300, "olio": 24,
}
ORE_TRASFORMAZIONE = 1800    # ipotesi: mulino 230, forno 640 (metà dei cereali in pane), frantoio e conserve 930
PASTI_AL_GIORNO = 1          # ipotesi: un pasto collettivo per persona al giorno
PASTI_PER_ORA = 12           # da 10 a 18 pasti per ora di lavoro, 16-20 nelle mense scolastiche (Sherrin e altri, 2009)

# ------------------------------------------------------------------ altre voci
FATTORE_PICCOLA_SCALA = 2    # ipotesi: energia e acqua costano il doppio delle ore della media UE
SANITARI_PER_1000 = 4.45     # soglia OMS: medici, infermieri, ostetriche
ADDETTI_CURA_PER_100_ANZIANI = 5     # media OCSE: conta persone, non ore, e comprende paesi dove gran parte della cura
                                     # resta alle famiglie; con il livello scandinavo (12) la voce più che raddoppierebbe
ANZIANI = 21.6               # % di popolazione con 65 anni o più
ORE_NIDO = 40 * 48           # ipotesi: 40 ore a settimana per 48 settimane, un adulto ogni cinque bambini
ALUNNI_PER_INSEGNANTE = 12.2 # UE, primaria e secondaria (Eurostat)
QUOTA_MANUTENZIONE = 0.5     # ipotesi: metà delle ore delle costruzioni è manutenzione
ORE_LOGISTICA = (6 + 1) * 365        # ipotesi: un turno di 6 ore al Magazzino e un'ora di consegne al giorno
BUCATO_KG = 80               # per persona all'anno (Millward-Hopkins e altri, 2020)
BUCATO_KG_ORA = 25           # 19-26 kg per ora di lavoro (FMLink, «Benchmarking laundry», 2019: da 42 a 57 libbre);
                             # TRSA 2023: da 25 a 36 kg
ORE_PULIZIE = 2 * 365        # ipotesi: spazi comuni
ORE_RETE = 8 * 52            # ipotesi
ORE_SANTUARI = 10 * 52       # ipotesi: santuari animali e riparazione ambientale
QUOTA_CIVICA = 0.10          # tetto del tempo amministrativo: Consigli, garanzia, facilitazione, contabilità e
                             # documentazione obbligatoria (Cod. 3, art. 12-bis, c. 13), usato come stima
ORE_TUTELA = 2 * 365         # ipotesi minima: turni del Corpo di Tutela Civica e altre funzioni della Lista D che non
                             # rientrano nel decimo; si contano a parte (Cod. 1, art. 2, c. 7, lett. e)
ORE_BACINO_PER_PERSONA = 5   # ipotesi minima: ore all'anno per abitante per le funzioni comuni dei Cerchi 2 e 3 e per
                             # la quota federata del Pool, che valgono come CBO (Cod. 15, art. 7, c. 3; art. 21-bis, c. 2, lett. c)

# ------------------------------------------------------------------ alloggio e Rete
M2_ALLOGGIO = 22             # ipotesi: superficie media a persona con le misure del Cod. 1, art. 47-bis, c. 2,
                             # se i Cerchi 0 sono come le famiglie italiane di oggi
M2_ALLOGGIO_CONFRONTO = 15   # il valore della prima versione della bozza (Millward-Hopkins e altri, 2020), per confronto
M2_COMUNI = 5                # ipotesi: edifici comuni a persona
CASE_PONTE = 0.125           # Case Ponte: dal 10 al 15% dell'abitato (Cost. 12.1; Cod. 11, art. 6-ter, c. 1); qui il 12,5%
EURO_M2 = 750                # ipotesi: euro di materiali per m2
QUOTA_DAI_12 = 0.88          # ipotesi: quota delle persone dai dodici anni, che possono chiedere un telefono (Cod. 7, art. 3, c. 9)

# ------------------------------------------------------------------ manufatti, contati sul bisogno
# Ogni riga: gruppo, voce, prezzo in euro, anni di durata, persone che condividono il bene.
# Prezzi e durate sono ipotesi di redazione: vanno sostituiti con preventivi e misure reali.
# Il costo annuo per persona è prezzo / durata / persone; le ore sono euro per il coefficiente ore per euro.
MANUFATTI = [
    ("Persona e Nucleo", "vestiario e calzature: 4 kg l'anno a 50 euro al kg", 200, 1, 1),
    ("Persona e Nucleo", "letto e materasso", 500, 15, 1),
    ("Persona e Nucleo", "arredi: tavolo, sedie, contenitori", 600, 25, 1),
    ("Persona e Nucleo", "biancheria, stoviglie, pentole", 300, 10, 1),
    ("Persona e Nucleo", "frigorifero con congelatore", 600, 15, 3),
    ("Persona e Nucleo", "piano di cottura e forno", 500, 15, 3),
    ("Persona e Nucleo", "lavatrice in lavanderia comune", 1500, 12, 15),
    ("Persona e Nucleo", "telefono, su richiesta dai dodici anni", 250 * QUOTA_DAI_12, 6, 1),
    ("Persona e Nucleo", "Nodo-IA personale", 400, 8, 1),
    ("Persona e Nucleo", "bicicletta e ricambi", 800, 15, 1),
    ("Persona e Nucleo", "prodotti per l'igiene", 120, 1, 1),
    ("Persona e Nucleo", "lampade, piccoli apparecchi, attrezzi domestici", 400, 10, 1),
    ("Salute", "farmaci e materiale sanitario", 300, 1, 1),
    ("Salute", "attrezzature sanitarie del Bacino", 1500, 15, 1),
    ("Abitare", "materiali per abitazioni: m2 a persona per euro di materiali al m2", M2_ALLOGGIO * EURO_M2, 80, 1),
    ("Abitare", "materiali per le Case Ponte: una quota dell'abitato", M2_ALLOGGIO * EURO_M2 * CASE_PONTE, 80, 1),
    ("Abitare", "materiali per edifici comuni", M2_COMUNI * EURO_M2, 80, 1),
    ("Energia e acqua", "fotovoltaico: 2 kW a persona", 2400, 25, 1),
    ("Energia e acqua", "accumulo", 500, 12, 1),
    ("Energia e acqua", "calore: pompe di calore, solare termico", 1500, 18, 1),
    ("Energia e acqua", "rete idrica, pompe, depurazione", 1000, 40, 1),
    ("Energia e acqua", "ricambi e materiali di consumo", 35, 1, 1),
    ("Produzione", "macchine agricole, irrigazione, mulino, frantoio, celle", 250000, 20, 150),
    ("Produzione", "sementi, materiali ed energia per i campi", 60, 1, 1),
    ("Produzione", "cucina collettiva e Magazzino", 100000, 15, 150),
    ("Produzione", "officina e attrezzi comuni", 80000, 15, 150),
    ("Produzione", "materiali di consumo dell'officina", 30, 1, 1),
    ("Mobilità e Rete", "tre mezzi elettrici leggeri e cargo bike", 100000, 12, 150),
    ("Mobilità e Rete", "trasporto pubblico: 3.000 km l'anno a 10 centesimi", 300, 1, 1),
    ("Mobilità e Rete", "server, apparati e cavi della Rete", 60000, 8, 150),
    ("Mobilità e Rete", "punto di accesso assistito: dispositivi condivisi (ipotesi: cinque da 600 euro)", 3000, 6, 150),
    ("Mobilità e Rete", "collegamento alla rete esterna", 60, 1, 1),
    ("Apprendimento", "materiali e strumenti", 50, 1, 1),
]
FATTORE_ORE_IMPORTATE = 2    # ipotesi senza fonte: i beni prodotti dove il lavoro rende meno contengono il doppio delle ore.
# Il coefficiente per paese (simula_cdr.py) usa la produttività media del paese, ma i beni esportati vengono di solito
# da settori più produttivi: le ore dei beni importati sono quindi probabilmente sovrastimate.


AMMINISTRATIVO = "Funzioni civiche: tempo amministrativo (al più un decimo)"
APPRENDIMENTO = "Altre attività: apprendimento dei minori"


def manufatti_ore(r, m2=None, case_ponte=None):
    """Ore all'anno dei manufatti per tutta la Comunità; m2 e case_ponte permettono un confronto."""
    tot = 0
    for _, voce, euro, anni, persone in MANUFATTI:
        if voce.startswith("materiali per abitazioni") and m2 is not None:
            euro = m2 * EURO_M2
        if voce.startswith("materiali per le Case Ponte") and case_ponte is not None:
            euro = (M2_ALLOGGIO if m2 is None else m2) * EURO_M2 * case_ponte
        tot += euro / anni / persone
    return tot * r["ore_per_euro"] * PERSONE


def conto():
    r = {}
    # --- chi contribuisce
    adulti = PERSONE * (ETA["18-69"] - DICIOTTENNI) / 100
    settantenni = PERSONE * ETA["70-74"] / 100 * 0.5
    puerpere = PERSONE * SOTTO_1 / 100
    genitori = PERSONE * SOTTO_3 / 100 * GENITORI_PER_BAMBINO - puerpere
    piene = adulti + settantenni - puerpere - genitori * 0.5
    piene -= (adulti + settantenni) * ALTRE_RIDUZIONI
    r["contributori"] = piene
    r["disponibili"] = piene * LIMITE_ORE * SETTIMANE
    # --- economia esterna
    r["ore_abitante_ue"] = ORE_UE / ABITANTI_UE
    r["ore_per_euro"] = ORE_UE / PIL_UE
    r["ore_annue_occupato"] = ORE_UE / OCCUPATI_UE
    ue = lambda voce: r["ore_abitante_ue"] * QUOTE_ORE[voce] / 100 * PERSONE
    # --- campo
    campo, ettari = {}, {}
    for voce, g in GRAMMI.items():
        tonnellate = g * 365 * PERSONE / 1e6 * (1 + PERDITE)
        ettari[voce] = tonnellate / (RESA[voce] * (1 - DIVARIO_BIO))
        campo[voce] = ettari[voce] * ORE_ETTARO[voce]
    r["ettari"], r["campo"] = ettari, campo
    pasti = PERSONE * 365 * PASTI_AL_GIORNO / PASTI_PER_ORA
    alimentazione = sum(campo.values()) + ORE_TRASFORMAZIONE + pasti
    r["pasti"] = pasti
    # --- voci comuni ai due scenari
    energia = ue("energia, acqua, rifiuti") * FATTORE_PICCOLA_SCALA
    altre = PERSONE * BUCATO_KG / BUCATO_KG_ORA + ORE_PULIZIE + ORE_RETE + ORE_SANTUARI
    annue = r["ore_annue_occupato"]
    minori_3_17 = PERSONE * (ETA["0-17"] - SOTTO_3) / 100
    # --- scenario A: standard minimi
    a = {
        "Alimentazione": alimentazione,
        "Energia e acqua": energia,
        "Cura: sanità": PERSONE * SANITARI_PER_1000 / 1000 * annue,
        "Cura: anziani e persone non autosufficienti":
            PERSONE * ANZIANI / 100 * ADDETTI_CURA_PER_100_ANZIANI / 100 * annue,
        "Cura: nido": ORE_NIDO,
        "Manutenzione": ue("costruzioni") * QUOTA_MANUTENZIONE,
        "Logistica": ORE_LOGISTICA,
        # il Bilancio del Lavoro ha sette categorie (Cod. 1, art. 2, c. 7, lett. a): l'apprendimento sta in «altre attività»
        "Altre attività: apprendimento dei minori": minori_3_17 / ALUNNI_PER_INSEGNANTE * annue,
        "Altre attività: lavanderia, pulizie, Rete, santuari": altre,
        "Altre attività: funzioni comuni del Bacino e quota federata": ORE_BACINO_PER_PERSONA * PERSONE,
        "Funzioni civiche: tutela civica e altre funzioni della Lista D": ORE_TUTELA,
    }
    # --- scenario B: servizi al livello dell'UE di oggi
    b = dict(a)
    b["Cura: sanità"] = ue("sanità")
    b["Cura: anziani e persone non autosufficienti"] = ue("assistenza sociale")
    b["Cura: nido"] = 0.0          # già compreso nell'assistenza sociale
    b["Altre attività: apprendimento dei minori"] = ue("istruzione")
    b["Manutenzione"] = ue("costruzioni")
    for s in (a, b):
        # il decimo si calcola sul CBO totale della Comunità, tempo amministrativo compreso
        s[AMMINISTRATIVO] = sum(s.values()) / (1 - QUOTA_CIVICA) * QUOTA_CIVICA
    r["A"], r["B"] = a, b
    r["manifattura_ue"] = ue("manifattura") - ue("industria alimentare")   # il cibo è già contato sopra
    r["cibo_ue"] = ue("agricoltura") + ue("industria alimentare") + ue("ristorazione e alloggio")
    r["casa_nel_cbo"] = (pasti + ORE_NIDO + PERSONE * BUCATO_KG / BUCATO_KG_ORA + ORE_PULIZIE) / (1 - QUOTA_CIVICA)
    # --- manufatti contati sul bisogno
    gruppi = {}
    for gruppo, _, euro, anni, persone in MANUFATTI:
        gruppi[gruppo] = gruppi.get(gruppo, 0) + euro / anni / persone
    r["manufatti_euro"] = gruppi                                   # euro per persona all'anno
    r["manufatti_ore"] = sum(gruppi.values()) * r["ore_per_euro"] * PERSONE
    return r


def stampa():
    r = conto()
    n = lambda x: ("%d" % round(x)).rjust(7)
    print("Comunità di %d persone" % PERSONE)
    print("Contributori equivalenti: %.1f (%.0f%% della popolazione)" % (r["contributori"], 100 * r["contributori"] / PERSONE))
    print("  di cui: 18-69 anni %.1f persone, meno i diciottenni con CBO volontario %.1f; 70-74 anni %.1f persone (metà CBO)"
          % (PERSONE * ETA["18-69"] / 100, PERSONE * DICIOTTENNI / 100, PERSONE * ETA["70-74"] / 100))
    print("Ore disponibili all'anno: %s  (%.0f per abitante)" % (n(r["disponibili"]), r["disponibili"] / PERSONE))
    print("\nTerra per il Paniere Alimentare")
    for v in r["ettari"]:
        print("  %-14s %5.2f ha  %s ore" % (v, r["ettari"][v], n(r["campo"][v])))
    print("  %-14s %5.2f ha  %s ore" % ("totale", sum(r["ettari"].values()), n(sum(r["campo"].values()))))
    print("  trasformazione %s ore; pasti collettivi %s ore" % (n(ORE_TRASFORMAZIONE), n(r["pasti"])))
    print("\n%-64s %9s %9s" % ("Ore necessarie all'anno", "A", "B"))
    for v in r["A"]:
        print("%-64s %9s %9s" % (v, n(r["A"][v]), n(r["B"][v])))
    for nome, s in (("A", r["A"]), ("B", r["B"])):
        tot = sum(s.values())
        print("Scenario %s: %s ore = %.0f%% delle disponibili = %.1f ore a settimana per contributore"
              % (nome, n(tot), 100 * tot / r["disponibili"], tot / r["contributori"] / SETTIMANE))
    print("\nEconomia esterna (UE, 2024)")
    print("  ore lavorate per abitante all'anno: %.0f" % r["ore_abitante_ue"])
    print("  ore annue per occupato: %.0f" % r["ore_annue_occupato"])
    print("  prodotto per abitante: %.0f euro" % (PIL_UE / ABITANTI_UE))
    print("  ore di lavoro per euro di prodotto: %.4f (1 ora = %.0f euro)" % (r["ore_per_euro"], 1 / r["ore_per_euro"]))
    print("  ore disponibili su ore lavorate nell'UE, per abitante: %.0f%%"
          % (100 * r["disponibili"] / PERSONE / r["ore_abitante_ue"]))
    print("  manifattura senza industria alimentare, per %d persone: %s ore" % (PERSONE, n(r["manifattura_ue"])))
    print("  agricoltura, industria alimentare e ristorazione, per %d persone: %s ore" % (PERSONE, n(r["cibo_ue"])))
    print("\nManufatti contati sul bisogno (euro per persona all'anno)")
    for g, e in r["manufatti_euro"].items():
        print("  %-18s %6.0f euro  %s ore per %d persone" % (g, e, n(e * r["ore_per_euro"] * PERSONE), PERSONE))
    tot_e = sum(r["manufatti_euro"].values())
    ore_m = r["manufatti_ore"]
    sett0 = lambda ore: ore / r["contributori"] / SETTIMANE
    print("  %-18s %6.0f euro  %s ore = %.1f ore a settimana per contributore" % ("totale", tot_e, n(ore_m), sett0(ore_m)))
    print("  con il fattore %d per i beni importati: %s ore = %.1f ore a settimana"
          % (FATTORE_ORE_IMPORTATE, n(ore_m * FATTORE_ORE_IMPORTATE), sett0(ore_m * FATTORE_ORE_IMPORTATE)))
    cp = ore_m - manufatti_ore(r, case_ponte=0)
    conf = manufatti_ore(r, m2=M2_ALLOGGIO_CONFRONTO, case_ponte=0)
    print("  di cui Case Ponte (%.1f%% dell'abitato): %s ore = %.2f ore a settimana"
          % (100 * CASE_PONTE, n(cp), sett0(cp)))
    print("  confronto: alloggio di %d m2 a persona e niente Case Ponte: %s ore = %.1f ore a settimana (%.1f con il fattore %d)"
          % (M2_ALLOGGIO_CONFRONTO, n(conf), sett0(conf), sett0(conf * FATTORE_ORE_IMPORTATE), FATTORE_ORE_IMPORTATE))
    print("\nConto completo: lavoro interno più manufatti (ore a settimana per contributore)")
    for nome in ("A", "B"):
        interno = sum(r[nome].values())
        print("  scenario %s: %.1f + %.1f = %.1f  (con il fattore %d: %.1f); margine %.1f - %.1f ore"
              % (nome, sett0(interno), sett0(ore_m), sett0(interno + ore_m), FATTORE_ORE_IMPORTATE,
                 sett0(interno + ore_m * FATTORE_ORE_IMPORTATE),
                 LIMITE_ORE - sett0(interno + ore_m * FATTORE_ORE_IMPORTATE), LIMITE_ORE - sett0(interno + ore_m)))
    print("  inventario triplicato: A %.1f, B %.1f" % (sett0(sum(r["A"].values()) + 3 * ore_m), sett0(sum(r["B"].values()) + 3 * ore_m)))
    for nome in ("A", "B"):
        interno = sum(r[nome].values())
        per_altri = r["contributori"] * (1 - QUOTA_ESSENZIALI)
        print("  in transizione, se il %.0f%% dei contributori lavora in una filiera essenziale computata nel CBO: "
              "scenario %s, lavoro interno %.1f ore a settimana per gli altri contributori"
              % (100 * QUOTA_ESSENZIALI, nome, interno / per_altri / SETTIMANE))
    print("  1.000 euro di acquisti per persona all'anno = %.1f ore a settimana per contributore"
          % sett0(1000 * r["ore_per_euro"] * PERSONE))
    print("  scenario B: %.0f%% delle ore lavorate oggi nell'UE per abitante"
          % (100 * sum(r["B"].values()) / PERSONE / r["ore_abitante_ue"]))
    # stima indipendente: McElroy e O'Neill (2025), Global Environmental Change 92, 103008, Regno Unito.
    # Il 36,7 non è uno scenario calcolato: è una stima degli autori in una frase della discussione (lo scenario
    # minimo più le voci che vi mancano). «Minimo realistico» è un'espressione del progetto: gli autori dicono che
    # nessuno scenario è realistico. Con la base dello studio (15-64 anni, 46,6 settimane, 80%) si converte anche
    # il conto del progetto (scenario B con il fattore 2).
    print("\nStima indipendente (McElroy e O'Neill, 2025), riportata in ore di CBO")
    quota_15_64 = 0.638
    for nome, ore in (("solo beni indispensabili", 17.5), ("minimo più servizi mancanti, stima degli autori", 36.7),
                      ("buona vita", 45.5), ("Regno Unito oggi", 64.7)):
        per_abitante = ore * 46.6 * 0.8 * quota_15_64
        print("  %s: %.0f ore per abitante all'anno = %.1f ore di CBO a settimana"
              % (nome, per_abitante, per_abitante * PERSONE / r["contributori"] / SETTIMANE))
    massimo = sum(r["B"].values()) + ore_m * FATTORE_ORE_IMPORTATE
    print("  le %.1f ore di questo conto (scenario B con il fattore %d), con la base dello studio: %.1f ore a settimana"
          % (sett0(massimo), FATTORE_ORE_IMPORTATE, massimo / PERSONE / (46.6 * 0.8 * quota_15_64)))
    casa = r["casa_nel_cbo"]
    print("  lavoro di casa portato nel CBO (pasti, nido, lavanderia, pulizie): %s ore = %.1f ore a settimana"
          % (n(casa), casa / r["contributori"] / SETTIMANE))
    print("\nSe cambia un'ipotesi (scenario A: %.1f ore a settimana)" % (sum(r["A"].values()) / r["contributori"] / SETTIMANE))
    tot_a = sum(r["A"].values())
    lordo = lambda ore: ore / (1 - QUOTA_CIVICA)
    sett = lambda ore: ore / r["contributori"] / SETTIMANE
    casi = [("tre pasti collettivi al giorno", lordo(2 * r["pasti"])),
            ("nessun pasto collettivo", lordo(-r["pasti"])),
            ("frutta secca dimezzata, senza sostituto", lordo(-r["campo"]["frutta secca"] / 2)),
            ("cereali, legumi e girasole a 8 ore per ettaro",
             lordo(-sum(r["campo"][v] - r["ettari"][v] * 8 for v in ("cereali", "legumi", "olio")))),
            ("energia e acqua alla media UE", lordo(-r["A"]["Energia e acqua"] / 2))]
    for nome, delta in casi:
        print("  %-48s %+7d ore -> %.1f ore a settimana" % (nome, round(delta), sett(tot_a + delta)))
    disp48 = r["contributori"] * LIMITE_ORE * 48
    print("  48 settimane di lavoro invece di 52: ore disponibili %s; A %.0f%%, B %.0f%%"
          % (n(disp48), 100 * tot_a / disp48, 100 * sum(r["B"].values()) / disp48))
    # 3 ore al giorno: il minimo della forbice 3-4 dell'indagine europea sull'uso del tempo (dati 2008-2015),
    # applicato a tutte le 150 persone, bambini compresi: il risultato è un ordine di grandezza, non un dato
    tutto = 3 * 365 * PERSONE
    print("  tutto il lavoro di casa di oggi (3 ore al giorno a persona): %s ore = %.0f ore a settimana per contributore"
          % (n(tutto), sett(tutto)))
    ore_persona = LIMITE_ORE * SETTIMANE
    print("\nIl limite è individuale: persone abilitate necessarie a %d ore l'anno ciascuna" % ore_persona)
    for nome in ("A", "B"):
        print("  scenario %s: sanità %.1f; apprendimento dei minori %.1f"
              % (nome, r[nome]["Cura: sanità"] / ore_persona, r[nome][APPRENDIMENTO] / ore_persona))
    print("\nLe soglie del Codice 3 (500 e 2.500 UCR) rispetto al lavoro annuo dello scenario A, secondo la dimensione")
    per_abitante = tot_a / PERSONE
    anno_contributore = tot_a / r["contributori"]
    print("  lavoro annuo: %.0f ore per abitante; un contributore ne dà %.0f" % (per_abitante, anno_contributore))
    print("  proposta 11: soglia bassa = 100 UCR più 1 per persona (massimo 500); alta = 500 più 5 per persona (massimo 2.500)")
    for persone in (30, 150, 500):
        lavoro = per_abitante * persone
        bassa, alta = min(100 + persone, 500), min(500 + 5 * persone, 2500)
        print("  %3d persone: oggi 500 UCR = %4.1f%% e 2.500 = %4.1f%% del lavoro annuo; "
              "con la proposta: %d (%.1f%%, %.0f euro) e %d (%.1f%%, %.0f euro)"
              % (persone, 100 * 500 / lavoro, 100 * 2500 / lavoro, bassa, 100 * bassa / lavoro, bassa / r["ore_per_euro"],
                 alta, 100 * alta / lavoro, alta / r["ore_per_euro"]))
    print("  base delle percentuali: ore necessarie dello scenario A (le stesse di PARAMETRI)")
    farmaci = 300 * r["ore_per_euro"]
    print("  farmaci e materiale sanitario di un anno (300 euro a persona): %.0f UCR per 30 persone, %.0f per 150"
          % (30 * farmaci, 150 * farmaci))


def esempio_pane():
    """Esempio svolto della bozza: UCR di un chilo di pane. I valori segnati «esempio» non sono misure."""
    r = conto()
    h_euro = r["ore_per_euro"]
    resa = RESA["cereali"] * (1 - DIVARIO_BIO) * 1000            # kg di grano per ettaro
    campo = (ORE_ETTARO["cereali"] + 400 * h_euro) / resa        # esempio: 400 euro di acquisti e macchine per ettaro
    kwh = 0.25 * h_euro                                          # esempio: elettricità acquistata a 0,25 euro per kWh
    mulino = 15 / 1000 + 0.05 * kwh + 0.02 * h_euro              # esempio: 15 ore per tonnellata, 0,05 kWh e 2 centesimi per kg
    farina = (campo + mulino) / 0.95                             # esempio: 95 kg di farina integrale da 100 kg di grano
    voci = [("farina (0,74 kg)", farina / 1.35),                 # esempio: 1,35 kg di pane da 1 kg di farina
            ("lavoro al forno", 1 / 15),                         # esempio: 15 kg di pane per ora di lavoro
            ("energia del forno (0,7 kWh)", 0.7 * kwh),
            ("sale, lievito e ammortamento del forno (5 centesimi)", 0.05 * h_euro)]
    print("\nEsempio: un chilo di pane")
    print("  grano: %.4f UCR per kg; farina: %.4f UCR per kg; 1 kWh acquistato: %.4f UCR" % (campo, farina, kwh))
    for nome, v in voci:
        print("  %-52s %.4f" % (nome, v))
    tot = sum(v for _, v in voci)
    print("  %-52s %.4f UCR = %.1f minuti" % ("totale", tot, tot * 60))


COSTO_DEI_ROBOT = 0.2      # ipotesi: costruire, alimentare e mantenere le macchine costa un quinto delle ore risparmiate


def automazione():
    """Quanto del lavoro interno è automatizzabile e quanto può cambiare il conto (scenario A)."""
    r = conto()
    a = r["A"]
    sett = lambda ore: ore / r["contributori"] / SETTIMANE
    campo = sum(r["campo"].values())
    macchine = {"Campo": campo, "Trasformazione del cibo": ORE_TRASFORMAZIONE, "Energia e acqua": a["Energia e acqua"],
                "Manutenzione e costruzioni": a["Manutenzione"], "Logistica": a["Logistica"]}
    persone = {"Pasti collettivi": r["pasti"],
               "Cura: sanità, anziani, nido": a["Cura: sanità"] + a["Cura: anziani e persone non autosufficienti"] + a["Cura: nido"],
               "Apprendimento": a[APPRENDIMENTO]}
    interno = sum(v for k, v in a.items() if not k.startswith("Funzioni civiche"))
    print("\nAutomazione (scenario A)")
    print("  Lavoro che le macchine possono alleggerire:")
    for k, v in macchine.items():
        print("    %-28s %6.0f ore" % (k, v))
    tot_m = sum(macchine.values())
    print("    %-28s %6.0f ore = %.0f%% del lavoro interno senza le funzioni civiche" % ("totale", tot_m, 100 * tot_m / interno))
    print("  Lavoro tra persone, che non si automatizza:")
    for k, v in persone.items():
        print("    %-28s %6.0f ore" % (k, v))
    tot_p = sum(persone.values())
    print("    %-28s %6.0f ore = %.0f%%" % ("totale", tot_p, 100 * tot_p / interno))
    totale = sum(a.values())
    for quota in (0.25, 0.5, 0.75):
        lordo = tot_m * quota / (1 - QUOTA_CIVICA)
        netto = lordo * (1 - COSTO_DEI_ROBOT)
        print("  se le macchine tolgono il %2.0f%% di quelle ore: da %.1f a %.1f ore a settimana (%.1f contando il costo delle macchine)"
              % (100 * quota, sett(totale), sett(totale - lordo), sett(totale - netto)))
    dieci = tot_m * 0.10 / (1 - QUOTA_CIVICA)
    print("  ogni 10%% in meno vale %.0f minuti a settimana per contributore" % (sett(dieci) * 60))
    # esempio del § 5.1: tutte le voci dell'art. 6-bis, c. 7, del Codice 7 (valori d'esempio, non misure)
    h = r["ore_per_euro"]
    costruzione = 60000 / 15 * h
    formazione = 40 / 15                 # esempio: 40 ore di formazione di chi la usa, ripartite sui 15 anni
    fine_vita = 60000 * 0.05 / 15 * h    # esempio: smaltimento e recupero pari al 5% del prezzo
    manutenzione = 50                    # esempio: 50 ore di manutenzione l'anno
    print("  esempio: una macchina da 60.000 euro che dura 15 anni costa %.0f UCR l'anno (%.0f se fatta per metà dove il lavoro rende meno)"
          % (costruzione, costruzione * FATTORE_ORE_IMPORTATE))
    print("    formazione di chi la usa (40 ore) %.1f e fine vita (5%% del prezzo) %.1f UCR l'anno; con %d ore di manutenzione: da %.0f a %.0f ore l'anno"
          % (formazione, fine_vita, manutenzione, costruzione + formazione + fine_vita + manutenzione,
             costruzione * FATTORE_ORE_IMPORTATE + formazione + fine_vita * FATTORE_ORE_IMPORTATE + manutenzione))


def paniere():
    """Quantità della bozza del Paniere (bozze/allegato-paniere.md) per la Comunità tipo."""
    print("\nPaniere (bozza del Paniere)")
    ospiti = 0.15                        # Cod. 11, art. 6-ter, c. 5: ospiti fino al 15% dei residenti
    print("  acqua: 50 litri per %d persone = %.1f m3 al giorno; con il %.0f%% di ospiti %.1f m3; acqua calda 20 litri = %.1f m3 all'anno a persona"
          % (PERSONE, 50 * PERSONE / 1000, 100 * ospiti, 50 * PERSONE * (1 + ospiti) / 1000, 20 * 365 / 1000))
    print("  terra (Peters e altri, 0,13-0,14 ettari a persona): %.0f ettari per %d persone; %.0f-%.0f per 500"
          % (0.135 * PERSONE, PERSONE, 0.13 * 500, 0.14 * 500))
    print("  energia (Millward-Hopkins): 15,3 GJ = %.0f kWh all'anno = %.1f kWh al giorno" % (15.3e9 / 3.6e6, 15.3e9 / 3.6e6 / 365))
    print("  sei mesi della dieta del Paniere, a persona (riferimento per il Paniere d'emergenza): " + ", ".join(
        "%s %.0f kg" % (v, GRAMMI[v] * 365 / 2 / 1000) for v in ("cereali", "legumi", "frutta secca", "olio")))


def cbo_stimato():
    """Lavoro interno a settimana per contributore negli scenari A e B: è il CBO stimato usato da simula_cdr.py."""
    r = conto()
    return {nome: sum(r[nome].values()) / r["contributori"] / SETTIMANE for nome in ("A", "B")}


if __name__ == "__main__":
    stampa()
    esempio_pane()
    automazione()
    paniere()
